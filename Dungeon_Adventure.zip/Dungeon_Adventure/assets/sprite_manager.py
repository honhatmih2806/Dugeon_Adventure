"""Sprite manager: load multiple named icons and provide scaled variants.

Place PNG files into `assets/sprites/` with names matching item/entity
identifiers. Examples: `player.png`, `enemy.png`, `key.png`, `sword.png`,
`torch.png`, `health_potion.png`.

Functions:
- `load_icons()` scans the sprites folder and caches originals.
- `get_named_icon(name, tile_size)` returns a scaled surface or None.
"""

from __future__ import annotations

import os
from typing import Optional

import pygame

SPRITES_DIR = os.path.join(os.path.dirname(__file__), "sprites")

_ORIGINALS: dict[str, pygame.Surface] = {}
_SCALED_CACHE: dict[tuple[str, int], pygame.Surface] = {}


def load_icons(directory: str | None = None) -> None:
    """Load all PNG files from the sprites directory into the originals cache."""
    global _ORIGINALS, _SCALED_CACHE
    _ORIGINALS.clear()
    _SCALED_CACHE.clear()

    sprites_path = directory or SPRITES_DIR
    if not os.path.isdir(sprites_path):
        return

    for name in os.listdir(sprites_path):
        lower = name.lower()
        if not lower.endswith(('.png', '.jpg', '.jpeg', '.gif')):
            continue
        key = os.path.splitext(name)[0].lower()
        try:
            surf = pygame.image.load(os.path.join(sprites_path, name)).convert_alpha()
        except Exception:
            continue
        _ORIGINALS[key] = surf
        if key == 'spirits':
            _ORIGINALS['spirit'] = surf


def _normalize_name(name: str) -> str:
    """Normalize item/entity names to sprite keys.

    Examples: 'Key 1' -> 'key', 'Health Potion' -> 'health_potion'
    """
    name = name.lower()
    if name.startswith("key"):
        return "key"
    return name.replace(" ", "_")


def get_named_icon(name: str, tile_size: int) -> Optional[pygame.Surface]:
    """Return a scaled icon for `name` sized to fit inside a tile.

    Returns None when no icon is available.
    """
    global _ORIGINALS, _SCALED_CACHE
    if not _ORIGINALS:
        load_icons()

    key = _normalize_name(name)
    if key not in _ORIGINALS:
        return None

    cache_key = (key, tile_size)
    if cache_key in _SCALED_CACHE:
        return _SCALED_CACHE[cache_key]

    padding = 6
    target = max(1, tile_size - padding * 2)
    try:
        scaled = pygame.transform.smoothscale(_ORIGINALS[key], (target, target))
    except Exception:
        return None

    _SCALED_CACHE[cache_key] = scaled
    return scaled

"""Cached pygame font instances."""

from __future__ import annotations

import pygame


class FontCache:
    """Create and reuse Font objects by size."""

    _cache: dict[int, pygame.font.Font] = {}

    @classmethod
    def get(cls, size: int) -> pygame.font.Font:
        """Return a cached font for the given pixel size."""
        if size not in cls._cache:
            cls._cache[size] = pygame.font.Font(None, size)
        return cls._cache[size]

    @classmethod
    def clear(cls) -> None:
        """Clear cached fonts (used only when pygame reinitializes)."""
        cls._cache.clear()

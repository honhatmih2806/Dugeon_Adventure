"""Generate simple 64x64 placeholder icons for the project.

Run this script from the workspace root with Python and Pillow installed:

    py -m pip install pillow
    python assets/make_placeholders.py

This will create PNGs in `assets/sprites/`.
"""

from __future__ import annotations

import os
from PIL import Image, ImageDraw, ImageFont

SPRITES_DIR = os.path.join(os.path.dirname(__file__), "sprites")
os.makedirs(SPRITES_DIR, exist_ok=True)

ICON_SIZE = 64
BG_COLORS = {
    "player": (50, 150, 255),
    "enemy": (220, 45, 45),
    "key": (255, 215, 0),
    "sword": (180, 180, 180),
    "torch": (255, 140, 0),
    "health_potion": (0, 220, 0),
    "magic_stone": (180, 0, 180),
    "spirit": (120, 220, 220),
}

FONT = None
try:
    FONT = ImageFont.truetype("arial.ttf", 18)
except Exception:
    try:
        FONT = ImageFont.truetype("DejaVuSans.ttf", 18)
    except Exception:
        FONT = ImageFont.load_default()

for name, color in BG_COLORS.items():
    img = Image.new("RGBA", (ICON_SIZE, ICON_SIZE), color + (255,))
    draw = ImageDraw.Draw(img)

    # draw a simple symbol
    cx, cy = ICON_SIZE // 2, ICON_SIZE // 2
    if name == "player":
        draw.ellipse((16, 10, 48, 42), fill=(255, 255, 255, 180))
        draw.rectangle((24, 38, 40, 54), fill=(255, 255, 255, 180))
    elif name == "enemy":
        draw.polygon([(32, 8), (52, 28), (44, 52), (20, 52), (12, 28)], fill=(255, 255, 255, 180))
    elif name == "key":
        draw.rectangle((20, 28, 44, 36), fill=(255, 255, 255, 220))
        draw.rectangle((40, 32, 48, 36), fill=(255, 255, 255, 220))
        draw.ellipse((14, 22, 26, 34), fill=(255, 255, 255, 220))
    elif name == "sword":
        draw.rectangle((28, 14, 36, 48), fill=(255, 255, 255, 220))
        draw.polygon([(18, 20), (28, 18), (28, 22), (18, 24)], fill=(200, 200, 200, 220))
    elif name == "torch":
        draw.rectangle((30, 20, 34, 50), fill=(80, 40, 0))
        draw.ellipse((24, 10, 40, 26), fill=(255, 220, 0))
    elif name == "health_potion":
        draw.ellipse((20, 16, 44, 44), fill=(255, 255, 255, 220))
        draw.rectangle((28, 8, 36, 16), fill=(255, 0, 0))
    elif name == "magic_stone":
        draw.polygon([(32, 8), (48, 28), (40, 52), (24, 52), (16, 28)], fill=(255, 255, 255, 220))
    elif name == "spirit":
        draw.ellipse((18, 18, 46, 46), fill=(255, 255, 255, 220))
        draw.polygon([(32, 8), (44, 30), (32, 26), (20, 30)], fill=(255, 255, 255, 220))

    text = name.replace("_", " ").title()
    try:
        w, h = FONT.getsize(text)
    except Exception:
        # fallback
        bbox = draw.textbbox((0, 0), text, font=FONT)
        w = bbox[2] - bbox[0]
        h = bbox[3] - bbox[1]

    draw.text((ICON_SIZE - w - 4, ICON_SIZE - h - 2), text, font=FONT, fill=(0, 0, 0))

    out_path = os.path.join(SPRITES_DIR, f"{name}.png")
    img.save(out_path)
    print("Wrote", out_path)

print("Done generating placeholders.")

"""Procedural dungeon generation."""

import random

FLOOR: int = 0
WALL: int = 1


class MazeGenerator:
    """Generates random dungeon layouts with rooms and corridors."""

    def __init__(self, width: int, height: int) -> None:
        """Initialize the maze generator for a grid of the given size."""
        self._width = width
        self._height = height

    def generate(self) -> list[list[int]]:
        """Generate a connected maze using DFS recursive backtracking."""
        grid = [
            [WALL for _ in range(self._width)] for _ in range(self._height)
        ]
        visited = [
            [False for _ in range(self._width)] for _ in range(self._height)
        ]

        start_x, start_y = 1, 1
        self._carve_passages(grid, visited, start_x, start_y)
        # Widen corridors slightly so paths are easier to navigate by agents
        # and players (make corridors radius=1 thicker).
        self._widen_passages(grid, radius=1)
        # Connect nearby passages near map edges to reduce isolated
        # dead-ends on the border and improve overall connectivity.
        self._connect_edge_corridors(grid)
        return grid

    def _widen_passages(self, grid: list[list[int]], radius: int = 1) -> None:
        """Expand floor tiles by `radius` using a simple dilation pass.

        This reduces extremely narrow single-tile corridors that make
        movement and pathfinding feel awkward. The operation is conservative
        (only enlarges floor, never converts existing walls surrounding
        special rooms after later carving).
        """
        height = len(grid)
        width = len(grid[0]) if height > 0 else 0
        to_carve: set[tuple[int, int]] = set()

        # Conservative widening: inspect wall cells and carve only those
        # that have a small number of floor neighbors (4-way). This keeps
        # corridors wider without turning the whole map into open area.
        for y in range(1, height - 1):
            for x in range(1, width - 1):
                if grid[y][x] != WALL:
                    continue

                floor_neighbors = 0
                for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
                    if grid[y + dy][x + dx] == FLOOR:
                        floor_neighbors += 1

                # only widen where carving will produce a short corridor
                # (1 or 2 adjacent floor tiles). Avoid carving near many
                # floor neighbors which indicates a larger open room.
                if 1 <= floor_neighbors <= 2:
                    # probabilistically widen: prefer single-floor neighbor
                    # locations less aggressively than two-neighbor spots.
                    if floor_neighbors == 1:
                        p = 0.28
                    else:
                        p = 0.12
                    if random.random() < p:
                        to_carve.add((x, y))

        for cx, cy in to_carve:
            grid[cy][cx] = FLOOR

    def _connect_edge_corridors(self, grid: list[list[int]]) -> None:
        """Add extra connections near the map edges to reduce isolated dead-ends.

        We look for wall cells that separate two floor regions and randomly
        remove some walls — biasing the probability when the cell is close
        to the map border so edge corridors tend to connect into the main
        reachable area.
        """
        height = len(grid)
        width = len(grid[0]) if height > 0 else 0

        to_carve = []
        for y in range(1, height - 1):
            for x in range(1, width - 1):
                if grid[y][x] != WALL:
                    continue

                # count adjacent floor neighbors
                neighbors = 0
                for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
                    if grid[y + dy][x + dx] == FLOOR:
                        neighbors += 1

                # only consider walls that separate at least two floors
                if neighbors < 2:
                    continue

                # bias toward carving near the border but keep very small
                # probability so we don't over-connect edges.
                dist_to_edge = min(x, y, width - 1 - x, height - 1 - y)
                base_p = 0.02
                p = base_p + max(0.0, (3 - dist_to_edge)) * 0.04
                if random.random() < p:
                    to_carve.append((x, y))

        for x, y in to_carve:
            grid[y][x] = FLOOR

    def _carve_passages(
        self,
        grid: list[list[int]],
        visited: list[list[bool]],
        x: int,
        y: int,
    ) -> None:
        """Carve passages recursively from the current cell."""
        visited[y][x] = True
        grid[y][x] = FLOOR

        directions = [(0, -2), (0, 2), (-2, 0), (2, 0)]
        random.shuffle(directions)

        for dx, dy in directions:
            nx = x + dx
            ny = y + dy

            if not self._is_valid_cell(nx, ny):
                continue

            if visited[ny][nx]:
                continue

            grid[y + dy // 2][x + dx // 2] = FLOOR
            self._carve_passages(grid, visited, nx, ny)

    def _is_valid_cell(self, x: int, y: int) -> bool:
        """Return True if (x, y) is an uncarved maze cell inside the border."""
        return (
            1 <= x < self._width - 1
            and 1 <= y < self._height - 1
            and x % 2 == 1
            and y % 2 == 1
        )

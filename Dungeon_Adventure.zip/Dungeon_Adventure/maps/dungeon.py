"""Dungeon map representation and AI-assisted generation pipeline."""

from __future__ import annotations

import random

import pygame

from ai.hill_climbing import (
    DungeonLayout,
    HillClimbingOptimizer,
    build_boss_adjacent_tiles,
    build_reachable_tiles,
)
from ai.simulated_annealing import SimulatedAnnealingOptimizer
from ai.min_conflicts import MinConflictsOptimizer
from ai.map_constraints import MapConstraintContext
from ai.ucs import ucs
from maps.maze_generator import MazeGenerator
from assets.sprite_manager import get_named_icon

FLOOR: int = 0
WALL: int = 1
GATE: int = 2


class Gate:
    """Represents the locked entrance to the boss room."""

    LOCKED_COLOR: tuple[int, int, int] = (97, 23, 36)
    UNLOCKED_COLOR: tuple[int, int, int] = (47, 103, 70)

    def __init__(self, position: tuple[int, int], additional_positions: list[tuple[int, int]] | None = None) -> None:
        """Initialize a locked gate at the given grid positions."""
        self.position = position
        self.positions = [position]
        if additional_positions:
            for extra in additional_positions:
                if extra not in self.positions:
                    self.positions.append(extra)
        self.locked = True
        self.required_keys = 4

    def unlock(self, keys: int) -> bool:
        """Unlock the gates when the player has enough keys."""
        if keys < self.required_keys:
            return False

        if self.locked:
            self.locked = False
            print("Boss Room Unlocked")

        return True

    def get_color(self) -> tuple[int, int, int]:
        """Return the current gate color."""
        if self.locked:
            return self.LOCKED_COLOR
        return self.UNLOCKED_COLOR


class Dungeon:
    """Represents the full dungeon layout including rooms and corridors."""

    TILE_SIZE: int = 32
    GRID_WIDTH: int = 40
    GRID_HEIGHT: int = 25

    FLOOR_COLOR: tuple[int, int, int] = (14, 13, 19)
    WALL_COLOR: tuple[int, int, int] = (24, 30, 48)
    KEY_ROOM_COLOR: tuple[int, int, int] = (66, 48, 72)
    BOSS_ROOM_COLOR: tuple[int, int, int] = (48, 28, 56)
    LABORATORY_FLOOR_COLOR: tuple[int, int, int] = (27, 72, 76)
    PUZZLE_ROOM_COUNT: int = 2
    KEY_ROOM_SIZE: int = 3
    BOSS_ROOM_SIZE: int = 5
    # For progression we want a compact 3x3 boss entrance area
    BOSS_ROOM_ENTRANCE_SIZE: int = 3
    LABORATORY_ROOM_SIZE: int = 3
    MIN_SPECIAL_ROOM_DISTANCE: int = 10
    MIN_KEY_ROOM_DISTANCE: int = 10
    MIN_SPAWN_PROGRESS_DISTANCE: int = 10
    TRAP_VALIDATION_ATTEMPTS: int = 40
    ITEM_MAX_COUNTS: dict[str, int] = {
        "Key 1": 1,
        "Key 2": 1,
        "Key 3": 1,
        "Key 4": 1,
        "Sword": 7,
        "Magic Stone": 6,
        "Torch": 7,
        "Health Potion": 4,
    }

    def __init__(self, grid_width: int | None = None, grid_height: int | None = None, game_mode: str = "LOW") -> None:
        """Build the dungeon through maze generation and local search.

        Optional `grid_width` and `grid_height` allow the caller to limit
        the generated map size (used by GameApplication to create maps
        relative to the visible screen)."""
        self.item_max_counts = dict(self.ITEM_MAX_COUNTS)
        if game_mode == "LOW":
            self.item_max_counts["Sword"] = 3
            self.item_max_counts["Torch"] = 10
        elif game_mode == "MEDIUM":
            self.item_max_counts["Sword"] = 5

        # allow instance override of class defaults
        if grid_width is not None:
            self.GRID_WIDTH = grid_width
        if grid_height is not None:
            self.GRID_HEIGHT = grid_height

        generator = MazeGenerator(self.GRID_WIDTH, self.GRID_HEIGHT)
        self._grid = generator.generate()
        self._maze_grid = [row[:] for row in self._grid]
        self._layout = self._build_layout()
        self._boss_room = self._build_boss_room(self._layout.boss_room_center)
        self._apply_layout(self._layout)
        self._reposition_items_outside_special_rooms()
        self._relocate_key_rooms()
        self._validate_item_counts()
        self._layout.traps = self._generate_validated_traps()

        repair_result = self._run_min_conflicts_repair()
        self._layout = repair_result.layout
        self._initial_conflicts = repair_result.initial_conflicts
        self._resolved_conflicts = repair_result.resolved_conflicts
        self._restore_maze_and_reapply_layout(self._layout)

        self._spawn_region, self._spawn_point, self._spawn_score = (
            self._select_spawn_point()
        )
        self._layout.spawn_point = self._spawn_point
        self._final_conflict_count = self._finalize_conflicts()
        # Ensure the boss room is reachable from the laboratory/spawn before
        # computing UCS path. If generation produced a sealed boss, carve a
        # simple corridor to the gate so the player can progress.
        self._ensure_boss_reachable()
        self._ensure_collectible_items_reachable()
        self._compute_ucs_path()
        self._print_debug_output()

    def get_spawn_point(self) -> tuple[int, int]:
        """Return a floor tile suitable for spawning the player."""
        return self._spawn_point

    def get_spawn_region(self) -> str:
        """Return the corner region chosen for player spawn."""
        return self._spawn_region

    def get_tile(self, x: int, y: int) -> int:
        """Return the tile type at grid coordinates."""
        return self._grid[y][x]

    def get_key_rooms(self) -> list[tuple[int, int]]:
        """Return the center positions of puzzle key rooms."""
        return list(self._layout.key_rooms)

    def get_puzzle_room_positions(self) -> list[tuple[int, int]]:
        """Return fixed key-room centers for puzzle rooms (Keys #1 and #2)."""
        return list(self._layout.key_rooms)

    def get_laboratory_room_position(self) -> tuple[int, int]:
        """Return the laboratory room center chosen by simulated annealing."""
        return self._layout.laboratory_room

    def get_boss_room_center(self) -> tuple[int, int]:
        """Return the optimized boss room center."""
        return self._layout.boss_room_center

    def get_item_placements(self) -> list[tuple[int, int, str]]:
        """Return optimized item placements for gameplay."""
        return list(self._layout.items)

    def get_trap_placements(self) -> list[tuple[int, int, str]]:
        """Return optimized trap placements for gameplay."""
        return list(self._layout.traps)

    def get_ucs_path(self) -> list[tuple[int, int]]:
        """Return the UCS path from the laboratory to the boss room."""
        return list(self._ucs_path)

    def get_ucs_stats(self) -> tuple[int, int, int]:
        """Return UCS path length, total cost, and nodes expanded."""
        return self._ucs_path_length, self._ucs_total_cost, self._ucs_nodes_expanded

    def get_gate_position(self) -> tuple[int, int]:
        """Return the primary final gate position."""
        return self.gate.position

    def get_gate_positions(self) -> list[tuple[int, int]]:
        """Return all boss gate positions."""
        return list(self.gate.positions)

    def is_gate_open(self) -> bool:
        """Return True when the final gate is open."""
        return not self.gate.locked

    def try_unlock_gate(self, keys: int) -> bool:
        """Try to unlock the final gate with the player's key count."""
        return self.gate.unlock(keys)

    def is_walkable(self, x: int, y: int) -> bool:
        """Return True if the tile at (x, y) is a floor tile."""
        if x < 0 or y < 0 or x >= self.GRID_WIDTH or y >= self.GRID_HEIGHT:
            return False
        if self._grid[y][x] == GATE:
            return not self.gate.locked
        return self._grid[y][x] == FLOOR

    def is_gate_position(self, x: int, y: int) -> bool:
        """Return True when coordinates match any gate position."""
        return (x, y) in self.gate.positions

    def is_boss_room_tile(self, x: int, y: int) -> bool:
        """Return True when a tile is inside the boss room."""
        left, top, right, bottom = self._boss_room["bounds"]
        return left <= x <= right and top <= y <= bottom

    def is_puzzle_room_tile(self, x: int, y: int) -> bool:
        """Return True when a tile belongs to a puzzle room."""
        return (x, y) in self._get_puzzle_room_tiles()

    def is_laboratory_room_tile(self, x: int, y: int) -> bool:
        """Return True when a tile belongs to the laboratory room."""
        return (x, y) in self._get_laboratory_room_tiles()

    def is_laboratory_tile(self, x: int, y: int) -> bool:
        """Return True when coordinates are inside the laboratory room."""
        return self.is_laboratory_room_tile(x, y)

    def is_forbidden_spawn_tile(self, x: int, y: int) -> bool:
        """Return True when enemies, items, or traps may not spawn here."""
        return (x, y) in self._get_forbidden_placement_tiles()

    def _build_layout(self) -> DungeonLayout:
        """Create and optimize the dungeon entity layout before spawn selection."""
        walkable_tiles = self._collect_walkable_tiles()
        layout_anchor = self._layout_anchor_point(walkable_tiles)
        key_rooms = self._generate_puzzle_rooms(walkable_tiles)
        puzzle_tiles = self._get_puzzle_room_tiles(key_rooms)
        forbidden_tiles = set(puzzle_tiles)
        default_boss_bounds = self._default_boss_bounds()
        boss_adjacent_tiles = build_boss_adjacent_tiles(
            default_boss_bounds,
            self.GRID_WIDTH,
            self.GRID_HEIGHT,
        )
        reserved_tiles = set(key_rooms) | puzzle_tiles
        pathfinding_grid = self._build_pathfinding_grid(include_gate=False)

        layout = DungeonLayout(
            spawn_point=layout_anchor,
            key_rooms=key_rooms,
            puzzle_rooms=list(key_rooms),
            items=[],
            traps=[],
            laboratory_room=layout_anchor,
            boss_room_center=self._default_boss_center(),
        )

        hill_climbing = HillClimbingOptimizer(
            grid=self._grid,
            walkable_tiles=walkable_tiles,
            spawn_point=layout_anchor,
            boss_adjacent_tiles=boss_adjacent_tiles,
            reserved_tiles=reserved_tiles,
            forbidden_tiles=forbidden_tiles,
        )
        layout.hill_climb_placements = hill_climbing.optimize_items()
        layout.items = [
            (*layout.hill_climb_placements[item_type], item_type)
            for item_type in ("Key 3", "Sword", "Health Potion", "Torch")
        ]

        hill_reserved = reserved_tiles | set(layout.hill_climb_placements.values())
        reachable_tiles = build_reachable_tiles(self._grid, layout_anchor) & set(
            walkable_tiles
        )

        simulated_annealing = SimulatedAnnealingOptimizer(
            walkable_tiles=walkable_tiles,
            spawn_point=layout_anchor,
            reachable_tiles=reachable_tiles,
            reserved_tiles=hill_reserved,
            forbidden_tiles=forbidden_tiles,
            special_room_centers=key_rooms,
            boss_room_size=self.BOSS_ROOM_SIZE,
            grid_width=self.GRID_WIDTH,
            grid_height=self.GRID_HEIGHT,
            pathfinding_grid=pathfinding_grid,
            laboratory_room_size=self.LABORATORY_ROOM_SIZE,
        )
        layout = simulated_annealing.optimize(layout)
        layout.items.extend(
            [
                (*key_rooms[0], "Key 1"),
                (*key_rooms[1], "Key 2"),
            ]
        )
        return layout

    def _run_min_conflicts_repair(self):
        """Run the final min-conflicts repair stage before player spawn."""
        walkable_tiles = self._collect_walkable_tiles()
        layout_anchor = self._layout_anchor_point(walkable_tiles)
        context = MapConstraintContext(
            grid=self._grid,
            grid_width=self.GRID_WIDTH,
            grid_height=self.GRID_HEIGHT,
            layout_anchor=layout_anchor,
            key_rooms=list(self._layout.key_rooms),
            items=list(self._layout.items),
            traps=list(self._layout.traps),
            laboratory_room=self._layout.laboratory_room,
            boss_room_center=self._layout.boss_room_center,
            boss_room_size=self.BOSS_ROOM_SIZE,
            laboratory_room_size=self.LABORATORY_ROOM_SIZE,
            key_room_size=self.KEY_ROOM_SIZE,
            forbidden_tiles=self._get_forbidden_placement_tiles(),
            pathfinding_grid=self._build_pathfinding_grid(include_gate=False),
        )
        optimizer = MinConflictsOptimizer(context, walkable_tiles)
        return optimizer.repair(self._layout)

    def _finalize_conflicts(self) -> int:
        """Run a final conflict check and repair pass using the chosen spawn point."""
        walkable_tiles = self._collect_walkable_tiles()
        context = MapConstraintContext(
            grid=self._grid,
            grid_width=self.GRID_WIDTH,
            grid_height=self.GRID_HEIGHT,
            layout_anchor=self._spawn_point,
            spawn_point=self._spawn_point,
            key_rooms=list(self._layout.key_rooms),
            items=list(self._layout.items),
            traps=list(self._layout.traps),
            laboratory_room=self._layout.laboratory_room,
            boss_room_center=self._layout.boss_room_center,
            boss_room_size=self.BOSS_ROOM_SIZE,
            laboratory_room_size=self.LABORATORY_ROOM_SIZE,
            key_room_size=self.KEY_ROOM_SIZE,
            forbidden_tiles=self._get_forbidden_placement_tiles(),
            pathfinding_grid=self._build_pathfinding_grid(include_gate=False),
            blocked_tiles={self._spawn_point},
        )
        optimizer = MinConflictsOptimizer(context, walkable_tiles)
        optimizer.MAX_ITERATIONS = 80
        result = optimizer.repair(self._layout)
        self._layout = result.layout
        self._resolved_conflicts += max(0, result.initial_conflicts - result.final_conflicts)
        self._restore_maze_and_reapply_layout(self._layout)

        if result.final_conflicts > 0:
            self._ensure_collectible_items_reachable()
            self._restore_maze_and_reapply_layout(self._layout)

        final_context = MapConstraintContext(
            grid=self._grid,
            grid_width=self.GRID_WIDTH,
            grid_height=self.GRID_HEIGHT,
            layout_anchor=self._spawn_point,
            spawn_point=self._spawn_point,
            key_rooms=list(self._layout.key_rooms),
            items=list(self._layout.items),
            traps=list(self._layout.traps),
            laboratory_room=self._layout.laboratory_room,
            boss_room_center=self._layout.boss_room_center,
            boss_room_size=self.BOSS_ROOM_SIZE,
            laboratory_room_size=self.LABORATORY_ROOM_SIZE,
            key_room_size=self.KEY_ROOM_SIZE,
            forbidden_tiles=self._get_forbidden_placement_tiles(),
            pathfinding_grid=self._build_pathfinding_grid(include_gate=False),
            blocked_tiles={self._spawn_point},
        )
        from ai.map_constraints import count_conflicts

        return count_conflicts(final_context).total_conflicts

    def _restore_maze_and_reapply_layout(self, layout: DungeonLayout) -> None:
        """Reset carved rooms and rebuild special rooms from the repaired layout."""
        self._grid = [row[:] for row in self._maze_grid]
        self._layout = layout
        for center_x, center_y in layout.key_rooms:
            self._carve_room(center_x, center_y, self.KEY_ROOM_SIZE)
        lab_x, lab_y = layout.laboratory_room
        self._carve_room(lab_x, lab_y, self.LABORATORY_ROOM_SIZE)
        self._boss_room = self._build_boss_room(layout.boss_room_center)

    def _layout_anchor_point(
        self,
        walkable_tiles: list[tuple[int, int]],
    ) -> tuple[int, int]:
        """Return a temporary anchor used before the final spawn is chosen."""
        if walkable_tiles:
            return walkable_tiles[0]
        return 1, 1

    def _apply_layout(self, layout: DungeonLayout) -> None:
        """Carve puzzle and laboratory rooms and store the final layout."""
        self._layout = layout
        for center_x, center_y in layout.key_rooms:
            self._carve_room(center_x, center_y, self.KEY_ROOM_SIZE)
        lab_x, lab_y = layout.laboratory_room
        self._carve_room(lab_x, lab_y, self.LABORATORY_ROOM_SIZE)

    def _generate_puzzle_rooms(
        self,
        walkable_tiles: list[tuple[int, int]],
    ) -> list[tuple[int, int]]:
        """Place key rooms with random reachable locations and separation."""
        rooms: list[tuple[int, int]] = []
        margin = self.KEY_ROOM_SIZE // 2
        corner_regions = self._get_corner_region_tiles(walkable_tiles)
        candidates = [
            tile
            for tile in walkable_tiles
            if margin <= tile[0] < self.GRID_WIDTH - margin
            and margin <= tile[1] < self.GRID_HEIGHT - margin
            and all(
                self._manhattan(tile, corner_tile) >= self.MIN_KEY_ROOM_DISTANCE
                for corner_tile in corner_regions
            )
        ]

        for _ in range(self.PUZZLE_ROOM_COUNT):
            valid_candidates = [
                tile
                for tile in candidates
                if all(
                    self._manhattan(tile, existing) >= self.MIN_KEY_ROOM_DISTANCE
                    for existing in rooms
                )
                and not self._room_bounds_overlap(
                    tile,
                    rooms,
                    self.KEY_ROOM_SIZE,
                    self.KEY_ROOM_SIZE,
                )
            ]
            if not valid_candidates:
                valid_candidates = [
                    tile
                    for tile in walkable_tiles
                    if tile not in rooms
                ]

            chosen = random.choice(valid_candidates)
            rooms.append(chosen)

        return rooms[: self.PUZZLE_ROOM_COUNT]

    def _select_spawn_point(self) -> tuple[str, tuple[int, int], float]:
        """Choose the highest-scoring reachable spawn after all placements."""
        strict_candidates = self._score_spawn_candidates(enforce_distance=True)
        if strict_candidates:
            score, position = random.choice(self._best_spawn_candidates(strict_candidates))
            return "optimized", position, score

        fallback_candidates = self._score_spawn_candidates(enforce_distance=False)
        if fallback_candidates:
            score, position = random.choice(
                self._best_spawn_candidates(fallback_candidates)
            )
            return "fallback", position, score

        fallback = self._layout_anchor_point(self._collect_walkable_tiles())
        return "fallback", fallback, self._score_spawn_position(fallback)

    def _score_spawn_candidates(
        self,
        enforce_distance: bool,
    ) -> list[tuple[float, tuple[int, int]]]:
        """Return scored spawn candidates from every walkable tile."""
        candidates: list[tuple[float, tuple[int, int]]] = []
        reachable_tiles = self._get_spawn_reachable_tiles()

        for tile in reachable_tiles:
            if not self._is_valid_spawn_candidate(
                tile,
                enforce_distance,
                reachable_tiles,
            ):
                continue
            candidates.append((self._score_spawn_position(tile), tile))

        return candidates

    def _best_spawn_candidates(
        self,
        candidates: list[tuple[float, tuple[int, int]]],
    ) -> list[tuple[float, tuple[int, int]]]:
        """Return all candidates tied for the best spawn score."""
        best_score = max(score for score, _ in candidates)
        return [
            (score, position)
            for score, position in candidates
            if score == best_score
        ]

    def _is_valid_spawn_candidate(
        self,
        position: tuple[int, int],
        enforce_distance: bool,
        reachable_tiles: set[tuple[int, int]],
    ) -> bool:
        """Return True when a tile satisfies spawn placement constraints."""
        if position not in reachable_tiles:
            return False
        if position in self._get_spawn_blocked_tiles():
            return False
        if enforce_distance and any(
            self._manhattan(position, anchor) < self.MIN_SPAWN_PROGRESS_DISTANCE
            for anchor in self._get_spawn_distance_anchors()
        ):
            return False

        return True

    def _get_spawn_reachable_tiles(self) -> set[tuple[int, int]]:
        """Return walkable tiles in the main reachable dungeon component."""
        walkable_tiles = self._collect_walkable_tiles()
        if not walkable_tiles:
            return set()

        return build_reachable_tiles(
            self._grid,
            self._layout_anchor_point(walkable_tiles),
        )

    def _score_spawn_position(self, position: tuple[int, int]) -> float:
        """Score spawn candidates by distance from progression locations."""
        key_positions = self._get_key_item_positions()
        score = 0.0
        score += self._manhattan(position, self._layout.boss_room_center) * 2.0
        score += self._manhattan(position, self._layout.laboratory_room) * 1.5

        for key_type in ("Key 3", "Key 4"):
            if key_type in key_positions:
                score += self._manhattan(position, key_positions[key_type]) * 1.75

        for puzzle_room in self._layout.key_rooms:
            score += self._manhattan(position, puzzle_room) * 1.25

        return score

    def _get_spawn_blocked_tiles(self) -> set[tuple[int, int]]:
        """Return tiles the player may not spawn inside."""
        blocked = self._get_forbidden_placement_tiles()
        blocked.update((x, y) for x, y, _ in self._layout.items)
        blocked.update((x, y) for x, y, _ in self._layout.traps)
        return blocked

    def _get_spawn_distance_anchors(self) -> list[tuple[int, int]]:
        """Return progression locations that spawn should be far away from."""
        anchors = [
            self._layout.boss_room_center,
            self._layout.laboratory_room,
            *self._layout.key_rooms,
        ]
        key_positions = self._get_key_item_positions()

        for key_type in ("Key 3", "Key 4"):
            if key_type in key_positions:
                anchors.append(key_positions[key_type])

        return anchors

    def _get_key_item_positions(self) -> dict[str, tuple[int, int]]:
        """Return current key item positions by item type."""
        return {
            item_type: (x, y)
            for x, y, item_type in self._layout.items
            if item_type.startswith("Key")
        }

    def _relocate_key_rooms(self) -> None:
        """Place Key #1 and Key #2 in reachable separated random rooms."""
        key_positions: list[tuple[int, int]] = []
        occupied = {
            (x, y)
            for x, y, item_type in self._layout.items
            if item_type not in ("Key 1", "Key 2")
        }

        for _ in range(self.PUZZLE_ROOM_COUNT):
            candidates = self._get_key_room_candidates(key_positions, occupied)
            if not candidates:
                candidates = self._get_relaxed_key_room_candidates(
                    key_positions,
                    occupied,
                )

            if not candidates:
                continue

            position = random.choice(candidates)
            key_positions.append(position)
            occupied.add(position)

        if len(key_positions) != self.PUZZLE_ROOM_COUNT:
            return

        self._layout.key_rooms = key_positions
        self._layout.puzzle_rooms = list(key_positions)
        for center_x, center_y in key_positions:
            self._carve_room(center_x, center_y, self.KEY_ROOM_SIZE)

        self._layout.items = [
            item
            for item in self._layout.items
            if item[2] not in ("Key 1", "Key 2")
        ]
        self._layout.items.extend(
            [
                (*key_positions[0], "Key 1"),
                (*key_positions[1], "Key 2"),
            ]
        )

    def _get_key_room_candidates(
        self,
        existing_keys: list[tuple[int, int]],
        occupied: set[tuple[int, int]],
    ) -> list[tuple[int, int]]:
        """Return strict candidates for Key #1 and Key #2 room centers."""
        return [
            tile
            for tile in self._collect_walkable_tiles()
            if tile not in occupied
            and self._is_valid_key_room_candidate(tile, existing_keys)
        ]

    def _get_relaxed_key_room_candidates(
        self,
        existing_keys: list[tuple[int, int]],
        occupied: set[tuple[int, int]],
    ) -> list[tuple[int, int]]:
        """Return fallback reachable candidates if strict room placement fails."""
        margin = self.KEY_ROOM_SIZE // 2
        return [
            tile
            for tile in self._collect_walkable_tiles()
            if tile not in occupied
            and margin <= tile[0] < self.GRID_WIDTH - margin
            and margin <= tile[1] < self.GRID_HEIGHT - margin
            and all(
                self._manhattan(tile, existing) >= self.MIN_KEY_ROOM_DISTANCE
                for existing in existing_keys
            )
        ]

    def _is_valid_key_room_candidate(
        self,
        tile: tuple[int, int],
        existing_keys: list[tuple[int, int]],
    ) -> bool:
        """Return True when a key room candidate satisfies placement rules."""
        margin = self.KEY_ROOM_SIZE // 2
        if not (margin <= tile[0] < self.GRID_WIDTH - margin):
            return False
        if not (margin <= tile[1] < self.GRID_HEIGHT - margin):
            return False
        if (
            self._manhattan(tile, self._layout.boss_room_center)
            < self.MIN_SPECIAL_ROOM_DISTANCE
        ):
            return False
        if (
            self._manhattan(tile, self._layout.laboratory_room)
            < self.MIN_SPECIAL_ROOM_DISTANCE
        ):
            return False
        if self._room_bounds_overlap(
            tile,
            [self._layout.boss_room_center],
            self.KEY_ROOM_SIZE,
            self.BOSS_ROOM_SIZE,
        ):
            return False
        if self._room_bounds_overlap(
            tile,
            [self._layout.laboratory_room],
            self.KEY_ROOM_SIZE,
            self.LABORATORY_ROOM_SIZE,
        ):
            return False
        if self._room_bounds_overlap(
            tile,
            existing_keys,
            self.KEY_ROOM_SIZE,
            self.KEY_ROOM_SIZE,
        ):
            return False

        return all(
            self._manhattan(tile, existing) >= self.MIN_KEY_ROOM_DISTANCE
            for existing in existing_keys
        )

    def _get_corner_region_tiles(
        self,
        walkable_tiles: list[tuple[int, int]],
        region_name: str | None = None,
    ) -> list[tuple[int, int]]:
        """Return walkable tiles inside one or all corner regions."""
        mid_x = self.GRID_WIDTH // 2
        mid_y = self.GRID_HEIGHT // 2
        regions: dict[str, list[tuple[int, int]]] = {
            "top-left": [],
            "top-right": [],
            "bottom-left": [],
            "bottom-right": [],
        }

        for x, y in walkable_tiles:
            if x < mid_x and y < mid_y:
                regions["top-left"].append((x, y))
            elif x >= mid_x and y < mid_y:
                regions["top-right"].append((x, y))
            elif x < mid_x and y >= mid_y:
                regions["bottom-left"].append((x, y))
            else:
                regions["bottom-right"].append((x, y))

        if region_name is not None:
            return regions[region_name]

        return [
            tile
            for tiles in regions.values()
            for tile in tiles
        ]

    def _generate_validated_traps(self) -> list[tuple[int, int, str]]:
        """Generate traps before final player spawn selection."""
        walkable_tiles = self._collect_walkable_tiles()
        forbidden = self._get_forbidden_placement_tiles()
        occupied = forbidden | {
            (x, y)
            for x, y, _ in self._layout.items
        }

        for _ in range(self.TRAP_VALIDATION_ATTEMPTS):
            traps: list[tuple[int, int, str]] = []
            local_occupied = set(occupied)

            for trap_type in ("Damage Trap", "Instant Death Trap"):
                candidates = [
                    tile
                    for tile in walkable_tiles
                    if tile not in local_occupied
                ]
                if not candidates:
                    break

                position = random.choice(candidates)
                traps.append((*position, trap_type))
                local_occupied.add(position)

            if len(traps) < 2:
                continue

            return traps

        return []

    def _compute_ucs_path(self) -> None:
        """Compute and store the UCS route from laboratory to boss room."""
        pathfinding_grid = self._build_pathfinding_grid(include_gate=True)
        start = self._layout.laboratory_room
        goal = self._layout.boss_room_center
        path, path_length, total_cost, nodes_expanded = ucs(
            start,
            goal,
            pathfinding_grid,
        )

        if path_length == 0:
            for candidate in self._get_boss_room_tiles(self._layout.boss_room_center):
                candidate_path, candidate_length, candidate_cost, candidate_expanded = ucs(
                    start,
                    candidate,
                    pathfinding_grid,
                )
                if candidate_length > 0:
                    path = candidate_path
                    path_length = candidate_length
                    total_cost = candidate_cost
                    nodes_expanded = candidate_expanded
                    break

        self._ucs_path = path
        self._ucs_path_length = path_length
        self._ucs_total_cost = total_cost
        self._ucs_nodes_expanded = nodes_expanded

    def _build_pathfinding_grid(self, include_gate: bool = False) -> list[list[int]]:
        """Return a UCS/BFS grid where 0 is walkable and 1 is a wall."""
        grid: list[list[int]] = []

        for y in range(self.GRID_HEIGHT):
            row: list[int] = []
            for x in range(self.GRID_WIDTH):
                tile = self._grid[y][x]
                if tile == FLOOR:
                    row.append(0)
                elif tile == GATE and include_gate:
                    row.append(0)
                else:
                    row.append(1)
            grid.append(row)

        return grid

    def _reposition_items_outside_special_rooms(self) -> None:
        """Ensure optimized items never spawn inside special rooms."""
        forbidden = self._get_forbidden_placement_tiles()
        occupied = forbidden.copy()
        occupied.update((x, y) for x, y, _ in self._layout.items)
        walkable_tiles = self._collect_walkable_tiles()

        updated_items: list[tuple[int, int, str]] = []
        for x, y, item_type in self._layout.items:
            if item_type in ("Key 1", "Key 2"):
                updated_items.append((x, y, item_type))
                continue
            if (x, y) not in forbidden:
                updated_items.append((x, y, item_type))
                continue

            candidates = [
                tile
                for tile in walkable_tiles
                if tile not in occupied
                and tile not in forbidden
            ]
            if not candidates:
                updated_items.append((x, y, item_type))
                continue

            replacement = random.choice(candidates)
            updated_items.append((*replacement, item_type))
            occupied.add(replacement)

        self._layout.items = updated_items

    def _validate_item_counts(self) -> None:
        """Remove item spawns that exceed the allowed maximum counts."""
        counts: dict[str, int] = {}
        validated_items: list[tuple[int, int, str]] = []

        for item in self._layout.items:
            item_type = item[2]
            max_count = self.item_max_counts.get(item_type)
            if max_count is None:
                validated_items.append(item)
                continue

            current_count = counts.get(item_type, 0)
            if current_count >= max_count:
                continue

            counts[item_type] = current_count + 1
            validated_items.append(item)

        self._layout.items = validated_items

    def _ensure_collectible_items_reachable(self) -> None:
        """Move items that landed on blocked or unreachable tiles."""
        reachable_tiles = build_reachable_tiles(self._grid, self._spawn_point)
        forbidden = self._get_forbidden_placement_tiles()
        trap_positions = {(x, y) for x, y, _ in self._layout.traps}
        occupied: set[tuple[int, int]] = set()
        repaired_items: list[tuple[int, int, str]] = []

        for x, y, item_type in self._layout.items:
            position = (x, y)
            if (
                self._is_collectible_position_valid(position, item_type, reachable_tiles)
                and position not in occupied
                and position not in trap_positions
            ):
                repaired_items.append((x, y, item_type))
                occupied.add(position)
                continue

            candidates = [
                tile
                for tile in reachable_tiles
                if tile not in occupied
                and tile not in trap_positions
                and self._is_collectible_position_valid(tile, item_type, reachable_tiles)
            ]
            if candidates and item_type not in ("Key 1", "Key 2"):
                candidates = [tile for tile in candidates if tile not in forbidden]
            if not candidates:
                candidates = [
                    tile
                    for tile in reachable_tiles
                    if tile not in occupied
                    and tile not in trap_positions
                    and self._grid[tile[1]][tile[0]] == FLOOR
                ]

            if not candidates:
                repaired_items.append((x, y, item_type))
                occupied.add(position)
                continue

            replacement = random.choice(candidates)
            repaired_items.append((*replacement, item_type))
            occupied.add(replacement)

        self._layout.items = repaired_items

    def _is_collectible_position_valid(
        self,
        position: tuple[int, int],
        item_type: str,
        reachable_tiles: set[tuple[int, int]],
    ) -> bool:
        """Return True when an item can be walked onto and collected."""
        x, y = position
        if position not in reachable_tiles:
            return False
        if not (0 <= x < self.GRID_WIDTH and 0 <= y < self.GRID_HEIGHT):
            return False
        if self._grid[y][x] != FLOOR:
            return False
        if item_type in ("Key 1", "Key 2"):
            return True
        return position not in self._get_forbidden_placement_tiles()

    def _get_forbidden_placement_tiles(self) -> set[tuple[int, int]]:
        """Return tiles reserved by boss, laboratory, and puzzle rooms."""
        forbidden = self._get_puzzle_room_tiles()
        forbidden.update(self._get_boss_room_tiles(self._layout.boss_room_center))
        forbidden.update(self._get_laboratory_room_tiles())
        return forbidden

    def _get_puzzle_room_tiles(
        self,
        centers: list[tuple[int, int]] | None = None,
    ) -> set[tuple[int, int]]:
        """Return all tiles occupied by puzzle rooms."""
        room_centers = centers if centers is not None else self._layout.key_rooms
        tiles: set[tuple[int, int]] = set()

        for center in room_centers:
            tiles.update(self._room_tiles(center, self.KEY_ROOM_SIZE))

        return tiles

    def _get_laboratory_room_tiles(self) -> set[tuple[int, int]]:
        """Return all tiles occupied by the laboratory room."""
        return self._room_tiles(
            self._layout.laboratory_room,
            self.LABORATORY_ROOM_SIZE,
        )

    def _room_tiles(
        self,
        center: tuple[int, int],
        room_size: int,
    ) -> set[tuple[int, int]]:
        """Return all grid tiles inside a square room."""
        center_x, center_y = center
        margin = room_size // 2
        tiles: set[tuple[int, int]] = set()

        for y in range(center_y - margin, center_y + margin + 1):
            for x in range(center_x - margin, center_x + margin + 1):
                if 0 <= x < self.GRID_WIDTH and 0 <= y < self.GRID_HEIGHT:
                    tiles.add((x, y))

        return tiles

    def _get_boss_room_tiles(self, center: tuple[int, int]) -> set[tuple[int, int]]:
        """Return all tiles inside a boss room centered on the given point."""
        return self._room_tiles(center, self.BOSS_ROOM_SIZE)

    def _room_bounds_overlap(
        self,
        center: tuple[int, int],
        existing_rooms: list[tuple[int, int]],
        room_size: int,
        existing_room_size: int,
    ) -> bool:
        """Return True when a proposed room overlaps an existing room."""
        margin = room_size // 2
        left = center[0] - margin
        right = center[0] + margin
        top = center[1] - margin
        bottom = center[1] + margin

        for existing_center in existing_rooms:
            existing_margin = existing_room_size // 2
            existing_left = existing_center[0] - existing_margin
            existing_right = existing_center[0] + existing_margin
            existing_top = existing_center[1] - existing_margin
            existing_bottom = existing_center[1] + existing_margin

            if left <= existing_right and right >= existing_left:
                if top <= existing_bottom and bottom >= existing_top:
                    return True

        return False

    def _print_debug_output(self) -> None:
        """Print placement and UCS debug information."""
        key_positions = {
            item_type: (x, y)
            for x, y, item_type in self._layout.items
            if item_type.startswith("Key")
        }

        print(f"Selected Spawn: {self._spawn_point}")
        print(f"Spawn Score: {self._spawn_score:.2f}")
        print(f"Spawn Region: {self._spawn_region}")
        print(f"Boss Room: {self._layout.boss_room_center}")
        print(f"Laboratory: {self._layout.laboratory_room}")
        print(f"Key #1: {key_positions.get('Key 1', self._spawn_point)}")
        print(f"Key #2: {key_positions.get('Key 2', self._spawn_point)}")
        print(f"Key #3: {key_positions.get('Key 3', self._spawn_point)}")
        print(f"Key #4: {key_positions.get('Key 4', self._spawn_point)}")
        print(f"Laboratory -> Boss path length: {self._ucs_path_length}")

    def _collect_walkable_tiles(self) -> list[tuple[int, int]]:
        """Return all floor tiles usable for placement."""
        tiles: list[tuple[int, int]] = []

        for y in range(self.GRID_HEIGHT):
            for x in range(self.GRID_WIDTH):
                if self._grid[y][x] != FLOOR:
                    continue
                tiles.append((x, y))

        return tiles

    def _carve_room(self, center_x: int, center_y: int, room_size: int) -> None:
        """Carve a room centered on an existing floor tile."""
        margin = room_size // 2

        for y in range(center_y - margin, center_y + margin + 1):
            for x in range(center_x - margin, center_x + margin + 1):
                if 0 <= x < self.GRID_WIDTH and 0 <= y < self.GRID_HEIGHT:
                    self._grid[y][x] = FLOOR

    def _default_boss_center(self) -> tuple[int, int]:
        """Return the legacy default boss room center used for HC constraints."""
        room_right = self.GRID_WIDTH - 2
        room_left = room_right - self.BOSS_ROOM_SIZE + 1
        room_top = self.GRID_HEIGHT // 2 - self.BOSS_ROOM_SIZE // 2
        room_bottom = room_top + self.BOSS_ROOM_SIZE - 1
        return (room_left + room_right) // 2, (room_top + room_bottom) // 2

    def _default_boss_bounds(self) -> tuple[int, int, int, int]:
        """Return bounds for the default boss room envelope."""
        center_x, center_y = self._default_boss_center()
        margin = self.BOSS_ROOM_SIZE // 2
        return (
            center_x - margin,
            center_y - margin,
            center_x + margin,
            center_y + margin,
        )

    def _build_boss_room(self, center: tuple[int, int]) -> dict[str, tuple[int, int, int, int]]:
        """Create a compact 3x3 boss entrance room with four random gates and a cleared ring."""
        center_x, center_y = center
        margin = self.BOSS_ROOM_ENTRANCE_SIZE // 2
        room_left = center_x - margin
        room_right = center_x + margin
        room_top = center_y - margin
        room_bottom = center_y + margin

        # Build a raised wall envelope for the 3x3 room structure
        for y in range(room_top - 1, room_bottom + 2):
            for x in range(room_left - 1, room_right + 2):
                if 0 <= x < self.GRID_WIDTH and 0 <= y < self.GRID_HEIGHT:
                    self._grid[y][x] = WALL

        for y in range(room_top, room_bottom + 1):
            for x in range(room_left, room_right + 1):
                if 0 <= x < self.GRID_WIDTH and 0 <= y < self.GRID_HEIGHT:
                    self._grid[y][x] = WALL

        if 0 <= center_x < self.GRID_WIDTH and 0 <= center_y < self.GRID_HEIGHT:
            self._grid[center_y][center_x] = FLOOR

        # Carve a 2-block wide floor area around the 3x3 boss room structure
        for y in range(center_y - 3, center_y + 4):
            for x in range(center_x - 3, center_x + 4):
                if 0 <= x < self.GRID_WIDTH and 0 <= y < self.GRID_HEIGHT:
                    # Exclude the 3x3 boss room structure itself
                    if not (room_left <= x <= room_right and room_top <= y <= room_bottom):
                        self._grid[y][x] = FLOOR

        corridor_directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        random.shuffle(corridor_directions)
        entrance_count = len(corridor_directions) # Set to 4 to place gates/paths in all directions
        gate_positions: list[tuple[int, int]] = []

        for direction in corridor_directions[:entrance_count]:
            dx, dy = direction
            gate_x = center_x + margin * dx
            gate_y = center_y + margin * dy
            if 0 <= gate_x < self.GRID_WIDTH and 0 <= gate_y < self.GRID_HEIGHT:
                self._grid[gate_y][gate_x] = GATE
                gate_positions.append((gate_x, gate_y))

            # Carve longer corridors (steps 2 to 5) to connect to the rest of the maze
            for step in range(2, 6):
                cx = center_x + step * dx
                cy = center_y + step * dy
                if 0 <= cx < self.GRID_WIDTH and 0 <= cy < self.GRID_HEIGHT:
                    self._grid[cy][cx] = FLOOR

        if not gate_positions:
            gate_x = room_left - 1
            gate_y = center_y
            if 0 <= gate_x < self.GRID_WIDTH and 0 <= gate_y < self.GRID_HEIGHT:
                self._grid[gate_y][gate_x] = GATE
                gate_positions.append((gate_x, gate_y))

        primary_gate = gate_positions[0]
        secondary_gates = gate_positions[1:]
        self.gate = Gate(primary_gate, additional_positions=secondary_gates)
        return {
            "bounds": (room_left, room_top, room_right, room_bottom),
        }

    def _ensure_boss_reachable(self) -> None:
        """Ensure there is a walkable path from the laboratory to the boss.

        If no path exists (due to aggressive carving or gate placement),
        carve a straight corridor from the laboratory center toward the gate
        and open floor tiles along the way so pathfinding can reach it.
        """
        from collections import deque

        # Build a pathfinding grid that treats the gate as walkable.
        grid = self._build_pathfinding_grid(include_gate=True)
        start = self._layout.laboratory_room
        boss_tiles = self._room_tiles(
            self._layout.boss_room_center,
            self.BOSS_ROOM_ENTRANCE_SIZE,
        )

        q = deque([start])
        visited = {start}

        found = False
        while q:
            x, y = q.popleft()
            if (x, y) in boss_tiles:
                found = True
                break

            for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
                nx, ny = x + dx, y + dy
                if 0 <= nx < self.GRID_WIDTH and 0 <= ny < self.GRID_HEIGHT:
                    if grid[ny][nx] == 0 and (nx, ny) not in visited:
                        visited.add((nx, ny))
                        q.append((nx, ny))

        if found:
            return

        # No path found: carve a straight corridor from the laboratory to the gate.
        gate_x, gate_y = self.gate.position
        cx, cy = start

        # Step horizontally then vertically toward the gate, carving floors.
        while (cx, cy) != (gate_x, gate_y):
            if cx < gate_x:
                cx += 1
            elif cx > gate_x:
                cx -= 1
            elif cy < gate_y:
                cy += 1
            elif cy > gate_y:
                cy -= 1

            if 0 <= cx < self.GRID_WIDTH and 0 <= cy < self.GRID_HEIGHT:
                self._grid[cy][cx] = FLOOR

        # Ensure every gate tile remains a gate (not overwritten).
        for gx, gy in self.gate.positions:
            if 0 <= gx < self.GRID_WIDTH and 0 <= gy < self.GRID_HEIGHT:
                self._grid[gy][gx] = GATE

    def _manhattan(
        self,
        first: tuple[int, int],
        second: tuple[int, int],
    ) -> int:
        """Return Manhattan distance between two grid points."""
        return abs(first[0] - second[0]) + abs(first[1] - second[1])

    def render(self, surface: pygame.Surface) -> None:
        """Draw all floor and wall tiles onto the given surface."""
        tile_size = self.TILE_SIZE
        for y in range(self.GRID_HEIGHT):
            for x in range(self.GRID_WIDTH):
                tile = self._grid[y][x]
                rect = pygame.Rect(
                    x * tile_size,
                    y * tile_size,
                    tile_size,
                    tile_size,
                )

                # Boss-room walls use the standard wall sprite when available
                if tile == WALL and self.is_boss_room_tile(x, y):
                    icon = get_named_icon("wall", tile_size)
                    if icon:
                        surface.blit(icon, rect.topleft)
                        continue
                    color = self.WALL_COLOR
                    pygame.draw.rect(surface, color, rect)
                    continue

                # Standard tile colors / gate handling
                if tile == FLOOR:
                    color = self.FLOOR_COLOR
                    if self.is_puzzle_room_tile(x, y):
                        color = self.KEY_ROOM_COLOR
                    if self.is_laboratory_room_tile(x, y):
                        color = self.LABORATORY_FLOOR_COLOR
                    if self.is_boss_room_tile(x, y):
                        color = self.BOSS_ROOM_COLOR
                    pygame.draw.rect(surface, color, rect)
                elif tile == GATE:
                    color = self.gate.get_color()
                    pygame.draw.rect(surface, color, rect)
                    pygame.draw.rect(surface, (151, 64, 74), rect, 2)
                    gate_icon = get_named_icon("door", tile_size + 12)
                    if gate_icon:
                        gw, gh = gate_icon.get_size()
                        gx = rect.x + (tile_size - gw) // 2
                        gy = rect.y + (tile_size - gh) // 2
                        surface.blit(gate_icon, (gx, gy))
                    else:
                        inner = rect.inflate(-8, -8)
                        pygame.draw.rect(surface, (18, 16, 22), inner)
                else:
                    icon = get_named_icon("wall", tile_size)
                    if icon:
                        surface.blit(icon, rect.topleft)
                    else:
                        pygame.draw.rect(surface, self.WALL_COLOR, rect)

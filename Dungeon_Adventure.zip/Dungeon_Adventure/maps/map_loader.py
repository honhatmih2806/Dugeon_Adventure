"""Map loading from assets."""


class MapLoader:
    """Loads dungeon map data from asset files."""

    def __init__(self) -> None:
        """Initialize the map loader."""
        pass

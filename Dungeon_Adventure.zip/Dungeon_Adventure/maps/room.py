"""Individual dungeon room representation."""


class Room:
    """Represents a single room within the dungeon."""

    def __init__(self) -> None:
        """Initialize the room."""
        pass

"""Fog of war visibility system."""

import pygame

from game.player import Player


class FogOfWar:
    """Controls tile visibility based on player exploration and torch range."""

    REVEAL_RADIUS: int = 5
    HIDDEN_COLOR: tuple[int, int, int] = (0, 0, 0)

    def __init__(self, width: int, height: int) -> None:
        """Initialize fog for a grid of the given width and height."""
        self._width = width
        self._height = height
        self._revealed: list[list[bool]] = [
            [False for _ in range(width)] for _ in range(height)
        ]

    def update(self, player: Player, dungeon: object = None, boss_visible: bool = True) -> None:
        """Reveal tiles within reveal radius of the player."""
        player_x, player_y = player.grid_position()
        reveal_radius = getattr(player, "vision", self.REVEAL_RADIUS)
        radius_sq = reveal_radius * reveal_radius

        for y_offset in range(-reveal_radius, reveal_radius + 1):
            y = player_y + y_offset
            if y < 0 or y >= self._height:
                continue

            for x_offset in range(-reveal_radius, reveal_radius + 1):
                if x_offset * x_offset + y_offset * y_offset > radius_sq:
                    continue

                x = player_x + x_offset
                if 0 <= x < self._width:
                    # Skip revealing if it's a boss room tile and boss is not visible
                    if dungeon is not None and not boss_visible:
                        if hasattr(dungeon, "is_boss_room_tile") and dungeon.is_boss_room_tile(x, y):
                            continue
                    self._revealed[y][x] = True

    def is_revealed(self, x: int, y: int) -> bool:
        """Return True if the tile at (x, y) has been revealed."""
        if x < 0 or y < 0 or x >= self._width or y >= self._height:
            return False
        return self._revealed[y][x]

    def render(self, surface: pygame.Surface, tile_size: int) -> None:
        """Draw black overlays on tiles that remain unseen."""
        for y in range(self._height):
            for x in range(self._width):
                if self._revealed[y][x]:
                    continue

                rect = pygame.Rect(
                    x * tile_size,
                    y * tile_size,
                    tile_size,
                    tile_size,
                )
                pygame.draw.rect(surface, self.HIDDEN_COLOR, rect)

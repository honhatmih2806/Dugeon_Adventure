"""Dark Fantasy boss arena map used when the player teleports into the boss fight.

This creates a small enclosed arena with one strong enemy and 3 sealing crystals.
"""

from __future__ import annotations
import random
from typing import Dict, List, Tuple, Set, TYPE_CHECKING
import pygame

from game.boss import BossEnemy
from assets.sprite_manager import get_named_icon
from ai.min_conflicts_boss import MinConflictsBoss

if TYPE_CHECKING:
    from game.player import Player
    from maps.fog_of_war import FogOfWar


class CrystalEntity:
    """A crystal entity that player can attack and destroy to regain status."""

    def __init__(self, color: str, position: Tuple[int, int], hp: int, color_rgb: Tuple[int, int, int], description: str) -> None:
        self.color_name = color
        self.x, self.y = position
        self.hp = hp
        self.max_hp = hp
        self.color_rgb = color_rgb
        self.description = description
        self.is_alive = True

    def grid_position(self) -> Tuple[int, int]:
        """Return the grid coordinates of the crystal."""
        return self.x, self.y

    def take_damage(self, amount: int) -> None:
        """Inflict damage on the crystal."""
        if not self.is_alive:
            return
        self.hp = max(0, self.hp - amount)
        print(f"[COMBAT] {self.color_name.title()} Crystal took {amount} damage! HP: {self.hp}/{self.max_hp}")
        if self.hp == 0:
            self.is_alive = False


class BossArena:
    GRID_WIDTH: int = 11
    GRID_HEIGHT: int = 9

    FLOOR = 0
    WALL = 1

    def __init__(self, tile_size: int) -> None:
        self.TILE_SIZE = tile_size
        # Build grid: border walls and inner floor
        self._grid = [[self.WALL for _ in range(self.GRID_WIDTH)] for _ in range(self.GRID_HEIGHT)]
        for y in range(1, self.GRID_HEIGHT - 1):
            for x in range(1, self.GRID_WIDTH - 1):
                self._grid[y][x] = self.FLOOR

        self._spawn = (2, 4) # Spawn player safely on the left side
        cx = self.GRID_WIDTH // 2
        cy = self.GRID_HEIGHT // 2

        # Spawn Boss at center
        self.boss = BossEnemy(cx, cy, home=(cx, cy))
        self.boss.max_hp = 80
        self.boss.hp = self.boss.max_hp
        self.boss.CONTACT_DAMAGE = 6
        self.boss.detection_radius = 4

        # Generate 3 crystal positions equidistant from the boss
        # Possible directions (North, South, East, West) at distance 3
        possible_positions = {
            "north": (cx, cy - 3),
            "south": (cx, cy + 3),
            "west": (cx - 3, cy),
            "east": (cx + 3, cy)
        }
        
        # Pick 3 random directions out of the 4
        chosen_dirs = random.sample(list(possible_positions.keys()), 3)
        positions = [possible_positions[d] for d in chosen_dirs]

        self.crystals: Dict[str, dict] = {
            "red": {
                "position": positions[0],
                "intact": True,
                "color": (220, 60, 60),
                "description": "Red crystal: seals Attack power.",
            },
            "green": {
                "position": positions[1],
                "intact": True,
                "color": (60, 220, 80),
                "description": "Green crystal: seals Vision range.",
            },
            "blue": {
                "position": positions[2],
                "intact": True,
                "color": (60, 100, 220),
                "description": "Blue crystal: seals Stamina recovery.",
            },
        }

        # Initialize Crystal Entities (all start with 2 HP)
        self.crystal_entities: Dict[str, CrystalEntity] = {}
        for color, info in self.crystals.items():
            self.crystal_entities[color] = CrystalEntity(
                color=color,
                position=info["position"],
                hp=2,
                color_rgb=info["color"],
                description=info["description"]
            )

        # Active enemies list (combat targets)
        self.enemies: List[pygame.sprite.Sprite | BossEnemy | CrystalEntity] = [
            self.boss,
            self.crystal_entities["red"],
            self.crystal_entities["green"],
            self.crystal_entities["blue"]
        ]

        self._first_entry_shown = False
        self.entry_messages: List[str] = []
        self.crystal_protection_active = False
        
        # Min-Conflicts Suggestion Tool
        self.min_conflicts_engine = MinConflictsBoss()
        self.current_recommendation = ""
        self.current_decision = ""
        self.recommended_sequence: List[str] = []
        self._recommendation_timer = 0.0

        # Dark Fantasy Particles
        self.particles: List[dict] = []
        for _ in range(25):
            self.particles.append({
                "x": random.randint(tile_size, (self.GRID_WIDTH - 1) * tile_size),
                "y": random.randint(tile_size, (self.GRID_HEIGHT - 1) * tile_size),
                "vx": random.uniform(-10, 10),
                "vy": random.uniform(-15, -5),
                "alpha": random.randint(50, 180),
                "size": random.randint(2, 4)
            })

    def is_walkable(self, x: int, y: int) -> bool:
        if x < 0 or y < 0 or x >= self.GRID_WIDTH or y >= self.GRID_HEIGHT:
            return False
        return self._grid[y][x] == self.FLOOR

    def get_spawn_point(self) -> Tuple[int, int]:
        return self._spawn

    def get_crystal_color_at(self, x: int, y: int) -> str | None:
        for color, info in self.crystals.items():
            if info["position"] == (x, y):
                return color
        return None

    @property
    def active_boss_buffs(self) -> Set[str]:
        """Compute boss buffs dynamically based on broken/intact crystals.
        
        Rules:
        - Boss has Attack buff if: Red intact AND (Green or Blue broken)
        - Boss has Stamina buff if: Blue intact AND (Red or Green broken)
        - Boss has Vision buff if: Green intact AND (Red or Blue broken)
        """
        buffs = set()
        red_intact = self.crystals["red"]["intact"]
        green_intact = self.crystals["green"]["intact"]
        blue_intact = self.crystals["blue"]["intact"]
        
        any_broken = (not red_intact) or (not green_intact) or (not blue_intact)
        
        if red_intact and any_broken:
            buffs.add("attack")
        if blue_intact and any_broken:
            buffs.add("stamina")
        if green_intact and any_broken:
            buffs.add("vision")
            
        return buffs

    def destroy_crystal(self, color: str) -> bool:
        if color not in self.crystals:
            return False
        if not self.crystals[color]["intact"]:
            return False

        self.crystals[color]["intact"] = False
        self.crystal_entities[color].is_alive = False
        print(f"[BOSS ROOM] {color.upper()} crystal destroyed!")

        # Dynamic Crystal Scaling: crystals become harder as you break them
        destroyed_count = sum(1 for c in self.crystals.values() if not c["intact"])
        next_hp = 4 if destroyed_count == 1 else 6
        
        for c_color, c_ent in self.crystal_entities.items():
            if c_ent.is_alive:
                c_ent.max_hp = next_hp
                c_ent.hp = next_hp
                print(f"[BOSS ROOM] Remaining crystal {c_color.title()} hardened! HP increased to {next_hp}.")

        # Send boss to guard the location of destroyed crystal
        self.boss.activate_defense(self.crystals[color]["position"])
        return True

    def update(self, player: "Player", dt: float, fog: "FogOfWar" | None = None) -> None:
        if not self.boss.is_alive or not player:
            return

        # Perform Debuff message on first entering the boss room
        if not self._first_entry_shown:
            self.entry_messages = [
                "Boss Room Debuff: Attack -2, Vision -2, Stamina capped at 100, Speed slowed!",
                "Break crystals to reclaim your stats! (Green -> Max Stamina 200, Blue -> Vision, Red -> Attack)",
                "Once all 3 crystals are broken, all debuffs will be lost!"
            ]
            for msg in self.entry_messages:
                print(f"[DEBUFF ALERT] {msg}")
            self._first_entry_shown = True

        # Check if any crystal entities died from sword attack
        for color, crystal in self.crystal_entities.items():
            if not crystal.is_alive and self.crystals[color]["intact"]:
                self.destroy_crystal(color)

        # Dynamic Debuff Application
        red_broken = not self.crystals["red"]["intact"]
        green_broken = not self.crystals["green"]["intact"]
        blue_broken = not self.crystals["blue"]["intact"]
        all_broken = red_broken and green_broken and blue_broken

        if all_broken:
            # All debuffs lost!
            player.attack = player.base_attack
            player.vision = player.base_vision
            player.max_stamina = 200 if green_broken else 150
            player.move_cooldown_modifier = 0.0
        else:
            # Apply dynamic debuffs:
            player.attack = player.base_attack if red_broken else max(1, player.base_attack - 2)
            player.vision = player.base_vision if blue_broken else max(1, player.base_vision - 2)
            player.max_stamina = 200 if green_broken else 100
            player.current_stamina = min(player.max_stamina, player.current_stamina)
            player.move_cooldown_modifier = 0.15 # speed low 1 all time

        # Update remaining enemies targets
        self.enemies = [enemy for enemy in self.enemies if enemy.is_alive]

        # Calculate active buffs and apply to boss
        active_buffs = self.active_boss_buffs
        self.boss.CONTACT_DAMAGE = 10 if "attack" in active_buffs else 6
        self.boss.MOVE_COOLDOWN = 0.20 if "stamina" in active_buffs else 0.35
        self.boss.detection_radius = 8 if "vision" in active_buffs else 4

        # Dynamic Fog of war radius (reveal radius = 1 if debuffed, else full player vision)
        if fog is not None:
            if player.vision < player.base_vision:
                fog.REVEAL_RADIUS = 1
            else:
                fog.REVEAL_RADIUS = player.vision
            fog.update(player)

        # Run Min-Conflicts engine recommendation
        self._recommendation_timer += dt
        if self._recommendation_timer >= 0.5 or not self.current_recommendation:
            self._recommendation_timer = 0.0
            intact_colors = {c for c, info in self.crystals.items() if info["intact"]}
            rec_target, rec_decision, rec_seq = self.min_conflicts_engine.evaluate_conflicts(
                player_attack=player.attack,
                player_vision=player.vision,
                player_stamina=player.stamina_stat,
                base_attack=player.base_attack,
                base_vision=player.base_vision,
                base_stamina=player.base_stamina,
                intact_crystals=intact_colors,
                boss_buffs=active_buffs
            )
            self.current_recommendation = rec_target
            self.current_decision = rec_decision
            self.recommended_sequence = rec_seq

        # Update Dark Fantasy Particles
        for p in self.particles:
            p["y"] += p["vy"] * dt
            p["x"] += p["vx"] * dt
            if p["y"] < self.TILE_SIZE:
                p["y"] = (self.GRID_HEIGHT - 1) * self.TILE_SIZE
                p["x"] = random.randint(self.TILE_SIZE, (self.GRID_WIDTH - 1) * self.TILE_SIZE)
                p["vx"] = random.uniform(-10, 10)
                p["vy"] = random.uniform(-15, -5)

        # Update boss
        self.boss.update(player, self, dt)

    def render(self, surface: pygame.Surface) -> None:
        # Draw Dark Floor (Caro pattern) and Tinted Red Walls (wall.png)
        tile_size = self.TILE_SIZE
        wall_icon = get_named_icon("wall", tile_size)
        tint = pygame.Surface((tile_size, tile_size), pygame.SRCALPHA)
        tint.fill((80, 15, 20, 120)) # Dark red translucent tint

        for y in range(self.GRID_HEIGHT):
            for x in range(self.GRID_WIDTH):
                rect = pygame.Rect(
                    x * tile_size,
                    y * tile_size,
                    tile_size,
                    tile_size,
                )
                if self._grid[y][x] == self.WALL:
                    if wall_icon:
                        surface.blit(wall_icon, rect.topleft)
                        surface.blit(tint, rect.topleft)
                    else:
                        pygame.draw.rect(surface, (40, 10, 15), rect)
                    pygame.draw.rect(surface, (100, 25, 30), rect, 1)
                else:
                    # Caro logic: alternate floor tile colors
                    if (x + y) % 2 == 0:
                        color = (12, 10, 14)
                    else:
                        color = (22, 18, 25)
                    pygame.draw.rect(surface, color, rect)

        # Render floating particles (embers)
        for p in self.particles:
            p_color = (130, 20, 30) # Red ashes
            pygame.draw.circle(surface, p_color, (int(p["x"]), int(p["y"])), p["size"])

        # Render crystals
        ticks = pygame.time.get_ticks()
        for color, info in self.crystals.items():
            if not info["intact"]:
                continue
            crystal_x, crystal_y = info["position"]
            
            # Pulse glowing aura underneath
            center = (
                crystal_x * self.TILE_SIZE + self.TILE_SIZE // 2,
                crystal_y * self.TILE_SIZE + self.TILE_SIZE // 2,
            )
            pulse_radius = int(self.TILE_SIZE // 2 + 3 * pygame.math.Vector2(0, 1).rotate(ticks / 5.0).x)
            
            # Draw semi-transparent aura
            aura = pygame.Surface((self.TILE_SIZE * 2, self.TILE_SIZE * 2), pygame.SRCALPHA)
            pygame.draw.circle(aura, (*info["color"], 60), (self.TILE_SIZE, self.TILE_SIZE), pulse_radius)
            surface.blit(aura, (center[0] - self.TILE_SIZE, center[1] - self.TILE_SIZE))
            
            # Draw scaled crystal icon from assets
            crystal_icon = get_named_icon(color, self.TILE_SIZE)
            if crystal_icon:
                surface.blit(crystal_icon, (crystal_x * self.TILE_SIZE + (self.TILE_SIZE - crystal_icon.get_width()) // 2,
                                            crystal_y * self.TILE_SIZE + (self.TILE_SIZE - crystal_icon.get_height()) // 2))
            else:
                # Fallback to nice circle
                radius = self.TILE_SIZE // 3
                pygame.draw.circle(surface, info["color"], center, radius)
                pygame.draw.circle(surface, (255, 255, 255), center, 3)

            # Render crystal HP bar above it if damaged
            ent = self.crystal_entities[color]
            if ent.hp < ent.max_hp:
                bar_w = self.TILE_SIZE - 12
                bar_h = 5
                bar_x = crystal_x * self.TILE_SIZE + 6
                bar_y = crystal_y * self.TILE_SIZE - 2
                
                pygame.draw.rect(surface, (50, 10, 10), (bar_x, bar_y, bar_w, bar_h))
                fill_w = int(bar_w * (ent.hp / ent.max_hp))
                pygame.draw.rect(surface, info["color"], (bar_x, bar_y, fill_w, bar_h))

"""Alpha-beta pruning adversarial search for Gomoku with dynamic board sizes and win conditions."""

from __future__ import annotations

from typing import Sequence

from ai.minimax import (
    BOSS,
    DIRECTIONS,
    EMPTY,
    PLAYER,
    check_winner,
)

WIN_SCORE: int = 100_000
LOSS_SCORE: int = -100_000


class AlphaBeta:
    """Minimax search with alpha-beta pruning, move ordering, and heuristics."""

    def __init__(self, max_depth: int = 3) -> None:
        """Initialize search depth for boss AI."""
        self._max_depth = max_depth

    def best_move(
        self,
        board: list[list[int]],
        ai_player: int,
        win_length: int = 4,
    ) -> tuple[int, int] | None:
        """Return the best grid move for ai_player."""
        _, move = self.search(board, ai_player, win_length=win_length)
        return move

    def search(
        self,
        board: list[list[int]],
        ai_player: int,
        depth: int | None = None,
        win_length: int = 4,
    ) -> tuple[int, tuple[int, int] | None]:
        """Run alpha-beta search and return (score, best_move)."""
        board_size = len(board)
        # Use depth 3 for LOW (6x6 board), and depth 5 for MEDIUM (15x15 board / "siêu khó").
        search_depth = depth if depth is not None else (3 if board_size <= 7 else 5)
        
        moves = self._ordered_moves(board, board_size)
        if not moves:
            return 0, None

        opponent = PLAYER if ai_player == BOSS else BOSS
        alpha = float("-inf")
        beta = float("inf")
        best_move_choice: tuple[int, int] | None = None
        best_score = float("-inf")

        for move in moves:
            x, y = move
            board[y][x] = ai_player
            score = self._minimax(
                board,
                search_depth - 1,
                False,
                ai_player,
                opponent,
                alpha,
                beta,
                win_length,
                board_size,
            )
            board[y][x] = EMPTY

            if score > best_score:
                best_score = score
                best_move_choice = move
            alpha = max(alpha, best_score)

        if best_move_choice is None:
            return 0, moves[0]
        return int(best_score), best_move_choice

    def _minimax(
        self,
        board: list[list[int]],
        depth: int,
        maximizing: bool,
        ai_player: int,
        opponent: int,
        alpha: float,
        beta: float,
        win_length: int,
        board_size: int,
    ) -> int:
        """Recursive alpha-beta minimax search."""
        winner = check_winner(board, win_length)
        if winner == ai_player:
            return WIN_SCORE + depth
        if winner == opponent:
            return LOSS_SCORE - depth
        if depth == 0 or not self._ordered_moves(board, board_size):
            return self._evaluate_board(board, ai_player, win_length, board_size)

        current_player = ai_player if maximizing else opponent
        if maximizing:
            value = float("-inf")
            for x, y in self._ordered_moves(board, board_size):
                board[y][x] = current_player
                value = max(
                    value,
                    self._minimax(
                        board,
                        depth - 1,
                        False,
                        ai_player,
                        opponent,
                        alpha,
                        beta,
                        win_length,
                        board_size,
                    ),
                )
                board[y][x] = EMPTY
                alpha = max(alpha, value)
                if beta <= alpha:
                    break
            return int(value)

        value = float("inf")
        for x, y in self._ordered_moves(board, board_size):
            board[y][x] = current_player
            value = min(
                value,
                self._minimax(
                    board,
                    depth - 1,
                    True,
                    ai_player,
                    opponent,
                    alpha,
                    beta,
                    win_length,
                    board_size,
                ),
            )
            board[y][x] = EMPTY
            beta = min(beta, value)
            if beta <= alpha:
                break
        return int(value)

    def _evaluate_board(self, board: Sequence[Sequence[int]], ai_player: int, win_length: int, board_size: int) -> int:
        """Heuristic evaluation independent from rendering."""
        opponent = PLAYER if ai_player == BOSS else BOSS
        score = 0
        center = board_size // 2

        occupied = []
        for y in range(board_size):
            for x in range(board_size):
                piece = board[y][x]
                if piece == EMPTY:
                    continue
                occupied.append((x, y))
                distance = abs(x - center) + abs(y - center)
                center_bonus = max(0, 3 - distance) * 2
                if piece == ai_player:
                    score += center_bonus
                else:
                    score -= center_bonus

        # Optimize: only evaluate empty cells adjacent to occupied tiles (far-away cells return 0 anyway)
        eval_cells = set()
        for ox, oy in occupied:
            for dy in range(-1, 2):
                for dx in range(-1, 2):
                    ex, ey = ox + dx, oy + dy
                    if 0 <= ex < board_size and 0 <= ey < board_size and board[ey][ex] == EMPTY:
                        eval_cells.add((ex, ey))

        for x, y in eval_cells:
            for dx, dy in DIRECTIONS:
                score += self._evaluate_line(
                    board,
                    x,
                    y,
                    dx,
                    dy,
                    ai_player,
                    opponent,
                    win_length,
                )

        return score

    def _evaluate_line(
        self,
        board: Sequence[Sequence[int]],
        x: int,
        y: int,
        dx: int,
        dy: int,
        ai_player: int,
        opponent: int,
        win_length: int,
    ) -> int:
        """Score potential sequences starting from an empty cell along one direction."""
        ai_count, ai_open = self._count_sequence(board, x, y, dx, dy, ai_player)
        opp_count, opp_open = self._count_sequence(board, x, y, dx, dy, opponent)

        score = 0
        if ai_count >= win_length:
            score += 50_000
        elif ai_count == win_length - 1 and ai_open == 2:
            score += 8_000
        elif ai_count == win_length - 2 and ai_open == 2:
            score += 800
        elif ai_count == win_length - 3 and ai_open >= 1:
            score += 80

        if opp_count >= win_length:
            score -= 60_000
        elif opp_count == win_length - 1 and opp_open == 2:
            score -= 12_000
        elif opp_count == win_length - 2 and opp_open == 2:
            score -= 1_200
        elif opp_count == win_length - 3 and opp_open >= 1:
            score -= 120

        return score

    def _count_sequence(
        self,
        board: Sequence[Sequence[int]],
        x: int,
        y: int,
        dx: int,
        dy: int,
        player: int,
    ) -> tuple[int, int]:
        """Count consecutive player stones and open ends around (x, y)."""
        size = len(board)
        count = 0
        open_ends = 0

        for direction in (-1, 1):
            cx, cy = x, y
            while 0 <= cx < size and 0 <= cy < size and board[cy][cx] == player:
                count += 1
                cx += dx * direction
                cy += dy * direction
            if 0 <= cx < size and 0 <= cy < size and board[cy][cx] == EMPTY:
                open_ends += 1

        return count, open_ends

    def _ordered_moves(self, board: Sequence[Sequence[int]], board_size: int) -> list[tuple[int, int]]:
        """Return empty cells ordered near existing stones for better pruning."""
        occupied = [
            (x, y)
            for y in range(board_size)
            for x in range(board_size)
            if board[y][x] != EMPTY
        ]
        if not occupied:
            center = board_size // 2
            return [(center, center)]

        candidates: set[tuple[int, int]] = set()
        for ox, oy in occupied:
            for dy in range(-1, 2):
                for dx in range(-1, 2):
                    x, y = ox + dx, oy + dy
                    if 0 <= x < board_size and 0 <= y < board_size and board[y][x] == EMPTY:
                        candidates.add((x, y))

        if not candidates:
            return [
                (x, y)
                for y in range(board_size)
                for x in range(board_size)
                if board[y][x] == EMPTY
            ]

        center = board_size // 2

        def move_priority(move: tuple[int, int]) -> tuple[int, int]:
            px, py = move
            nearest = min(abs(px - ox) + abs(py - oy) for ox, oy in occupied)
            center_distance = abs(px - center) + abs(py - center)
            return nearest, center_distance

        return sorted(candidates, key=move_priority)

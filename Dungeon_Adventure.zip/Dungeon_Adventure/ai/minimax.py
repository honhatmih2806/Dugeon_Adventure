"""Shared Gomoku board utilities for adversarial search with dynamic win conditions."""

from __future__ import annotations

from typing import Sequence

EMPTY: int = 0
BOSS: int = 1
PLAYER: int = 2

DIRECTIONS: tuple[tuple[int, int], ...] = (
    (1, 0),
    (0, 1),
    (1, 1),
    (1, -1),
)


def check_winner(board: Sequence[Sequence[int]], win_length: int = 4) -> int:
    """Return BOSS, PLAYER, or EMPTY when no winner is found."""
    size = len(board)
    for y in range(size):
        for x in range(size):
            piece = board[y][x]
            if piece == EMPTY:
                continue
            for dx, dy in DIRECTIONS:
                count = 1
                cx, cy = x + dx, y + dy
                while (
                    0 <= cx < size
                    and 0 <= cy < size
                    and board[cy][cx] == piece
                ):
                    count += 1
                    cx += dx
                    cy += dy

                if count >= win_length:
                    return piece
    return EMPTY


def is_board_full(board: Sequence[Sequence[int]]) -> bool:
    """Return True when no empty cells remain."""
    return all(cell != EMPTY for row in board for cell in row)

"""Uniform-cost search algorithm."""

from __future__ import annotations

import heapq

from ai.bfs import DIRECTIONS, _is_walkable, _neighbors, _reconstruct_path


def ucs(
    start: tuple[int, int],
    goal: tuple[int, int],
    grid: list[list[int]],
) -> tuple[list[tuple[int, int]], int, int, int]:
    """Find a lowest-cost path using uniform-cost search.

    Grid cells with value 0 are walkable; 1 marks walls.
    Each step costs 1. Returns path, path_length, total_cost, and nodes_expanded.
    """
    # Basic validation
    height = len(grid)
    width = len(grid[0]) if height else 0
    if width == 0 or height == 0:
        return [], 0, 0, 0

    def in_bounds(p: tuple[int, int]) -> bool:
        x, y = p
        return 0 <= x < width and 0 <= y < height

    if not in_bounds(start) or not in_bounds(goal):
        return [], 0, 0, 0

    if not _is_walkable(start, grid) or not _is_walkable(goal, grid):
        return [], 0, 0, 0

    if start == goal:
        return [start], 0, 0, 1

    open_set: list[tuple[int, tuple[int, int]]] = [(0, start)]
    came_from: dict[tuple[int, int], tuple[int, int] | None] = {start: None}
    g_score: dict[tuple[int, int], int] = {start: 0}
    closed: set[tuple[int, int]] = set()
    nodes_expanded = 0

    while open_set:
        cost, current = heapq.heappop(open_set)
        if current in closed:
            continue

        closed.add(current)
        nodes_expanded += 1

        if current == goal:
            path = _reconstruct_path(came_from, start, goal)
            total_cost = g_score.get(current, cost)
            return path, max(0, len(path) - 1), total_cost, nodes_expanded

        current_g = g_score.get(current, cost)

        for neighbor in _neighbors(current, width, height):
            if neighbor in closed:
                continue
            if not _is_walkable(neighbor, grid):
                continue

            step_cost = 1
            new_cost = current_g + step_cost
            if new_cost >= g_score.get(neighbor, float("inf")):
                continue

            came_from[neighbor] = current
            g_score[neighbor] = new_cost
            heapq.heappush(open_set, (new_cost, neighbor))

    return [], 0, 0, nodes_expanded


class UCS:
    """Implements uniform-cost search for pathfinding."""

    def search(
        self,
        start: tuple[int, int],
        goal: tuple[int, int],
        grid: list[list[int]],
    ) -> tuple[list[tuple[int, int]], int, int, int]:
        """Run UCS and return path, path length, total cost, and nodes expanded."""
        return ucs(start, goal, grid)

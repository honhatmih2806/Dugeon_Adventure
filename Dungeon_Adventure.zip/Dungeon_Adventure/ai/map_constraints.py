"""Shared dungeon placement constraints and fitness helpers.

Single source of truth for Hill Climbing, Simulated Annealing, and Min-Conflicts.
Contains no optimization algorithm logic.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

from ai.ucs import ucs

FLOOR: int = 0
WALL: int = 1
GATE: int = 2

MIN_SPAWN_DISTANCE: int = 10
MIN_HILL_SPREAD_DISTANCE: int = 5
MIN_ANNEALING_SPREAD_DISTANCE: int = 10
MIN_SPECIAL_ROOM_DISTANCE: int = 10
MIN_KEY_ROOM_DISTANCE: int = 8
HILL_IDEAL_SPAWN_DISTANCE: tuple[int, int] = (12, 32)
ANNEALING_IDEAL_SPAWN_DISTANCE: tuple[int, int] = (14, 34)
MIN_BOSS_PATH_LENGTH: int = 25
MIN_BOSS_PATH_TURNS: int = 5
MAX_STRAIGHT_SEGMENT: int = 8

HILL_CLIMB_ENTITIES: tuple[str, ...] = ("Key 3", "Sword", "Health Potion", "Torch")
ANNEALING_ENTITIES: tuple[str, ...] = ("Key 4", "Boss Room", "Laboratory Room")
REQUIRED_OBJECTIVES: tuple[str, ...] = (
    "Key 1",
    "Key 2",
    "Key 3",
    "Key 4",
    "Laboratory Room",
    "Boss Room",
)


@dataclass
class MapConstraintContext:
    """Placement state shared across all optimization stages."""

    grid: list[list[int]]
    grid_width: int
    grid_height: int
    layout_anchor: tuple[int, int]
    spawn_point: tuple[int, int] | None = None
    key_rooms: list[tuple[int, int]] = field(default_factory=list)
    items: list[tuple[int, int, str]] = field(default_factory=list)
    traps: list[tuple[int, int, str]] = field(default_factory=list)
    laboratory_room: tuple[int, int] = (0, 0)
    boss_room_center: tuple[int, int] = (0, 0)
    boss_room_size: int = 5
    laboratory_room_size: int = 3
    key_room_size: int = 3
    reserved_tiles: set[tuple[int, int]] = field(default_factory=set)
    forbidden_tiles: set[tuple[int, int]] = field(default_factory=set)
    boss_adjacent_tiles: set[tuple[int, int]] = field(default_factory=set)
    pathfinding_grid: list[list[int]] | None = None
    blocked_tiles: set[tuple[int, int]] = field(default_factory=set)


@dataclass
class ConflictReport:
    """Result of counting placement constraint violations."""

    total_conflicts: int
    conflicting_objects: dict[str, list[str]]


@dataclass
class HillClimbEvaluationContext:
    """Inputs required to score hill-climbing placements."""

    spawn_point: tuple[int, int]
    walkable_tiles: set[tuple[int, int]]
    reachable_tiles: set[tuple[int, int]]
    boss_adjacent_tiles: set[tuple[int, int]]
    reserved_tiles: set[tuple[int, int]]
    forbidden_tiles: set[tuple[int, int]]


@dataclass
class AnnealingEvaluationContext:
    """Inputs required to score simulated-annealing placements."""

    spawn_point: tuple[int, int]
    walkable_tiles: set[tuple[int, int]]
    reachable_tiles: set[tuple[int, int]]
    reserved_tiles: set[tuple[int, int]]
    forbidden_tiles: set[tuple[int, int]]
    special_room_centers: list[tuple[int, int]]
    boss_room_size: int
    grid_width: int
    grid_height: int
    laboratory_room_size: int
    pathfinding_grid: list[list[int]]


def manhattan(first: tuple[int, int], second: tuple[int, int]) -> int:
    """Return Manhattan distance between two grid points."""
    return abs(first[0] - second[0]) + abs(first[1] - second[1])


def is_floor(
    grid: list[list[int]],
    position: tuple[int, int],
    width: int,
    height: int,
) -> bool:
    """Return True when a grid cell is a floor tile."""
    x, y = position
    if x < 0 or y < 0 or x >= width or y >= height:
        return False
    return grid[y][x] == FLOOR


def reachable_tiles(
    grid: list[list[int]],
    start: tuple[int, int],
) -> set[tuple[int, int]]:
    """Return floor tiles reachable from start using BFS."""
    height = len(grid)
    width = len(grid[0]) if height else 0
    if not is_floor(grid, start, width, height):
        return set()

    reachable: set[tuple[int, int]] = set()
    queue: deque[tuple[int, int]] = deque([start])

    while queue:
        x, y = queue.popleft()
        if (x, y) in reachable:
            continue

        reachable.add((x, y))

        for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            next_position = (x + dx, y + dy)
            if next_position in reachable:
                continue
            if not is_floor(grid, next_position, width, height):
                continue
            queue.append(next_position)

    return reachable


def build_reachable_tiles(
    grid: list[list[int]],
    spawn_point: tuple[int, int],
) -> set[tuple[int, int]]:
    """Alias for reachable_tiles used by existing dungeon imports."""
    return reachable_tiles(grid, spawn_point)


def path_exists(
    grid: list[list[int]],
    start: tuple[int, int],
    goal: tuple[int, int],
) -> bool:
    """Return True when a walkable path exists between two floor tiles."""
    return goal in reachable_tiles(grid, start)


def room_tiles(center: tuple[int, int], room_size: int) -> set[tuple[int, int]]:
    """Return all grid tiles inside a square room."""
    center_x, center_y = center
    margin = room_size // 2
    tiles: set[tuple[int, int]] = set()

    for y in range(center_y - margin, center_y + margin + 1):
        for x in range(center_x - margin, center_x + margin + 1):
            tiles.add((x, y))

    return tiles


def boss_bounds(
    center_x: int,
    center_y: int,
    boss_room_size: int,
) -> tuple[int, int, int, int] | None:
    """Return boss room bounds for a center, or None when out of range."""
    margin = boss_room_size // 2
    return (
        center_x - margin,
        center_y - margin,
        center_x + margin,
        center_y + margin,
    )


def build_boss_adjacent_tiles(
    boss_bounds_rect: tuple[int, int, int, int],
    grid_width: int,
    grid_height: int,
) -> set[tuple[int, int]]:
    """Return tiles directly adjacent to a boss room envelope."""
    left, top, right, bottom = boss_bounds_rect
    adjacent: set[tuple[int, int]] = set()

    for y in range(top - 1, bottom + 2):
        for x in range(left - 1, right + 2):
            if 0 <= x < grid_width and 0 <= y < grid_height:
                adjacent.add((x, y))

    return adjacent


def room_overlap(
    center: tuple[int, int],
    room_size: int,
    other_center: tuple[int, int],
    other_room_size: int,
) -> bool:
    """Return True when two square rooms overlap."""
    margin = room_size // 2
    left = center[0] - margin
    right = center[0] + margin
    top = center[1] - margin
    bottom = center[1] + margin

    other_margin = other_room_size // 2
    other_left = other_center[0] - other_margin
    other_right = other_center[0] + other_margin
    other_top = other_center[1] - other_margin
    other_bottom = other_center[1] + other_margin

    return left <= other_right and right >= other_left and top <= other_bottom and bottom >= other_top


def distance_to_spawn(
    position: tuple[int, int],
    spawn_point: tuple[int, int],
) -> int:
    """Return Manhattan distance from a position to spawn."""
    return manhattan(position, spawn_point)


def distance_between_special_rooms(
    first: tuple[int, int],
    second: tuple[int, int],
) -> int:
    """Return Manhattan distance between two special-room centers."""
    return manhattan(first, second)


def inside_special_room(
    position: tuple[int, int],
    context: MapConstraintContext,
) -> bool:
    """Return True when a tile lies inside a puzzle, boss, or laboratory room."""
    if position in get_forbidden_room_tiles(context):
        return True
    for center in context.key_rooms:
        if position in room_tiles(center, context.key_room_size):
            return True
    return False


def get_forbidden_room_tiles(context: MapConstraintContext) -> set[tuple[int, int]]:
    """Return tiles reserved by boss and laboratory rooms."""
    forbidden = room_tiles(context.boss_room_center, context.boss_room_size)
    forbidden.update(room_tiles(context.laboratory_room, context.laboratory_room_size))
    for center in context.key_rooms:
        forbidden.update(room_tiles(center, context.key_room_size))
    return forbidden


def get_walkable_tiles(grid: list[list[int]]) -> set[tuple[int, int]]:
    """Return every floor tile in the grid."""
    tiles: set[tuple[int, int]] = set()
    for y, row in enumerate(grid):
        for x, tile in enumerate(row):
            if tile == FLOOR:
                tiles.add((x, y))
    return tiles


def find_floor_components(grid: list[list[int]]) -> list[set[tuple[int, int]]]:
    """Return connected floor components in the grid."""
    walkable = get_walkable_tiles(grid)
    components: list[set[tuple[int, int]]] = []
    visited: set[tuple[int, int]] = set()

    for tile in walkable:
        if tile in visited:
            continue
        component = reachable_tiles(grid, tile)
        components.append(component)
        visited.update(component)

    return components


def reachable(position: tuple[int, int], reachable_set: set[tuple[int, int]]) -> bool:
    """Return True when a position is inside a reachable tile set."""
    return position in reachable_set


def overlaps(positions: list[tuple[int, int]]) -> bool:
    """Return True when any two positions share the same tile."""
    return len(set(positions)) != len(positions)


def valid_distance(
    position: tuple[int, int],
    spawn_point: tuple[int, int],
    minimum: int = MIN_SPAWN_DISTANCE,
) -> bool:
    """Return True when a position respects minimum spawn distance."""
    return manhattan(position, spawn_point) >= minimum


def valid_room(
    center: tuple[int, int],
    room_size: int,
    grid_width: int,
    grid_height: int,
) -> bool:
    """Return True when a room center fits inside the grid with margin."""
    margin = room_size // 2
    return (
        margin <= center[0] < grid_width - margin
        and margin <= center[1] < grid_height - margin
    )


def valid_boss_center(center: tuple[int, int], context: AnnealingEvaluationContext) -> bool:
    """Return True when a boss room center fits inside the grid."""
    bounds = boss_bounds(center[0], center[1], context.boss_room_size)
    if bounds is None:
        return False

    left, top, right, bottom = bounds
    return (
        left >= 1
        and top >= 1
        and right < context.grid_width - 1
        and bottom < context.grid_height - 1
    )


def valid_item(
    position: tuple[int, int],
    item_type: str,
    context: MapConstraintContext,
    reachable_set: set[tuple[int, int]],
) -> bool:
    """Return True when an item placement satisfies shared constraints."""
    if position not in reachable_set:
        return False
    if not is_floor(context.grid, position, context.grid_width, context.grid_height):
        return False
    if item_type in ("Key 1", "Key 2"):
        return True
    if inside_special_room(position, context):
        return False
    if position in context.reserved_tiles:
        return False
    if position in context.blocked_tiles:
        return False
    return position not in context.forbidden_tiles


def valid_trap(
    position: tuple[int, int],
    context: MapConstraintContext,
    reachable_set: set[tuple[int, int]],
) -> bool:
    """Return True when a trap placement satisfies shared constraints."""
    if position not in reachable_set:
        return False
    if inside_special_room(position, context):
        return False
    if position in context.forbidden_tiles:
        return False
    return is_floor(context.grid, position, context.grid_width, context.grid_height)


def valid_special_room_separation(
    centers: list[tuple[int, int]],
    minimum: int = MIN_SPECIAL_ROOM_DISTANCE,
) -> bool:
    """Return True when all special-room centers respect separation distance."""
    for first_index, first_center in enumerate(centers):
        for second_center in centers[first_index + 1 :]:
            if manhattan(first_center, second_center) < minimum:
                return False
    return True


def spawn_distance_score(
    position: tuple[int, int],
    spawn_point: tuple[int, int],
    ideal_range: tuple[int, int],
) -> float:
    """Score distance from spawn, rewarding ideal-range placement."""
    distance = manhattan(position, spawn_point)
    min_distance, max_distance = ideal_range
    score = distance * 0.35

    if min_distance <= distance <= max_distance:
        score += 8.0
    elif distance < min_distance:
        score -= 12.0

    return score


def spread_score(
    positions: list[tuple[int, int]],
    minimum_spread: int,
    penalty_multiplier: float = 8.0,
    reward_multiplier: float = 0.9,
) -> float:
    """Reward spread between placements and penalize clusters."""
    score = 0.0
    for first_index, first_point in enumerate(positions):
        for second_point in positions[first_index + 1 :]:
            distance = manhattan(first_point, second_point)
            score += distance * reward_multiplier
            if distance < minimum_spread:
                score -= (minimum_spread - distance) * penalty_multiplier
    return score


def exploration_score(positions: list[tuple[int, int]], spawn_point: tuple[int, int]) -> float:
    """Reward coverage across map quadrants relative to spawn."""
    return quadrant_spread_bonus(positions, spawn_point)


def room_spacing_score(centers: list[tuple[int, int]]) -> float:
    """Reward separated special-room centers."""
    score = 0.0
    for first_index, first_center in enumerate(centers):
        for second_center in centers[first_index + 1 :]:
            score += manhattan(first_center, second_center) * 0.5
    return score


def quadrant_spread_bonus(
    points: list[tuple[int, int]],
    spawn_point: tuple[int, int],
    weight: float = 4.0,
) -> float:
    """Reward coverage across map quadrants relative to spawn."""
    spawn_x, spawn_y = spawn_point
    quadrants = {0, 1, 2, 3}

    for x, y in points:
        horizontal = 0 if x <= spawn_x else 1
        vertical = 0 if y <= spawn_y else 1
        quadrants.discard(horizontal + vertical * 2)

    return float(len({0, 1, 2, 3}) - len(quadrants)) * weight


def count_path_turns(path: list[tuple[int, int]]) -> int:
    """Count direction changes along a grid path."""
    if len(path) < 3:
        return 0

    turns = 0
    previous_direction: tuple[int, int] | None = None

    for first, second in zip(path, path[1:]):
        direction = (second[0] - first[0], second[1] - first[1])
        if previous_direction is not None and direction != previous_direction:
            turns += 1
        previous_direction = direction

    return turns


def longest_straight_segment(path: list[tuple[int, int]]) -> int:
    """Return the longest run of steps in a single direction."""
    if len(path) < 2:
        return 0

    longest = 1
    current = 1
    previous_direction: tuple[int, int] | None = None

    for first, second in zip(path, path[1:]):
        direction = (second[0] - first[0], second[1] - first[1])
        if direction == previous_direction:
            current += 1
        else:
            current = 1
        previous_direction = direction
        longest = max(longest, current)

    return longest


def path_quality_score(
    start: tuple[int, int],
    goal: tuple[int, int],
    grid: list[list[int]],
) -> float:
    """Reward longer, turning boss routes and penalize straight shortcuts."""
    path, path_length, _, _ = ucs(start, goal, grid)
    if path_length <= 0:
        return -500.0

    turns = count_path_turns(path)
    straight_segment = longest_straight_segment(path)
    score = path_length * 1.2 + turns * 4.0

    if path_length < MIN_BOSS_PATH_LENGTH:
        score -= (MIN_BOSS_PATH_LENGTH - path_length) * 8.0

    if turns < MIN_BOSS_PATH_TURNS:
        score -= (MIN_BOSS_PATH_TURNS - turns) * 10.0

    if straight_segment > MAX_STRAIGHT_SEGMENT:
        score -= (straight_segment - MAX_STRAIGHT_SEGMENT) * 6.0

    return score


def evaluate_hill_climb_placements(
    placements: dict[str, tuple[int, int]],
    context: HillClimbEvaluationContext,
) -> float:
    """Score a hill-climbing placement state. Higher is better."""
    positions = list(placements.values())

    if overlaps(positions):
        return -1000.0

    score = 0.0

    for entity, position in placements.items():
        if position not in context.walkable_tiles:
            return -1000.0
        if position in context.reserved_tiles:
            return -1000.0
        if position in context.forbidden_tiles:
            return -1000.0
        if position in context.boss_adjacent_tiles:
            score -= 60.0
        if not valid_distance(position, context.spawn_point):
            score -= 60.0
        if not reachable(position, context.reachable_tiles):
            score -= 120.0
        else:
            score += 15.0

        score += spawn_distance_score(
            position,
            context.spawn_point,
            HILL_IDEAL_SPAWN_DISTANCE,
        )

        if entity == "Key 3":
            score += manhattan(position, context.spawn_point) * 0.15

    score += spread_score(positions, MIN_HILL_SPREAD_DISTANCE)
    score += exploration_score(positions, context.spawn_point)
    return score


def evaluate_annealing_placements(
    placements: dict[str, tuple[int, int]],
    context: AnnealingEvaluationContext,
) -> float:
    """Score a simulated-annealing placement state. Higher is better."""
    positions = list(placements.values())

    if overlaps(positions):
        return -1000.0

    boss_center = placements.get("Boss Room")
    if boss_center is None or not valid_boss_center(boss_center, context):
        return -1000.0

    all_special_centers = list(context.special_room_centers)
    all_special_centers.extend(
        position
        for entity, position in placements.items()
        if entity in ("Boss Room", "Laboratory Room")
    )
    if not valid_special_room_separation(all_special_centers):
        return -1000.0

    score = 0.0
    boss_tiles = room_tiles(boss_center, context.boss_room_size)
    laboratory_center = placements.get("Laboratory Room")

    if laboratory_center is not None:
        laboratory_tiles = room_tiles(laboratory_center, context.laboratory_room_size)
        if laboratory_tiles & boss_tiles:
            return -1000.0
        if laboratory_tiles & context.forbidden_tiles:
            return -1000.0

    for entity, position in placements.items():
        if entity == "Boss Room":
            continue

        if position not in context.walkable_tiles:
            return -1000.0
        if position in context.reserved_tiles:
            return -1000.0
        if position in context.forbidden_tiles:
            return -1000.0
        if not reachable(position, context.reachable_tiles):
            return -1000.0
        if not valid_distance(position, context.spawn_point):
            return -1000.0

        spawn_distance = manhattan(position, context.spawn_point)
        score += spawn_distance * 0.6
        min_distance, max_distance = ANNEALING_IDEAL_SPAWN_DISTANCE
        if min_distance <= spawn_distance <= max_distance:
            score += 10.0

        if position in boss_tiles:
            return -1000.0

    boss_distance = manhattan(boss_center, context.spawn_point)
    if boss_distance < MIN_SPAWN_DISTANCE:
        return -1000.0
    score += boss_distance * 0.8

    score += spread_score(
        positions,
        MIN_ANNEALING_SPREAD_DISTANCE,
        penalty_multiplier=10.0,
        reward_multiplier=0.75,
    )
    score += exploration_score(positions, context.spawn_point) * 1.5

    if laboratory_center is not None:
        score += path_quality_score(
            laboratory_center,
            boss_center,
            context.pathfinding_grid,
        )

    return score


def get_objective_positions(context: MapConstraintContext) -> dict[str, tuple[int, int]]:
    """Return required gameplay objective positions."""
    objectives: dict[str, tuple[int, int]] = {
        "Laboratory Room": context.laboratory_room,
        "Boss Room": context.boss_room_center,
    }

    for index, center in enumerate(context.key_rooms):
        objectives[f"Key Room {index + 1}"] = center

    for x, y, item_type in context.items:
        if item_type.startswith("Key"):
            objectives[item_type] = (x, y)

    return objectives


def _resolve_reachability_origin(context: MapConstraintContext) -> tuple[int, int]:
    """Return the best tile for global reachability validation."""
    if context.spawn_point is not None:
        return context.spawn_point

    components = find_floor_components(context.grid)
    if not components:
        return context.layout_anchor

    main_component = max(components, key=len)
    if context.layout_anchor in main_component:
        return context.layout_anchor

    return next(iter(main_component))


def count_conflicts(context: MapConstraintContext) -> ConflictReport:
    """Count every violated placement constraint in the current dungeon state."""
    conflicting_objects: dict[str, list[str]] = {}
    origin = _resolve_reachability_origin(context)
    reachable_set = reachable_tiles(context.grid, origin)
    forbidden = get_forbidden_room_tiles(context)
    occupied: set[tuple[int, int]] = set()

    def add_conflict(object_id: str, reason: str) -> None:
        conflicting_objects.setdefault(object_id, []).append(reason)

    components = _main_maze_components(context)
    if len(components) > 1:
        add_conflict("maze", "disconnected_floor_regions")

    special_centers = list(context.key_rooms) + [
        context.laboratory_room,
        context.boss_room_center,
    ]
    if not valid_special_room_separation(special_centers):
        for index, center in enumerate(context.key_rooms):
            for other in special_centers:
                if center == other:
                    continue
                if manhattan(center, other) < MIN_SPECIAL_ROOM_DISTANCE:
                    add_conflict(f"key_room:{index}", "room_distance_violation")
        if manhattan(context.laboratory_room, context.boss_room_center) < MIN_SPECIAL_ROOM_DISTANCE:
            add_conflict("Laboratory Room", "room_distance_violation")

    for first_index, first_center in enumerate(context.key_rooms):
        for second_index, second_center in enumerate(context.key_rooms):
            if second_index <= first_index:
                continue
            if room_overlap(
                first_center,
                context.key_room_size,
                second_center,
                context.key_room_size,
            ):
                add_conflict(f"key_room:{first_index}", "special_room_overlap")
                add_conflict(f"key_room:{second_index}", "special_room_overlap")

    if room_overlap(
        context.laboratory_room,
        context.laboratory_room_size,
        context.boss_room_center,
        context.boss_room_size,
    ):
        add_conflict("Laboratory Room", "special_room_overlap")
        add_conflict("Boss Room", "special_room_overlap")

    for x, y, item_type in context.items:
        position = (x, y)
        if position in occupied:
            add_conflict(item_type, "duplicate_position")
        occupied.add(position)

        if position in context.blocked_tiles:
            add_conflict(item_type, "blocks_spawn")
        if not valid_item(position, item_type, context, reachable_set):
            if position not in reachable_set:
                add_conflict(item_type, "unreachable")
            elif inside_special_room(position, context) and item_type not in ("Key 1", "Key 2"):
                add_conflict(item_type, "inside_forbidden_room")
            else:
                add_conflict(item_type, "invalid_item_placement")

    for index, (x, y, trap_type) in enumerate(context.traps):
        position = (x, y)
        object_id = f"trap:{index}:{trap_type}"
        if position in occupied:
            add_conflict(object_id, "duplicate_position")
        if not valid_trap(position, context, reachable_set):
            if position not in reachable_set:
                add_conflict(object_id, "unreachable")
            elif inside_special_room(position, context):
                add_conflict(object_id, "inside_forbidden_room")
            else:
                add_conflict(object_id, "invalid_trap_placement")

        for objective_name, objective_position in get_objective_positions(context).items():
            if objective_position == position:
                add_conflict(object_id, "blocks_objective_route")

    for objective_name in REQUIRED_OBJECTIVES:
        objective_position = _required_objective_position(context, objective_name)
        if objective_position is None:
            add_conflict(objective_name, "missing_objective")
            continue
        if objective_position not in reachable_set and not _objective_reachable(
            context,
            origin,
            objective_name,
            objective_position,
        ):
            if objective_name == "Boss Room" and _boss_room_reachable(context, origin):
                continue
            add_conflict(objective_name, "unreachable")

    total_conflicts = sum(len(reasons) for reasons in conflicting_objects.values())
    return ConflictReport(total_conflicts, conflicting_objects)


def _required_objective_position(
    context: MapConstraintContext,
    objective_name: str,
) -> tuple[int, int] | None:
    """Return the tile used to validate reachability for one objective."""
    if objective_name == "Laboratory Room":
        return context.laboratory_room
    if objective_name == "Boss Room":
        return context.boss_room_center

    for x, y, item_type in context.items:
        if item_type == objective_name:
            return (x, y)

    if objective_name == "Key 1" and context.key_rooms:
        return context.key_rooms[0]
    if objective_name == "Key 2" and len(context.key_rooms) > 1:
        return context.key_rooms[1]

    return None


def _main_maze_components(context: MapConstraintContext) -> list[set[tuple[int, int]]]:
    """Return connected floor components excluding the enclosed boss-room interior."""
    boss_tiles = room_tiles(context.boss_room_center, context.boss_room_size)
    visited: set[tuple[int, int]] = set()
    components: list[set[tuple[int, int]]] = []

    for y, row in enumerate(context.grid):
        for x, tile in enumerate(row):
            if tile != FLOOR:
                continue
            position = (x, y)
            if position in boss_tiles or position in visited:
                continue

            component = reachable_tiles(context.grid, position)
            component -= boss_tiles
            if not component:
                continue

            components.append(component)
            visited.update(component)

    return components


def _boss_room_reachable(
    context: MapConstraintContext,
    origin: tuple[int, int],
) -> bool:
    """Return True when the boss room gate can be reached from the origin."""
    reachable_set = reachable_tiles(context.grid, origin)
    boss_tiles = room_tiles(context.boss_room_center, context.boss_room_size)

    for x, y in boss_tiles:
        for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            neighbor = (x + dx, y + dy)
            if neighbor in boss_tiles:
                continue
            if neighbor in reachable_set:
                return True
            if (
                0 <= neighbor[0] < context.grid_width
                and 0 <= neighbor[1] < context.grid_height
                and context.grid[neighbor[1]][neighbor[0]] == GATE
            ):
                return True

    return False


def _objective_reachable(
    context: MapConstraintContext,
    origin: tuple[int, int],
    objective_name: str,
    objective_position: tuple[int, int],
) -> bool:
    """Return True when an objective room or item can be reached from origin."""
    if objective_name in ("Boss Room", "Laboratory Room"):
        tiles = room_tiles(
            objective_position,
            context.boss_room_size if objective_name == "Boss Room" else context.laboratory_room_size,
        )
        return any(tile in reachable_tiles(context.grid, origin) for tile in tiles)

    return path_exists(context.grid, origin, objective_position)


def build_boss_candidates(
    boss_room_size: int,
    grid_width: int,
    grid_height: int,
) -> list[tuple[int, int]]:
    """Return valid boss room center positions that fit inside the grid."""
    margin = boss_room_size // 2
    candidates: list[tuple[int, int]] = []

    for center_y in range(margin + 1, grid_height - margin - 1):
        for center_x in range(margin + 4, grid_width - margin - 1):
            bounds = boss_bounds(center_x, center_y, boss_room_size)
            if bounds is None:
                continue

            left, _, _, _ = bounds
            if left <= 1:
                continue

            candidates.append((center_x, center_y))

    return candidates

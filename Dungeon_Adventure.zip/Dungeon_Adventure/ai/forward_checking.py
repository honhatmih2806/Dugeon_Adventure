"""Forward Checking constraint satisfaction solvers.

This module contains two solvers:
1. ForwardCheckingSolver: Solves the key-door puzzle (Key #1).
2. ForwardCheckingGateSolver: Solves the step-by-step lock-picking for the boss gate lock puzzle.
"""

from __future__ import annotations
import random
from typing import Generator, Tuple, List, Optional


class ForwardCheckingSolver:
    """Solves a small grid CSP with recursive forward checking / backtracking search."""

    def __init__(self, grid: list[list[int]]) -> None:
        """Initialize the solver with a copy of the puzzle grid."""
        self.grid = [row[:] for row in grid]

    def is_valid(self, row: int, col: int, value: int) -> bool:
        """Return True when value does not duplicate in the row or column."""
        for index in range(len(self.grid)):
            if self.grid[row][index] == value:
                return False
            if self.grid[index][col] == value:
                return False

        return True

    def solve(self) -> bool:
        """Solve the grid using recursive backtracking."""
        empty_cell = self._find_empty_cell()
        if empty_cell is None:
            return True

        row, col = empty_cell
        for value in range(1, len(self.grid) + 1):
            if not self.is_valid(row, col, value):
                continue

            self.grid[row][col] = value
            if self.solve():
                return True
            self.grid[row][col] = 0

        return False

    def _find_empty_cell(self) -> tuple[int, int] | None:
        """Return the next empty cell in the puzzle grid."""
        for row in range(len(self.grid)):
            for col in range(len(self.grid[row])):
                if self.grid[row][col] == 0:
                    return row, col

        return None


class ForwardCheckingGateSolver:
    """Manages the step-by-step forward-checking solver state and yields visualization data."""

    def __init__(self, correct_combo: List[int]) -> None:
        """Initialize the solver with the correct key sequence."""
        self.correct_combo = list(correct_combo)
        # Visual lock states: False = unlocked/unknown, True = locked/secured
        self.locked_status = [False, False, False, False]
        # Current keys assigned to each lock (0 to 3)
        self.assigned_keys: List[Optional[int]] = [None, None, None, None]
        # History of tried assignments for visualization
        self.log_message = "Ready to start decryption..."
        self.is_solved = False
        
        # Generator for step-by-step resolution
        self.step_generator: Optional[Generator[Tuple[str, int, int, bool, List[Optional[int]]], None, bool]] = None

    def start_solving(self) -> None:
        """Create the backtracking step generator.
        
        If locks are already locked, we preserve them and start from the next lock.
        """
        # Determine starting index based on already locked states
        start_idx = 0
        if self.locked_status[2]: # Lock 3 locked means locks 1, 2, and 3 are correct
            start_idx = 3
            self.assigned_keys[0] = self.correct_combo[0]
            self.assigned_keys[1] = self.correct_combo[1]
            self.assigned_keys[2] = self.correct_combo[2]
            self.locked_status[0] = True
            self.locked_status[1] = False # Lock 2 never visually locks
        elif self.locked_status[0]: # Lock 1 locked means lock 1 is correct
            start_idx = 1
            self.assigned_keys[0] = self.correct_combo[0]
        
        self.step_generator = self._backtrack_gen(start_idx)

    def _backtrack_gen(self, start_idx: int) -> Generator[Tuple[str, int, int, bool, List[Optional[int]]], None, bool]:
        """A generator that runs backtracking step-by-step and yields.
        
        Yields tuple: (action, lock_idx, key, is_valid, current_assigned_keys)
        action can be: "TRY", "LOCK", "BACKTRACK", "SUCCESS"
        """
        keys_pool = [1, 2, 3, 4]

        def solve(lock_idx: int) -> Generator[Tuple[str, int, int, bool, List[Optional[int]]], None, bool]:
            if lock_idx == 4:
                # Double check all assignments are correct
                if all(self.assigned_keys[i] == self.correct_combo[i] for i in range(4)):
                    yield "SUCCESS", 3, self.assigned_keys[3] or 0, True, list(self.assigned_keys)
                    return True
                return False

            # Find available keys
            available = [k for k in keys_pool if k not in self.assigned_keys[:lock_idx]]
            
            for key in available:
                self.assigned_keys[lock_idx] = key
                
                # Check constraints for visual locking and validity
                is_valid = True
                if lock_idx == 0:
                    is_valid = (key == self.correct_combo[0])
                elif lock_idx == 1:
                    is_valid = True # Lock 2 itself has no constraint check at this step
                elif lock_idx == 2:
                    is_valid = (self.assigned_keys[1] == self.correct_combo[1] and key == self.correct_combo[2])
                elif lock_idx == 3:
                    is_valid = (key == self.correct_combo[3])
                
                yield "TRY", lock_idx, key, is_valid, list(self.assigned_keys)
                
                if is_valid:
                    # Update visual locks
                    if lock_idx == 0:
                        self.locked_status[0] = True
                        yield "LOCK", 0, key, True, list(self.assigned_keys)
                    elif lock_idx == 2:
                        self.locked_status[0] = True
                        self.locked_status[2] = True
                        yield "LOCK", 2, key, True, list(self.assigned_keys)
                    
                    # Recurse
                    if (yield from solve(lock_idx + 1)):
                        return True
                    
                    # Remove lock visual if we backtrack
                    if lock_idx == 0:
                        self.locked_status[0] = False
                    elif lock_idx == 2:
                        self.locked_status[2] = False
                
                # Backtrack
                self.assigned_keys[lock_idx] = None
                yield "BACKTRACK", lock_idx, key, False, list(self.assigned_keys)
                
            return False

        # Run from start index
        result = yield from solve(start_idx)
        return result

    def interrupt(self) -> None:
        """Discard the current active search generator and reset un-secured key assignments."""
        self.step_generator = None
        
        # Reset assignments based on locked_status to keep RAM clean
        if self.locked_status[2]:
            # Keep locks 1, 2, 3 assigned
            self.assigned_keys = [
                self.correct_combo[0],
                self.correct_combo[1],
                self.correct_combo[2],
                None
            ]
        elif self.locked_status[0]:
            # Keep lock 1 assigned
            self.assigned_keys = [
                self.correct_combo[0],
                None,
                None,
                None
            ]
        else:
            # Reset everything
            self.assigned_keys = [None, None, None, None]
        self.log_message = "Decryption interrupted. Standing still will resume."

    def step(self) -> Tuple[bool, str]:
        """Perform one step of the backtracking algorithm.
        
        Returns (is_finished, description_message).
        """
        if self.step_generator is None:
            self.start_solving()
            
        try:
            assert self.step_generator is not None
            action, lock_idx, key, is_valid, assigned = next(self.step_generator)
            
            # Formulate logging messages based on backtracking steps
            if action == "TRY":
                if is_valid:
                    self.log_message = f"Lock {lock_idx+1}: Testing Key {key}... Match found!"
                else:
                    self.log_message = f"Lock {lock_idx+1}: Testing Key {key}... Conflict!"
            elif action == "LOCK":
                self.log_message = f">> Secure signal! Lock {lock_idx+1} is now LOCKED."
            elif action == "BACKTRACK":
                self.log_message = f"Lock {lock_idx+1}: Key {key} causes conflicts. Backtracking..."
            elif action == "SUCCESS":
                self.log_message = f"SUCCESS! All locks aligned. Gate unlocked!"
                self.is_solved = True
                return True, self.log_message
                
            return False, self.log_message
        except StopIteration:
            # Check if solved
            if self.is_solved:
                return True, "Gate already open."
            # If generator stopped and not solved, it failed (should not happen for a valid puzzle)
            return True, "Forward checking search completed with no solution."

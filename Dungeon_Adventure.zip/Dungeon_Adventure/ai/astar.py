"""A* search algorithm.

Used by EnemyAStar in game/enemy.py for chase behavior with f(n) = g(n) + h(n).
"""

from __future__ import annotations

import heapq
from collections.abc import Callable


class AStar:
    """Finds paths using A* search and Manhattan distance."""

    DIRECTIONS: tuple[tuple[int, int], ...] = ((0, -1), (0, 1), (-1, 0), (1, 0))

    def find_path(
        self,
        start: tuple[int, int],
        goal: tuple[int, int],
        is_walkable: Callable[[int, int], bool],
        get_cost: Callable[[int, int], int] = None,
    ) -> list[tuple[int, int]]:
        """Return a lowest-cost path from start to goal excluding start."""
        if start == goal:
            return []

        open_set: list[tuple[int, tuple[int, int]]] = [
            (self._heuristic(start, goal), start)
        ]
        came_from: dict[tuple[int, int], tuple[int, int]] = {}
        g_score: dict[tuple[int, int], int] = {start: 0}
        closed: set[tuple[int, int]] = set()

        while open_set:
            _, current = heapq.heappop(open_set)
            if current in closed:
                continue

            if current == goal:
                return self._reconstruct_path(came_from, start, goal)

            closed.add(current)

            for neighbor in self._neighbors(current):
                if neighbor in closed:
                    continue
                if not is_walkable(*neighbor):
                    continue

                step_cost = get_cost(*neighbor) if get_cost else 1
                tentative_g = g_score[current] + step_cost
                if tentative_g >= g_score.get(neighbor, float("inf")):
                    continue

                came_from[neighbor] = current
                g_score[neighbor] = tentative_g
                f_score = tentative_g + self._heuristic(neighbor, goal)
                heapq.heappush(open_set, (f_score, neighbor))

        return []

    def _heuristic(
        self,
        position: tuple[int, int],
        goal: tuple[int, int],
    ) -> int:
        """Return Manhattan distance h(n)."""
        return abs(position[0] - goal[0]) + abs(position[1] - goal[1])

    def _neighbors(self, position: tuple[int, int]) -> list[tuple[int, int]]:
        """Return adjacent grid positions."""
        x, y = position
        return [(x + dx, y + dy) for dx, dy in self.DIRECTIONS]

    def _reconstruct_path(
        self,
        came_from: dict[tuple[int, int], tuple[int, int]],
        start: tuple[int, int],
        goal: tuple[int, int],
    ) -> list[tuple[int, int]]:
        """Rebuild the path from start to goal."""
        path: list[tuple[int, int]] = []
        current = goal

        while current != start:
            path.append(current)
            current = came_from[current]

        path.reverse()
        return path

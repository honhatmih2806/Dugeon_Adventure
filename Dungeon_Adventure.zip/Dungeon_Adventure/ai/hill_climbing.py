"""Hill climbing local search for dungeon entity placement.

Used by maps/dungeon.py to optimize Key #3, Sword, Health Potion, and Torch.
"""

from __future__ import annotations

import copy
import random
from collections import deque
from dataclasses import dataclass, field

FLOOR: int = 0
WALL: int = 1

HILL_CLIMB_ENTITIES: tuple[str, ...] = ("Key 3", "Sword", "Health Potion", "Torch")
MIN_SPAWN_DISTANCE: int = 10
MIN_SPREAD_DISTANCE: int = 5
IDEAL_SPAWN_DISTANCE: tuple[int, int] = (12, 32)


@dataclass
class DungeonLayout:
    """Mutable placement state optimized during dungeon generation."""

    spawn_point: tuple[int, int]
    key_rooms: list[tuple[int, int]]
    puzzle_rooms: list[tuple[int, int]]
    items: list[tuple[int, int, str]]
    traps: list[tuple[int, int, str]]
    laboratory_room: tuple[int, int] = (0, 0)
    boss_room_center: tuple[int, int] = (0, 0)
    hill_climb_placements: dict[str, tuple[int, int]] = field(default_factory=dict)
    annealing_placements: dict[str, tuple[int, int]] = field(default_factory=dict)


@dataclass
class HillClimbContext:
    """Shared placement constraints for hill climbing."""

    spawn_point: tuple[int, int]
    walkable_tiles: set[tuple[int, int]]
    reachable_tiles: set[tuple[int, int]]
    boss_adjacent_tiles: set[tuple[int, int]]
    reserved_tiles: set[tuple[int, int]]
    forbidden_tiles: set[tuple[int, int]]
    candidate_tiles: list[tuple[int, int]]


def evaluate_position(
    placements: dict[str, tuple[int, int]],
    context: HillClimbContext,
) -> float:
    """Score a hill-climbing placement state. Higher is better."""
    positions = list(placements.values())

    if len(set(positions)) != len(positions):
        return -1000.0

    score = 0.0

    for entity, position in placements.items():
        if position not in context.walkable_tiles:
            return -1000.0
        if position in context.reserved_tiles:
            return -1000.0
        if position in context.forbidden_tiles:
            return -1000.0
        if position in context.boss_adjacent_tiles:
            score -= 60.0
        if _manhattan(position, context.spawn_point) < MIN_SPAWN_DISTANCE:
            score -= 60.0
        if position not in context.reachable_tiles:
            score -= 120.0
        else:
            score += 15.0

        spawn_distance = _manhattan(position, context.spawn_point)
        min_distance, max_distance = IDEAL_SPAWN_DISTANCE
        if min_distance <= spawn_distance <= max_distance:
            score += 8.0
        elif spawn_distance < min_distance:
            score -= 12.0
        else:
            score += spawn_distance * 0.35

        if entity == "Key 3":
            score += spawn_distance * 0.15

    for first_index, first_point in enumerate(positions):
        for second_point in positions[first_index + 1 :]:
            distance = _manhattan(first_point, second_point)
            score += distance * 0.9
            if distance < MIN_SPREAD_DISTANCE:
                score -= (MIN_SPREAD_DISTANCE - distance) * 8.0

    score += _quadrant_spread_bonus(positions, context.spawn_point)
    return score


def generate_neighbor(
    placements: dict[str, tuple[int, int]],
    context: HillClimbContext,
) -> dict[str, tuple[int, int]]:
    """Move one hill-climb entity to a nearby valid tile."""
    neighbor = dict(placements)
    entity = random.choice(HILL_CLIMB_ENTITIES)
    occupied = (
        _occupied_tiles(neighbor, skip_entity=entity)
        | context.reserved_tiles
        | context.forbidden_tiles
    )
    candidates = [
        tile
        for tile in context.candidate_tiles
        if tile not in occupied
    ]

    if not candidates:
        return neighbor

    neighbor[entity] = random.choice(candidates)
    return neighbor


def hill_climb(
    initial: dict[str, tuple[int, int]],
    context: HillClimbContext,
    max_iterations: int = 300,
) -> dict[str, tuple[int, int]]:
    """Improve placements using standard hill climbing."""
    current = dict(initial)
    current_score = evaluate_position(current, context)

    for _ in range(max_iterations):
        neighbor = generate_neighbor(current, context)
        neighbor_score = evaluate_position(neighbor, context)

        if neighbor_score > current_score:
            current = neighbor
            current_score = neighbor_score

    improved = True
    while improved:
        improved = False
        for _ in range(40):
            neighbor = generate_neighbor(current, context)
            neighbor_score = evaluate_position(neighbor, context)
            if neighbor_score > current_score:
                current = neighbor
                current_score = neighbor_score
                improved = True
                break

    return current


def build_reachable_tiles(
    grid: list[list[int]],
    spawn_point: tuple[int, int],
) -> set[tuple[int, int]]:
    """Return floor tiles reachable from spawn using BFS."""
    height = len(grid)
    width = len(grid[0]) if height else 0
    if not _is_floor(grid, spawn_point, width, height):
        return set()

    reachable: set[tuple[int, int]] = set()
    queue: deque[tuple[int, int]] = deque([spawn_point])

    while queue:
        x, y = queue.popleft()
        if (x, y) in reachable:
            continue

        reachable.add((x, y))

        for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            next_position = (x + dx, y + dy)
            if next_position in reachable:
                continue
            if not _is_floor(grid, next_position, width, height):
                continue
            queue.append(next_position)

    return reachable


def build_boss_adjacent_tiles(
    boss_bounds: tuple[int, int, int, int],
    grid_width: int,
    grid_height: int,
) -> set[tuple[int, int]]:
    """Return walkable tiles directly adjacent to a boss room envelope."""
    left, top, right, bottom = boss_bounds
    adjacent: set[tuple[int, int]] = set()

    for y in range(top - 1, bottom + 2):
        for x in range(left - 1, right + 2):
            if 0 <= x < grid_width and 0 <= y < grid_height:
                adjacent.add((x, y))

    return adjacent


def create_initial_placements(
    context: HillClimbContext,
) -> dict[str, tuple[int, int]]:
    """Create a random valid starting state for hill climbing."""
    placements: dict[str, tuple[int, int]] = {}
    occupied = set(context.reserved_tiles)

    for entity in HILL_CLIMB_ENTITIES:
        candidates = [
            tile
            for tile in context.candidate_tiles
            if tile not in occupied
            and tile not in context.forbidden_tiles
            and tile in context.reachable_tiles
            and _manhattan(tile, context.spawn_point) >= MIN_SPAWN_DISTANCE
            and tile not in context.boss_adjacent_tiles
        ]
        if not candidates:
            candidates = [
                tile
                for tile in context.candidate_tiles
                if tile not in occupied
            ]

        position = random.choice(candidates)
        placements[entity] = position
        occupied.add(position)

    return placements


class HillClimbingOptimizer:
    """Optimizes hill-climb entity placement for dungeon generation."""

    def __init__(
        self,
        grid: list[list[int]],
        walkable_tiles: list[tuple[int, int]],
        spawn_point: tuple[int, int],
        boss_adjacent_tiles: set[tuple[int, int]],
        reserved_tiles: set[tuple[int, int]],
        forbidden_tiles: set[tuple[int, int]] | None = None,
    ) -> None:
        """Initialize optimizer with maze context and placement constraints."""
        self._grid = grid
        self._spawn_point = spawn_point
        walkable_set = set(walkable_tiles)
        blocked_tiles = set(forbidden_tiles or set())
        self._context = HillClimbContext(
            spawn_point=spawn_point,
            walkable_tiles=walkable_set,
            reachable_tiles=build_reachable_tiles(grid, spawn_point) & walkable_set,
            boss_adjacent_tiles=boss_adjacent_tiles,
            reserved_tiles=set(reserved_tiles),
            forbidden_tiles=blocked_tiles,
            candidate_tiles=[
                tile
                for tile in walkable_tiles
                if tile not in boss_adjacent_tiles
                and tile not in blocked_tiles
            ],
        )

    def optimize_items(self) -> dict[str, tuple[int, int]]:
        """Place Key #3, Sword, Health Potion, and Torch with hill climbing."""
        initial = create_initial_placements(self._context)
        return hill_climb(initial, self._context)

    def optimize(self, layout: DungeonLayout) -> DungeonLayout:
        """Legacy hook: optimize hill-climb entities inside a layout object."""
        optimized = copy.deepcopy(layout)
        optimized.hill_climb_placements = self.optimize_items()
        optimized.items = _merge_hill_items(optimized.items, optimized.hill_climb_placements)
        return optimized


def _merge_hill_items(
    items: list[tuple[int, int, str]],
    hill_placements: dict[str, tuple[int, int]],
) -> list[tuple[int, int, str]]:
    """Replace hill-climb item positions inside a layout item list."""
    remaining = [
        item for item in items if item[2] not in HILL_CLIMB_ENTITIES
    ]
    for item_type in HILL_CLIMB_ENTITIES:
        if item_type in hill_placements:
            x, y = hill_placements[item_type]
            remaining.append((x, y, item_type))
    return remaining


def _occupied_tiles(
    placements: dict[str, tuple[int, int]],
    skip_entity: str | None = None,
) -> set[tuple[int, int]]:
    """Return occupied tiles, optionally excluding one entity."""
    occupied: set[tuple[int, int]] = set()
    for entity, position in placements.items():
        if entity == skip_entity:
            continue
        occupied.add(position)
    return occupied


def _is_floor(
    grid: list[list[int]],
    position: tuple[int, int],
    width: int,
    height: int,
) -> bool:
    """Return True when a grid cell is a floor tile."""
    x, y = position
    if x < 0 or y < 0 or x >= width or y >= height:
        return False
    return grid[y][x] == FLOOR


def _quadrant_spread_bonus(
    points: list[tuple[int, int]],
    spawn_point: tuple[int, int],
) -> float:
    """Reward coverage across map quadrants relative to spawn."""
    spawn_x, spawn_y = spawn_point
    quadrants = {0, 1, 2, 3}

    for x, y in points:
        horizontal = 0 if x <= spawn_x else 1
        vertical = 0 if y <= spawn_y else 1
        quadrants.discard(horizontal + vertical * 2)

    return float(len({0, 1, 2, 3}) - len(quadrants)) * 4.0


def _manhattan(first: tuple[int, int], second: tuple[int, int]) -> int:
    """Return Manhattan distance between two grid points."""
    return abs(first[0] - second[0]) + abs(first[1] - second[1])

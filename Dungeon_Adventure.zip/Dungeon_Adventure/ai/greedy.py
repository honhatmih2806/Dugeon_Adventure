"""Greedy best-first search algorithm.

Used by EnemyGreedy in game/enemy.py for chase behavior with f(n) = h(n).
"""

from __future__ import annotations

import heapq
from collections.abc import Callable


class GreedyBestFirstSearch:
    """Finds paths using greedy best-first search and Manhattan distance."""

    DIRECTIONS: tuple[tuple[int, int], ...] = ((0, -1), (0, 1), (-1, 0), (1, 0))

    def find_path(
        self,
        start: tuple[int, int],
        goal: tuple[int, int],
        is_walkable: Callable[[int, int], bool],
    ) -> list[tuple[int, int]]:
        """Return a path from start to goal excluding start."""
        if start == goal:
            return []

        open_set: list[tuple[int, tuple[int, int]]] = [
            (self._heuristic(start, goal), start)
        ]
        came_from: dict[tuple[int, int], tuple[int, int]] = {}
        visited: set[tuple[int, int]] = {start}

        while open_set:
            _, current = heapq.heappop(open_set)
            if current == goal:
                return self._reconstruct_path(came_from, start, goal)

            for neighbor in self._neighbors(current):
                if neighbor in visited:
                    continue
                if not is_walkable(*neighbor):
                    continue

                visited.add(neighbor)
                came_from[neighbor] = current
                heapq.heappush(
                    open_set,
                    (self._heuristic(neighbor, goal), neighbor),
                )

        return []

    def _heuristic(
        self,
        position: tuple[int, int],
        goal: tuple[int, int],
    ) -> int:
        """Return Manhattan distance h(n) used as f(n) for greedy search."""
        return abs(position[0] - goal[0]) + abs(position[1] - goal[1])

    def _neighbors(self, position: tuple[int, int]) -> list[tuple[int, int]]:
        """Return adjacent grid positions."""
        x, y = position
        return [(x + dx, y + dy) for dx, dy in self.DIRECTIONS]

    def _reconstruct_path(
        self,
        came_from: dict[tuple[int, int], tuple[int, int]],
        start: tuple[int, int],
        goal: tuple[int, int],
    ) -> list[tuple[int, int]]:
        """Rebuild the path from start to goal."""
        path: list[tuple[int, int]] = []
        current = goal

        while current != start:
            path.append(current)
            current = came_from[current]

        path.reverse()
        return path

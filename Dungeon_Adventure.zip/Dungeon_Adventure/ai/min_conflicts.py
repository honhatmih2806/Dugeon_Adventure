"""Min-conflicts constraint satisfaction for dungeon repair and rune puzzles."""

from __future__ import annotations

import random
from dataclasses import dataclass

from ai.hill_climbing import DungeonLayout
from ai.map_constraints import (
    MapConstraintContext,
    ConflictReport,
    count_conflicts,
    get_forbidden_room_tiles,
    manhattan,
    reachable_tiles,
    room_tiles,
    valid_item,
    valid_trap,
)


@dataclass
class MinConflictsRepairResult:
    """Summary of a min-conflicts repair pass."""

    layout: DungeonLayout
    initial_conflicts: int
    final_conflicts: int
    resolved_conflicts: int


class MinConflictsOptimizer:
    """Repairs placement conflicts on a completed dungeon layout."""

    MAX_ITERATIONS: int = 200
    MAX_CANDIDATES: int = 48

    def __init__(
        self,
        context: MapConstraintContext,
        walkable_tiles: list[tuple[int, int]],
    ) -> None:
        """Initialize the repair stage with shared constraint context."""
        self._context = context
        self._walkable_tiles = walkable_tiles

    def repair(self, layout: DungeonLayout) -> MinConflictsRepairResult:
        """Relocate conflicting objects until conflicts reach zero or max iterations."""
        working_layout = _copy_layout(layout)
        self._sync_context(working_layout)

        initial_report = count_conflicts(self._context)
        current_report = initial_report

        for _ in range(self.MAX_ITERATIONS):
            if current_report.total_conflicts == 0:
                break

            target_object = self._most_conflicted_object(current_report)
            if target_object is None:
                break

            if not self._relocate_object(working_layout, target_object):
                break

            self._sync_context(working_layout)
            current_report = count_conflicts(self._context)

        resolved = max(0, initial_report.total_conflicts - current_report.total_conflicts)
        return MinConflictsRepairResult(
            layout=working_layout,
            initial_conflicts=initial_report.total_conflicts,
            final_conflicts=current_report.total_conflicts,
            resolved_conflicts=resolved,
        )

    def _most_conflicted_object(self, report: ConflictReport) -> str | None:
        """Return the object id involved in the most conflicts."""
        if not report.conflicting_objects:
            return None

        return max(
            report.conflicting_objects,
            key=lambda object_id: len(report.conflicting_objects[object_id]),
        )

    def _relocate_object(self, layout: DungeonLayout, object_id: str) -> bool:
        """Move one conflicting object to the candidate tile with fewest conflicts."""
        candidates = self._candidate_tiles_for_object(layout, object_id)
        if not candidates:
            return False

        if len(candidates) > self.MAX_CANDIDATES:
            candidates = random.sample(candidates, self.MAX_CANDIDATES)

        best_position: tuple[int, int] | None = None
        best_conflicts = count_conflicts(self._context).total_conflicts

        for candidate in candidates:
            trial_layout = _copy_layout(layout)
            self._apply_relocation(trial_layout, object_id, candidate)
            trial_context = self._build_trial_context(trial_layout)
            trial_conflicts = count_conflicts(trial_context).total_conflicts

            if trial_conflicts < best_conflicts:
                best_conflicts = trial_conflicts
                best_position = candidate

        if best_position is None:
            return False

        self._apply_relocation(layout, object_id, best_position)
        return True

    def _candidate_tiles_for_object(
        self,
        layout: DungeonLayout,
        object_id: str,
    ) -> list[tuple[int, int]]:
        """Return valid relocation tiles for one repairable object."""
        origin = self._context.spawn_point or self._context.layout_anchor
        reachable_set = reachable_tiles(self._context.grid, origin)
        occupied = self._occupied_tiles(layout, skip_object=object_id)
        forbidden = get_forbidden_room_tiles(self._context)

        candidates = [
            tile
            for tile in self._walkable_tiles
            if tile not in occupied
            and tile in reachable_set
            and tile not in forbidden
        ]

        if object_id.startswith("trap:"):
            return [
                tile
                for tile in candidates
                if valid_trap(tile, self._context, reachable_set)
            ]

        if object_id.startswith("key_room:"):
            return candidates

        if object_id in ("Laboratory Room", "Boss Room"):
            return candidates

        return [
            tile
            for tile in candidates
            if valid_item(tile, object_id, self._context, reachable_set)
        ]

    def _apply_relocation(
        self,
        layout: DungeonLayout,
        object_id: str,
        position: tuple[int, int],
    ) -> None:
        """Write a relocated object back into the layout."""
        if object_id.startswith("trap:"):
            index = int(object_id.split(":")[1])
            trap_type = layout.traps[index][2]
            layout.traps[index] = (*position, trap_type)
            return

        if object_id.startswith("key_room:"):
            index = int(object_id.split(":")[1])
            layout.key_rooms[index] = position
            layout.puzzle_rooms[index] = position
            for item_index, (x, y, item_type) in enumerate(layout.items):
                if item_type == f"Key {index + 1}":
                    layout.items[item_index] = (*position, item_type)
            return

        if object_id == "Laboratory Room":
            layout.laboratory_room = position
            return

        if object_id == "Boss Room":
            layout.boss_room_center = position
            return

        for item_index, (x, y, item_type) in enumerate(layout.items):
            if item_type == object_id:
                layout.items[item_index] = (*position, item_type)
                return

    def _occupied_tiles(
        self,
        layout: DungeonLayout,
        skip_object: str | None = None,
    ) -> set[tuple[int, int]]:
        """Return tiles currently occupied by layout objects."""
        occupied: set[tuple[int, int]] = set()

        for index, center in enumerate(layout.key_rooms):
            object_id = f"key_room:{index}"
            if object_id == skip_object:
                continue
            occupied.update(room_tiles(center, self._context.key_room_size))

        if skip_object != "Laboratory Room":
            occupied.update(
                room_tiles(layout.laboratory_room, self._context.laboratory_room_size)
            )
        if skip_object != "Boss Room":
            occupied.update(
                room_tiles(layout.boss_room_center, self._context.boss_room_size)
            )

        for index, (x, y, trap_type) in enumerate(layout.traps):
            object_id = f"trap:{index}:{trap_type}"
            if object_id == skip_object:
                continue
            occupied.add((x, y))

        for x, y, item_type in layout.items:
            if item_type == skip_object:
                continue
            occupied.add((x, y))

        return occupied

    def _sync_context(self, layout: DungeonLayout) -> None:
        """Refresh the shared constraint context from the current layout."""
        self._context.key_rooms = list(layout.key_rooms)
        self._context.items = list(layout.items)
        self._context.traps = list(layout.traps)
        self._context.laboratory_room = layout.laboratory_room
        self._context.boss_room_center = layout.boss_room_center

    def _build_trial_context(self, layout: DungeonLayout) -> MapConstraintContext:
        """Clone the constraint context for evaluating a trial relocation."""
        return MapConstraintContext(
            grid=self._context.grid,
            grid_width=self._context.grid_width,
            grid_height=self._context.grid_height,
            layout_anchor=self._context.layout_anchor,
            spawn_point=self._context.spawn_point,
            key_rooms=list(layout.key_rooms),
            items=list(layout.items),
            traps=list(layout.traps),
            laboratory_room=layout.laboratory_room,
            boss_room_center=layout.boss_room_center,
            boss_room_size=self._context.boss_room_size,
            laboratory_room_size=self._context.laboratory_room_size,
            key_room_size=self._context.key_room_size,
            reserved_tiles=set(self._context.reserved_tiles),
            forbidden_tiles=set(self._context.forbidden_tiles),
            boss_adjacent_tiles=set(self._context.boss_adjacent_tiles),
            pathfinding_grid=self._context.pathfinding_grid,
        )


class MinConflictsSolver:
    """Solves small CSPs with iterative min-conflicts search for the rune puzzle."""

    MAX_STEPS: int = 200

    def __init__(self, variable_count: int = 3, domain_size: int = 3) -> None:
        """Initialize solver dimensions for the rune puzzle."""
        self.variable_count = variable_count
        self.domain_size = domain_size
        self.state: list[int] = []

    def initialize_state(self) -> list[int]:
        """Create a random value assignment for all variables."""
        self.state = [
            random.randint(1, self.domain_size) for _ in range(self.variable_count)
        ]
        return self.state

    def count_conflicts(
        self,
        state: list[int],
        row: int | None = None,
        value: int | None = None,
    ) -> int:
        """Count duplicate-value conflicts in the current or test state."""
        test_state = state[:]
        if row is not None and value is not None:
            test_state[row] = value

        conflicts = 0
        for first_index in range(self.variable_count):
            for second_index in range(first_index + 1, self.variable_count):
                if test_state[first_index] == test_state[second_index]:
                    conflicts += 1

        return conflicts

    def solve(self) -> bool:
        """Solve using random conflicted variable selection."""
        self.state = self.initialize_state()

        for _ in range(self.MAX_STEPS):
            if self.count_conflicts(self.state) == 0:
                return True

            conflicted_rows = self._get_conflicted_rows()
            row = random.choice(conflicted_rows)
            best_conflicts = min(
                self.count_conflicts(self.state, row, candidate)
                for candidate in range(1, self.domain_size + 1)
            )
            best_values = [
                candidate
                for candidate in range(1, self.domain_size + 1)
                if self.count_conflicts(self.state, row, candidate) == best_conflicts
            ]
            self.state[row] = random.choice(best_values)

        return self.count_conflicts(self.state) == 0

    def _get_conflicted_rows(self) -> list[int]:
        """Return variable indices involved in at least one conflict."""
        conflicted_rows: list[int] = []

        for row in range(self.variable_count):
            for other_row in range(self.variable_count):
                if row == other_row:
                    continue

                if self.state[row] == self.state[other_row]:
                    conflicted_rows.append(row)
                    break

        return conflicted_rows


def _copy_layout(layout: DungeonLayout) -> DungeonLayout:
    """Return a shallow copy of a dungeon layout."""
    return DungeonLayout(
        spawn_point=layout.spawn_point,
        key_rooms=list(layout.key_rooms),
        puzzle_rooms=list(layout.puzzle_rooms),
        items=list(layout.items),
        traps=list(layout.traps),
        laboratory_room=layout.laboratory_room,
        boss_room_center=layout.boss_room_center,
        hill_climb_placements=dict(layout.hill_climb_placements),
        annealing_placements=dict(layout.annealing_placements),
    )

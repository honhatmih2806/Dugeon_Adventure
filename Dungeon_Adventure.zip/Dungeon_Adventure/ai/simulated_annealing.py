"""Simulated annealing local search for dungeon layout refinement.

Used by maps/dungeon.py to optimize Key #4, Boss Room, and Laboratory Room.
"""

from __future__ import annotations

import copy
import math
import random
from dataclasses import dataclass

from ai.hill_climbing import DungeonLayout, _manhattan
from ai.ucs import ucs

ANNEALING_ENTITIES: tuple[str, ...] = ("Key 4", "Boss Room", "Laboratory Room")
MIN_SPAWN_DISTANCE: int = 10
MIN_SPECIAL_ROOM_DISTANCE: int = 10
MIN_KEY_ROOM_DISTANCE: int = 8
MIN_SPREAD_DISTANCE: int = 10
IDEAL_SPAWN_DISTANCE: tuple[int, int] = (14, 34)
MIN_BOSS_PATH_LENGTH: int = 25
MIN_BOSS_PATH_TURNS: int = 5
MAX_STRAIGHT_SEGMENT: int = 8


@dataclass
class AnnealingContext:
    """Shared placement constraints for simulated annealing."""

    spawn_point: tuple[int, int]
    walkable_tiles: set[tuple[int, int]]
    reachable_tiles: set[tuple[int, int]]
    reserved_tiles: set[tuple[int, int]]
    forbidden_tiles: set[tuple[int, int]]
    special_room_centers: list[tuple[int, int]]
    boss_room_size: int
    grid_width: int
    grid_height: int
    boss_candidates: list[tuple[int, int]]
    item_candidates: list[tuple[int, int]]
    pathfinding_grid: list[list[int]]
    laboratory_room_size: int


def evaluate_position(
    placements: dict[str, tuple[int, int]],
    context: AnnealingContext,
) -> float:
    """Score an annealing placement state. Higher is better."""
    positions = list(placements.values())

    if len(set(positions)) != len(positions):
        return -1000.0

    score = 0.0
    boss_center = placements.get("Boss Room")
    if boss_center is None or not _is_valid_boss_center(boss_center, context):
        return -1000.0

    all_special_centers = list(context.special_room_centers)
    all_special_centers.extend(
        position
        for entity, position in placements.items()
        if entity in ("Boss Room", "Laboratory Room")
    )

    for first_index, first_center in enumerate(all_special_centers):
        for second_center in all_special_centers[first_index + 1 :]:
            if _manhattan(first_center, second_center) < MIN_SPECIAL_ROOM_DISTANCE:
                return -1000.0

    for entity, position in placements.items():
        if entity == "Boss Room":
            continue

        if position not in context.walkable_tiles:
            return -1000.0
        if position in context.reserved_tiles:
            return -1000.0
        if position in context.forbidden_tiles:
            return -1000.0
        if position not in context.reachable_tiles:
            return -1000.0

        spawn_distance = _manhattan(position, context.spawn_point)
        if spawn_distance < MIN_SPAWN_DISTANCE:
            return -1000.0
        score += spawn_distance * 0.6

        min_distance, max_distance = IDEAL_SPAWN_DISTANCE
        if min_distance <= spawn_distance <= max_distance:
            score += 10.0

    boss_distance = _manhattan(boss_center, context.spawn_point)
    if boss_distance < MIN_SPAWN_DISTANCE:
        return -1000.0
    score += boss_distance * 0.8

    boss_tiles = _boss_room_tiles(boss_center, context.boss_room_size)
    laboratory_center = placements.get("Laboratory Room")
    if laboratory_center is not None:
        laboratory_tiles = _room_tiles(
            laboratory_center,
            context.laboratory_room_size,
        )
        if laboratory_tiles & boss_tiles:
            return -1000.0
        if laboratory_tiles & context.forbidden_tiles:
            return -1000.0

    for entity, position in placements.items():
        if entity == "Boss Room":
            continue
        if position in boss_tiles:
            return -1000.0

    for first_index, first_point in enumerate(positions):
        for second_point in positions[first_index + 1 :]:
            distance = _manhattan(first_point, second_point)
            score += distance * 0.75
            if distance < MIN_SPREAD_DISTANCE:
                score -= (MIN_SPREAD_DISTANCE - distance) * 10.0

    score += _quadrant_spread_bonus(positions, context.spawn_point)

    laboratory_center = placements.get("Laboratory Room")
    if laboratory_center is not None and boss_center is not None:
        score += _evaluate_boss_route_quality(
            laboratory_center,
            boss_center,
            context.pathfinding_grid,
        )

    return score


def generate_neighbor(
    placements: dict[str, tuple[int, int]],
    context: AnnealingContext,
) -> dict[str, tuple[int, int]]:
    """Move one annealing entity to a new valid tile."""
    neighbor = dict(placements)
    entity = random.choice(ANNEALING_ENTITIES)
    occupied = (
        _occupied_tiles(neighbor, skip_entity=entity)
        | context.reserved_tiles
        | context.forbidden_tiles
    )

    if entity == "Boss Room":
        candidates = [
            center
            for center in context.boss_candidates
            if center not in occupied
            and _manhattan(center, context.spawn_point) >= MIN_SPAWN_DISTANCE
            and _is_far_from_special_rooms(center, context)
        ]
    else:
        other_centers = [
            position
            for other_entity, position in neighbor.items()
            if other_entity != entity
        ]
        candidates = [
            tile
            for tile in context.item_candidates
            if tile not in occupied
            and _manhattan(tile, context.spawn_point) >= MIN_SPAWN_DISTANCE
            and _is_far_from_special_rooms(tile, context, other_centers)
        ]

    if not candidates:
        return neighbor

    neighbor[entity] = random.choice(candidates)
    return neighbor


def simulated_annealing(
    initial: dict[str, tuple[int, int]],
    context: AnnealingContext,
    initial_temperature: float = 15.0,
    cooling_rate: float = 0.985,
    min_temperature: float = 0.05,
    max_iterations: int = 450,
) -> dict[str, tuple[int, int]]:
    """Improve placements using simulated annealing."""
    current = dict(initial)
    current_score = evaluate_position(current, context)
    best = dict(current)
    best_score = current_score
    temperature = initial_temperature

    for _ in range(max_iterations):
        neighbor = generate_neighbor(current, context)
        neighbor_score = evaluate_position(neighbor, context)
        delta = neighbor_score - current_score

        if delta >= 0 or _accept_worse_move(delta, temperature):
            current = neighbor
            current_score = neighbor_score

            if current_score > best_score:
                best = dict(current)
                best_score = current_score

        temperature = max(min_temperature, temperature * cooling_rate)

    return best


def create_initial_placements(context: AnnealingContext) -> dict[str, tuple[int, int]]:
    """Create a random valid starting state for simulated annealing."""
    placements: dict[str, tuple[int, int]] = {}
    occupied = set(context.reserved_tiles)

    boss_candidates = [
        center
        for center in context.boss_candidates
        if center not in occupied
        and _manhattan(center, context.spawn_point) >= MIN_SPAWN_DISTANCE
        and _is_far_from_special_rooms(center, context)
    ]
    if not boss_candidates:
        boss_candidates = [
            center
            for center in context.boss_candidates
            if center not in occupied
        ]
    placements["Boss Room"] = random.choice(boss_candidates)
    occupied.add(placements["Boss Room"])

    for entity in ("Key 4", "Laboratory Room"):
        other_centers = list(placements.values())
        candidates = [
            tile
            for tile in context.item_candidates
            if tile not in occupied
            and tile in context.reachable_tiles
            and tile not in context.forbidden_tiles
            and _manhattan(tile, context.spawn_point) >= MIN_SPAWN_DISTANCE
            and _is_far_from_special_rooms(tile, context, other_centers)
        ]
        if not candidates:
            candidates = [
                tile
                for tile in context.item_candidates
                if tile not in occupied
            ]

        position = random.choice(candidates)
        placements[entity] = position
        occupied.add(position)

    return placements


def build_boss_candidates(
    walkable_tiles: set[tuple[int, int]],
    boss_room_size: int,
    grid_width: int,
    grid_height: int,
) -> list[tuple[int, int]]:
    """Return valid boss room center positions that fit inside the grid."""
    del walkable_tiles  # Boss room carving creates its own floor tiles.
    margin = boss_room_size // 2
    candidates: list[tuple[int, int]] = []

    for center_y in range(margin + 1, grid_height - margin - 1):
        for center_x in range(margin + 4, grid_width - margin - 1):
            bounds = _boss_bounds(center_x, center_y, boss_room_size)
            if bounds is None:
                continue

            left, top, right, bottom = bounds
            if left <= 1:
                continue

            candidates.append((center_x, center_y))

    return candidates


class SimulatedAnnealingOptimizer:
    """Optimizes Key #4, Boss Room, and Laboratory placement."""

    def __init__(
        self,
        walkable_tiles: list[tuple[int, int]],
        spawn_point: tuple[int, int],
        reachable_tiles: set[tuple[int, int]],
        reserved_tiles: set[tuple[int, int]],
        forbidden_tiles: set[tuple[int, int]],
        special_room_centers: list[tuple[int, int]],
        boss_room_size: int,
        grid_width: int,
        grid_height: int,
        pathfinding_grid: list[list[int]],
        laboratory_room_size: int = 3,
    ) -> None:
        """Initialize optimizer with maze context and placement constraints."""
        walkable_set = set(walkable_tiles)
        boss_candidates = build_boss_candidates(
            walkable_set,
            boss_room_size,
            grid_width,
            grid_height,
        )
        if not boss_candidates:
            boss_candidates = [(grid_width - 4, grid_height // 2)]

        self._context = AnnealingContext(
            spawn_point=spawn_point,
            walkable_tiles=walkable_set,
            reachable_tiles=reachable_tiles,
            reserved_tiles=set(reserved_tiles),
            forbidden_tiles=set(forbidden_tiles),
            special_room_centers=list(special_room_centers),
            boss_room_size=boss_room_size,
            grid_width=grid_width,
            grid_height=grid_height,
            boss_candidates=boss_candidates,
            item_candidates=[
                tile
                for tile in walkable_set
                if tile not in forbidden_tiles
            ],
            pathfinding_grid=pathfinding_grid,
            laboratory_room_size=laboratory_room_size,
        )

    def optimize_placements(self) -> dict[str, tuple[int, int]]:
        """Place Key #4, Boss Room, and Laboratory Room with simulated annealing."""
        initial = create_initial_placements(self._context)
        return simulated_annealing(initial, self._context)

    def optimize(self, layout: DungeonLayout) -> DungeonLayout:
        """Apply simulated annealing to annealing entities inside a layout."""
        optimized = copy.deepcopy(layout)
        optimized.annealing_placements = self.optimize_placements()
        optimized.boss_room_center = optimized.annealing_placements["Boss Room"]
        optimized.laboratory_room = optimized.annealing_placements["Laboratory Room"]
        optimized.items = _merge_annealing_items(
            optimized.items,
            optimized.annealing_placements,
        )
        return optimized


def _merge_annealing_items(
    items: list[tuple[int, int, str]],
    annealing_placements: dict[str, tuple[int, int]],
) -> list[tuple[int, int, str]]:
    """Replace annealing item positions inside a layout item list."""
    remaining = [item for item in items if item[2] != "Key 4"]
    key_position = annealing_placements["Key 4"]
    remaining.append((*key_position, "Key 4"))
    return remaining


def _is_far_from_special_rooms(
    position: tuple[int, int],
    context: AnnealingContext,
    other_centers: list[tuple[int, int]] | None = None,
) -> bool:
    """Return True when a position respects special-room separation."""
    centers = list(context.special_room_centers)
    if other_centers:
        centers.extend(other_centers)

    for center in centers:
        if _manhattan(position, center) < MIN_SPECIAL_ROOM_DISTANCE:
            return False

    return True


def _room_tiles(center: tuple[int, int], room_size: int) -> set[tuple[int, int]]:
    """Return all grid tiles inside a square room."""
    center_x, center_y = center
    margin = room_size // 2
    tiles: set[tuple[int, int]] = set()

    for y in range(center_y - margin, center_y + margin + 1):
        for x in range(center_x - margin, center_x + margin + 1):
            tiles.add((x, y))

    return tiles


def _boss_room_tiles(
    center: tuple[int, int],
    boss_room_size: int,
) -> set[tuple[int, int]]:
    """Return all tiles inside a boss room centered on the given point."""
    center_x, center_y = center
    margin = boss_room_size // 2
    tiles: set[tuple[int, int]] = set()

    for y in range(center_y - margin, center_y + margin + 1):
        for x in range(center_x - margin, center_x + margin + 1):
            tiles.add((x, y))

    return tiles


def _evaluate_boss_route_quality(
    start: tuple[int, int],
    goal: tuple[int, int],
    grid: list[list[int]],
) -> float:
    """Reward longer, turning boss routes and penalize straight shortcuts."""
    path, path_length, _, _ = ucs(start, goal, grid)
    if path_length <= 0:
        return -500.0

    turns = _count_path_turns(path)
    straight_segment = _longest_straight_segment(path)
    score = path_length * 1.2 + turns * 4.0

    if path_length < MIN_BOSS_PATH_LENGTH:
        score -= (MIN_BOSS_PATH_LENGTH - path_length) * 8.0

    if turns < MIN_BOSS_PATH_TURNS:
        score -= (MIN_BOSS_PATH_TURNS - turns) * 10.0

    if straight_segment > MAX_STRAIGHT_SEGMENT:
        score -= (straight_segment - MAX_STRAIGHT_SEGMENT) * 6.0

    return score


def _count_path_turns(path: list[tuple[int, int]]) -> int:
    """Count direction changes along a grid path."""
    if len(path) < 3:
        return 0

    turns = 0
    previous_direction: tuple[int, int] | None = None

    for first, second in zip(path, path[1:]):
        direction = (second[0] - first[0], second[1] - first[1])
        if previous_direction is not None and direction != previous_direction:
            turns += 1
        previous_direction = direction

    return turns


def _longest_straight_segment(path: list[tuple[int, int]]) -> int:
    """Return the longest run of steps in a single direction."""
    if len(path) < 2:
        return 0

    longest = 1
    current = 1
    previous_direction: tuple[int, int] | None = None

    for first, second in zip(path, path[1:]):
        direction = (second[0] - first[0], second[1] - first[1])
        if direction == previous_direction:
            current += 1
        else:
            current = 1
        previous_direction = direction
        longest = max(longest, current)

    return longest


def _accept_worse_move(delta: float, temperature: float) -> bool:
    """Accept worse layouts probabilistically while temperature is high."""
    if temperature <= 0.0:
        return False

    probability = math.exp(delta / temperature)
    return random.random() < probability


def _boss_bounds(
    center_x: int,
    center_y: int,
    boss_room_size: int,
) -> tuple[int, int, int, int] | None:
    """Return boss room bounds for a center, or None when out of range."""
    margin = boss_room_size // 2
    left = center_x - margin
    right = center_x + margin
    top = center_y - margin
    bottom = center_y + margin
    return left, top, right, bottom


def _is_valid_boss_center(center: tuple[int, int], context: AnnealingContext) -> bool:
    """Return True when a boss room center fits inside the grid."""
    bounds = _boss_bounds(center[0], center[1], context.boss_room_size)
    if bounds is None:
        return False

    left, top, right, bottom = bounds
    if left < 1 or top < 1 or right >= context.grid_width - 1 or bottom >= context.grid_height - 1:
        return False

    return True


def _occupied_tiles(
    placements: dict[str, tuple[int, int]],
    skip_entity: str | None = None,
) -> set[tuple[int, int]]:
    """Return occupied tiles, optionally excluding one entity."""
    occupied: set[tuple[int, int]] = set()
    for entity, position in placements.items():
        if entity == skip_entity:
            continue
        occupied.add(position)
    return occupied


def _quadrant_spread_bonus(
    points: list[tuple[int, int]],
    spawn_point: tuple[int, int],
) -> float:
    """Reward coverage across map quadrants relative to spawn."""
    spawn_x, spawn_y = spawn_point
    quadrants = {0, 1, 2, 3}

    for x, y in points:
        horizontal = 0 if x <= spawn_x else 1
        vertical = 0 if y <= spawn_y else 1
        quadrants.discard(horizontal + vertical * 2)

    return float(len({0, 1, 2, 3}) - len(quadrants)) * 6.0

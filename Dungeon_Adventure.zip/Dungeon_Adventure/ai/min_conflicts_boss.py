"""Min-conflicts constraint satisfaction algorithm for recommending boss crystal targets.

Suggests:
1. The optimal sequence of crystal destruction based on player stats.
2. Whether the player should engage the boss immediately or focus on crystals.
"""

from __future__ import annotations
from typing import Dict, List, Set, Tuple


class MinConflictsBoss:
    """Computes crystal recommendations based on player stats and boss status."""

    def __init__(self) -> None:
        pass

    def evaluate_conflicts(
        self,
        player_attack: int,
        player_vision: int,
        player_stamina: int,
        base_attack: int,
        base_vision: int,
        base_stamina: int,
        intact_crystals: Set[str],
        boss_buffs: Set[str]
    ) -> Tuple[str, str, List[str]]:
        """Calculate conflicts for each available target.
        
        Returns:
            Tuple: (recommended_target, boss_engage_decision, recommended_sequence)
        """
        # If no crystals are left, the only target is the boss
        if not intact_crystals:
            return "boss", "Engage Boss! Crystals shattered.", []

        # We evaluate the total conflict score of engaging the boss right now
        boss_conflict = 0
        # Player weakness conflicts
        if player_attack < base_attack:
            boss_conflict += 10
        if player_stamina < base_stamina:
            boss_conflict += 6
        if player_vision < base_vision:
            boss_conflict += 3
        # Boss buff conflicts
        if "attack" in boss_buffs:
            boss_conflict += 8
        if "stamina" in boss_buffs:
            boss_conflict += 6
        if "vision" in boss_buffs:
            boss_conflict += 2

        # Engage decision based on current boss conflict
        if boss_conflict <= 6:
            boss_decision = "Engage Boss! You are strong enough."
        elif boss_conflict <= 12:
            boss_decision = "Engage Boss? Risky but doable. Breaking crystals recommended."
        else:
            boss_decision = "DO NOT engage Boss! Danger high. Shatter crystals first."

        # Let's find the optimal path of remaining crystals to break using a search
        # We want to find a permutation of remaining crystals that minimizes the conflict at each step.
        remaining = list(intact_crystals)
        
        # Helper to compute state conflict
        def get_state_conflict(p_att: int, p_vis: int, p_sta: int, b_att: bool, b_sta: bool, b_vis: bool) -> int:
            conf = 0
            if p_att < base_attack:
                conf += 10
            if p_sta < base_stamina:
                conf += 6
            if p_vis < base_vision:
                conf += 3
            if b_att:
                conf += 8
            if b_sta:
                conf += 6
            if b_vis:
                conf += 2
            return conf

        # Simulate crystal destruction steps and compute cumulative conflict
        # We want to test all sequences of remaining crystals
        import itertools
        best_sequence = []
        min_path_conflict = 99999
        
        for seq in itertools.permutations(remaining):
            # Start with current state
            curr_p_att, curr_p_vis, curr_p_sta = player_attack, player_vision, player_stamina
            # Keep track of active boss buffs in simulation
            curr_b_buffs = set(boss_buffs)
            
            path_conflict = 0
            
            for crystal in seq:
                # 1. Break the crystal: player gets stat back, boss gets the other two
                if crystal == "red":
                    curr_p_att = base_attack
                    # Boss gets stamina and vision buffs (if those crystals are intact)
                    if "blue" in intact_crystals and "blue" not in seq[:seq.index(crystal)]:
                        curr_b_buffs.add("stamina")
                    if "green" in intact_crystals and "green" not in seq[:seq.index(crystal)]:
                        curr_b_buffs.add("vision")
                    # Boss loses attack buff if red is broken
                    if "attack" in curr_b_buffs:
                        curr_b_buffs.remove("attack")
                elif crystal == "blue":
                    curr_p_sta = base_stamina
                    if "red" in intact_crystals and "red" not in seq[:seq.index(crystal)]:
                        curr_b_buffs.add("attack")
                    if "green" in intact_crystals and "green" not in seq[:seq.index(crystal)]:
                        curr_b_buffs.add("vision")
                    if "stamina" in curr_b_buffs:
                        curr_b_buffs.remove("stamina")
                elif crystal == "green":
                    curr_p_vis = base_vision
                    if "red" in intact_crystals and "red" not in seq[:seq.index(crystal)]:
                        curr_b_buffs.add("attack")
                    if "blue" in intact_crystals and "blue" not in seq[:seq.index(crystal)]:
                        curr_b_buffs.add("stamina")
                    if "vision" in curr_b_buffs:
                        curr_b_buffs.remove("vision")
                
                # Add conflict score of this intermediate state
                b_att = "attack" in curr_b_buffs
                b_sta = "stamina" in curr_b_buffs
                b_vis = "vision" in curr_b_buffs
                path_conflict += get_state_conflict(curr_p_att, curr_p_vis, curr_p_sta, b_att, b_sta, b_vis)
            
            if path_conflict < min_path_conflict:
                min_path_conflict = path_conflict
                best_sequence = list(seq)

        # The next recommended target is the first element of the best sequence
        recommended_target = best_sequence[0] if best_sequence else "boss"
        
        # Let's map names to friendly text for recommendation
        # e.g., red -> Red Crystal (Attack), blue -> Blue Crystal (Stamina), green -> Green Crystal (Vision)
        friendly_names = {
            "red": "Red Crystal (Attack)",
            "blue": "Blue Crystal (Stamina)",
            "green": "Green Crystal (Vision)",
            "boss": "Boss"
        }
        
        seq_names = [friendly_names[c] for c in best_sequence]
        
        return recommended_target, boss_decision, seq_names

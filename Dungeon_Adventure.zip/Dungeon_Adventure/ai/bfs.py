"""Breadth-first search algorithm."""

from __future__ import annotations

from collections import deque


DIRECTIONS: tuple[tuple[int, int], ...] = ((0, -1), (0, 1), (-1, 0), (1, 0))


def bfs(
    start: tuple[int, int],
    goal: tuple[int, int],
    grid: list[list[int]],
) -> tuple[list[tuple[int, int]], int, int]:
    """Find a shortest path using breadth-first search.

    Grid cells with value 0 are walkable; 1 marks walls.
    Returns path, path_length (edge count), and nodes_expanded.
    """
    # Basic validation
    height = len(grid)
    width = len(grid[0]) if height else 0
    if width == 0 or height == 0:
        return [], 0, 0

    def in_bounds(p: tuple[int, int]) -> bool:
        x, y = p
        return 0 <= x < width and 0 <= y < height

    if not in_bounds(start) or not in_bounds(goal):
        return [], 0, 0

    if not _is_walkable(start, grid) or not _is_walkable(goal, grid):
        return [], 0, 0

    if start == goal:
        return [start], 0, 1

    queue: deque[tuple[int, int]] = deque([start])
    came_from: dict[tuple[int, int], tuple[int, int] | None] = {start: None}
    nodes_expanded = 0

    while queue:
        current = queue.popleft()
        nodes_expanded += 1

        if current == goal:
            path = _reconstruct_path(came_from, start, goal)
            return path, max(0, len(path) - 1), nodes_expanded

        for neighbor in _neighbors(current, width, height):
            if neighbor in came_from:
                continue
            if not _is_walkable(neighbor, grid):
                continue

            came_from[neighbor] = current
            queue.append(neighbor)

    return [], 0, nodes_expanded


def _is_walkable(position: tuple[int, int], grid: list[list[int]]) -> bool:
    """Return True when a grid cell is walkable."""
    x, y = position
    return grid[y][x] == 0


def _neighbors(
    position: tuple[int, int],
    width: int,
    height: int,
) -> list[tuple[int, int]]:
    """Return in-bounds adjacent grid positions."""
    x, y = position
    neighbors: list[tuple[int, int]] = []

    for dx, dy in DIRECTIONS:
        next_x = x + dx
        next_y = y + dy
        if 0 <= next_x < width and 0 <= next_y < height:
            neighbors.append((next_x, next_y))

    return neighbors


def _reconstruct_path(
    came_from: dict[tuple[int, int], tuple[int, int] | None],
    start: tuple[int, int],
    goal: tuple[int, int],
) -> list[tuple[int, int]]:
    """Rebuild the path from start to goal."""
    path: list[tuple[int, int]] = []
    current: tuple[int, int] | None = goal

    while current is not None:
        path.append(current)
        current = came_from[current]

    path.reverse()
    return path


class BFS:
    """Implements breadth-first search for pathfinding."""

    def search(
        self,
        start: tuple[int, int],
        goal: tuple[int, int],
        grid: list[list[int]],
    ) -> tuple[list[tuple[int, int]], int, int]:
        """Run BFS and return path, path length, and nodes expanded."""
        return bfs(start, goal, grid)

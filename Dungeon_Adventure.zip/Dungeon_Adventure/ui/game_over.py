"""Game over screen."""


class GameOver:
    """Renders the game over screen after victory or defeat."""

    def __init__(self) -> None:
        """Initialize the game over screen."""
        pass

"""Heads-up display rendering."""

import pygame

from game.player import Player
from assets.sprite_manager import get_named_icon


class HUD:
    """Draw player health and stamina bars, and bottom horizontal inventory hotbar."""

    BAR_WIDTH: int = 220
    BAR_HEIGHT: int = 18
    PADDING: int = 12
    BAR_GAP: int = 10
    BORDER_WIDTH: int = 2

    BACKGROUND_COLOR: tuple[int, int, int] = (15, 13, 19)
    BORDER_COLOR: tuple[int, int, int] = (117, 92, 76)
    HP_COLOR: tuple[int, int, int] = (154, 35, 52)
    STAMINA_COLOR: tuple[int, int, int] = (180, 129, 53)
    TEXT_COLOR: tuple[int, int, int] = (226, 218, 198)
    GAME_OVER_COLOR: tuple[int, int, int] = (188, 36, 49)

    def __init__(self) -> None:
        """Initialize HUD text rendering."""
        self._font = pygame.font.Font(None, 24)
        self._game_over_font = pygame.font.Font(None, 72)

    def render(
        self,
        surface: pygame.Surface,
        player: Player,
        key_target_count: int = 4,
        inventory_visible: bool = False,
        selected_index: int = 0,
        show_hud_bars: bool = False,
        sorted_items: list[tuple[str, int]] = None,
    ) -> None:
        """Draw HP, stamina, and optional inventory for the given player."""
        if show_hud_bars:
            x = self.PADDING
            y = self.PADDING

            self._draw_bar(
                surface,
                x,
                y,
                "HP",
                int(player.hp),
                player.max_hp,
                self.HP_COLOR,
            )
            self._draw_bar(
                surface,
                x,
                y + self.BAR_HEIGHT + self.BAR_GAP,
                "STA",
                player.stamina,
                player.max_stamina,
                self.STAMINA_COLOR,
            )

        if inventory_visible:
            self._draw_bottom_inventory(
                surface,
                player,
                key_target_count,
                selected_index,
                sorted_items or [],
            )

        if not player.is_alive:
            self._draw_game_over(surface)

    def _draw_bar(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        label: str,
        value: int,
        max_value: int,
        fill_color: tuple[int, int, int],
    ) -> None:
        """Draw one labeled meter."""
        max_value = max(1, max_value)
        value = max(0, min(value, max_value))
        fill_width = int(self.BAR_WIDTH * (value / max_value))

        background_rect = pygame.Rect(x, y, self.BAR_WIDTH, self.BAR_HEIGHT)
        fill_rect = pygame.Rect(x, y, fill_width, self.BAR_HEIGHT)

        pygame.draw.rect(surface, self.BACKGROUND_COLOR, background_rect)
        pygame.draw.rect(surface, fill_color, fill_rect)
        pygame.draw.rect(
            surface,
            self.BORDER_COLOR,
            background_rect,
            self.BORDER_WIDTH,
        )

        text = self._font.render(
            f"{label} {value}/{max_value}",
            True,
            self.TEXT_COLOR,
        )
        text_rect = text.get_rect(center=background_rect.center)
        surface.blit(text, text_rect)

    def _draw_bottom_inventory(
        self,
        surface: pygame.Surface,
        player: Player,
        key_target_count: int,
        selected_index: int,
        sorted_items: list[tuple[str, int]],
    ) -> None:
        """Draw inventory panel horizontally at the bottom of the screen."""
        panel_w = 980
        panel_h = 110
        panel_x = (surface.get_width() - panel_w) // 2
        panel_y = surface.get_height() - panel_h - self.PADDING
        
        panel_rect = pygame.Rect(panel_x, panel_y, panel_w, panel_h)
        pygame.draw.rect(surface, self.BACKGROUND_COLOR, panel_rect)
        pygame.draw.rect(surface, self.BORDER_COLOR, panel_rect, self.BORDER_WIDTH)
        
        # 1. Circular player avatar on the left
        avatar_center_x = panel_x + 55
        avatar_center_y = panel_y + 55
        pygame.draw.circle(surface, (30, 25, 40), (avatar_center_x, avatar_center_y), 45)
        pygame.draw.circle(surface, self.BORDER_COLOR, (avatar_center_x, avatar_center_y), 45, self.BORDER_WIDTH)
        
        avatar_icon = get_named_icon("player", 64)
        if avatar_icon:
            iw, ih = avatar_icon.get_size()
            surface.blit(avatar_icon, (avatar_center_x - iw // 2, avatar_center_y - ih // 2))
            
        # 2. HP and Stamina bars inside the panel next to avatar
        bar_x = panel_x + 120
        bar_w = 200
        # Draw HP bar (Green)
        hp_max = max(1, player.max_hp)
        hp_val = max(0, min(int(player.hp), hp_max))
        hp_fill_w = int(bar_w * (hp_val / hp_max))
        hp_bg_rect = pygame.Rect(bar_x, panel_y + 18, bar_w, 24)
        pygame.draw.rect(surface, (20, 15, 20), hp_bg_rect)
        pygame.draw.rect(surface, (35, 140, 52), pygame.Rect(bar_x, panel_y + 18, hp_fill_w, 24))
        pygame.draw.rect(surface, self.BORDER_COLOR, hp_bg_rect, self.BORDER_WIDTH)
        hp_text = self._font.render(f"HP {hp_val}/{hp_max}", True, self.TEXT_COLOR)
        surface.blit(hp_text, hp_text.get_rect(center=hp_bg_rect.center))
        
        # Draw Stamina bar (Blue)
        sta_max = max(1, player.max_stamina)
        sta_val = max(0, min(player.stamina, sta_max))
        sta_fill_w = int(bar_w * (sta_val / sta_max))
        sta_bg_rect = pygame.Rect(bar_x, panel_y + 52, bar_w, 24)
        pygame.draw.rect(surface, (20, 15, 20), sta_bg_rect)
        pygame.draw.rect(surface, (45, 100, 220), pygame.Rect(bar_x, panel_y + 52, sta_fill_w, 24))
        pygame.draw.rect(surface, self.BORDER_COLOR, sta_bg_rect, self.BORDER_WIDTH)
        sta_text = self._font.render(f"STA {sta_val}/{sta_max}", True, self.TEXT_COLOR)
        surface.blit(sta_text, sta_text.get_rect(center=sta_bg_rect.center))
        
        # 3. Stats display
        stat_x = bar_x + bar_w + 25
        atk_text = self._font.render(f"ATK: {player.attack}", True, self.TEXT_COLOR)
        vis_text = self._font.render(f"VIS: {player.vision}", True, self.TEXT_COLOR)
        keys_text = self._font.render(f"KEYS: {player.keys}/{key_target_count}", True, (255, 215, 0))
        surface.blit(atk_text, (stat_x, panel_y + 20))
        surface.blit(vis_text, (stat_x, panel_y + 45))
        surface.blit(keys_text, (stat_x, panel_y + 70))
        
        # 4. Inventory Slots (5 slots horizontally)
        slot_start_x = stat_x + 130
        slot_y = panel_y + 18
        slot_sz = 74
        slot_gap = 12
        
        for i in range(5):
            slot_rect = pygame.Rect(slot_start_x + i * (slot_sz + slot_gap), slot_y, slot_sz, slot_sz)
            # Draw slot background
            pygame.draw.rect(surface, (25, 20, 30), slot_rect)
            
            # Draw selection highlight
            if i == selected_index:
                pygame.draw.rect(surface, (255, 230, 100), slot_rect, 3)
            else:
                pygame.draw.rect(surface, self.BORDER_COLOR, slot_rect, self.BORDER_WIDTH)
                
            # If there is an item in this slot
            if i < len(sorted_items):
                item_name, item_count = sorted_items[i]
                icon_name = None
                if item_name == "Sword":
                    icon_name = "sword"
                elif item_name == "Torch":
                    icon_name = "torch"
                elif item_name == "Magic Stone":
                    icon_name = "magic_stone"
                elif item_name == "Spirit":
                    icon_name = "spirit"
                elif item_name == "Health Potion":
                    icon_name = "health_potion"
                
                if icon_name:
                    item_icon = get_named_icon(icon_name, 48)
                    if item_icon:
                        surface.blit(item_icon, (slot_rect.centerx - 24, slot_rect.centery - 24))
                
                # Render count if > 1 or for potions
                if item_count > 1 or item_name in ("Health Potion", "Magic Stone"):
                    count_text = self._font.render(f"x{item_count}", True, self.TEXT_COLOR)
                    surface.blit(count_text, (slot_rect.right - 26, slot_rect.bottom - 20))
            
            # Hotkey label (1, 2, 3, 4, 5) at top-left of each slot
            num_surf = self._font.render(str(i + 1), True, (160, 150, 150))
            surface.blit(num_surf, (slot_rect.x + 6, slot_rect.y + 4))

        # 5. Hint text at the right of slots
        hint_x = slot_start_x + 5 * (slot_sz + slot_gap) + 15
        hint_line1 = self._font.render("A/D: Select", True, (160, 150, 150))
        hint_line2 = self._font.render("E: Use item", True, (160, 150, 150))
        hint_line3 = self._font.render("1-5: Hotkeys", True, (160, 150, 150))
        surface.blit(hint_line1, (hint_x, panel_y + 20))
        surface.blit(hint_line2, (hint_x, panel_y + 45))
        surface.blit(hint_line3, (hint_x, panel_y + 70))

    def _draw_game_over(self, surface: pygame.Surface) -> None:
        """Draw the game over message in the center of the screen."""
        text = self._game_over_font.render(
            "GAME OVER",
            True,
            self.GAME_OVER_COLOR,
        )
        text_rect = text.get_rect(center=surface.get_rect().center)
        surface.blit(text, text_rect)

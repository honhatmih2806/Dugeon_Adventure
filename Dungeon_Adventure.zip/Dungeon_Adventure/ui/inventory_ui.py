"""Inventory user interface."""


class InventoryUI:
    """Renders and handles the player inventory screen."""

    def __init__(self) -> None:
        """Initialize the inventory UI."""
        pass

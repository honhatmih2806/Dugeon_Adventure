"""Boss battle manager and fullscreen Gomoku UI for Low and Medium modes."""

from __future__ import annotations

import random
from copy import deepcopy
from enum import Enum
import pygame

from ai.alpha_beta import AlphaBeta
from ai.minimax import BOSS, EMPTY, PLAYER, check_winner, is_board_full
from assets.sprite_manager import get_named_icon
from assets.font_cache import FontCache


class MatchResult(Enum):
    """Possible outcomes of a best-of-three boss match."""

    NONE = "none"
    PLAYER_WIN = "player_win"
    BOSS_WIN = "boss_win"


class BossBattle:
    """Manages rounds, turns, validation, and match flow for the Gomoku boss fight."""

    def __init__(self, mode: str = "LOW") -> None:
        """Initialize Gomoku boss battle based on selected game mode."""
        self._ai = AlphaBeta()
        self._active = False
        self.mode = mode
        
        # Configure board settings based on mode
        if mode == "LOW":
            self.BOARD_SIZE = 6
            self.WIN_LENGTH = 4
            self.WINS_TO_MATCH = 2
        else:
            self.BOARD_SIZE = 15
            self.WIN_LENGTH = 5
            self.WINS_TO_MATCH = 2

        self._board: list[list[int]] = self._empty_board()
        self._cursor_x = self.BOARD_SIZE // 2
        self._cursor_y = self.BOARD_SIZE // 2
        self._current_player = PLAYER
        self._round_number = 1
        self._boss_wins = 0
        self._player_wins = 0
        self._round_one_boss_starts = False
        self._round_over = False
        self._round_message = ""
        self._match_result = MatchResult.NONE
        self._pending_boss_move = False

    @property
    def round_over(self) -> bool:
        """Return True when the current round has ended."""
        return self._round_over

    @property
    def is_active(self) -> bool:
        """Return True while a boss battle is in progress."""
        return self._active

    @property
    def match_result(self) -> MatchResult:
        """Return the final match result once the BO3 is decided."""
        return self._match_result

    @property
    def board(self) -> list[list[int]]:
        """Return a copy of the current board state."""
        return deepcopy(self._board)

    @property
    def cursor(self) -> tuple[int, int]:
        """Return the current cursor position."""
        return self._cursor_x, self._cursor_y

    @property
    def current_player(self) -> int:
        """Return the player token whose turn it is."""
        return self._current_player

    @property
    def round_number(self) -> int:
        """Return the current round index."""
        return self._round_number

    @property
    def boss_wins(self) -> int:
        """Return the boss round-win count."""
        return self._boss_wins

    @property
    def player_wins(self) -> int:
        """Return the player round-win count."""
        return self._player_wins

    @property
    def round_message(self) -> str:
        """Return a short status message for the current round."""
        return self._round_message

    @property
    def is_player_turn(self) -> bool:
        """Return True when the human player may act."""
        return (
            self._active
            and not self._round_over
            and self._match_result == MatchResult.NONE
            and self._current_player == PLAYER
            and not self._pending_boss_move
        )

    @property
    def is_boss_turn(self) -> bool:
        """Return True when the boss is about to move."""
        return self._pending_boss_move

    def enter_battle(self) -> None:
        """Start a new best-of-three boss battle."""
        self._active = True
        self._round_number = 1
        self._boss_wins = 0
        self._player_wins = 0
        self._match_result = MatchResult.NONE
        self._round_one_boss_starts = random.choice([True, False])
        self._start_round()

    def exit_battle(self) -> None:
        """Clear battle state after the match ends."""
        self._active = False
        self._round_over = False
        self._pending_boss_move = False
        self._round_message = ""

    def move_cursor(self, dx: int, dy: int) -> None:
        """Move the selection cursor when it is the player's turn."""
        if not self.is_player_turn:
            return
        self._cursor_x = max(0, min(self.BOARD_SIZE - 1, self._cursor_x + dx))
        self._cursor_y = max(0, min(self.BOARD_SIZE - 1, self._cursor_y + dy))

    def place_player_move(self) -> bool:
        """Place the player's piece at the cursor if the move is valid."""
        if not self.is_player_turn:
            return False
        if not self._is_valid_move(self._cursor_x, self._cursor_y):
            return False

        self._board[self._cursor_y][self._cursor_x] = PLAYER
        self._after_move(PLAYER)
        return True

    def update(self) -> None:
        """Execute the boss move when it is the AI's turn."""
        if not self._pending_boss_move or self._round_over:
            return

        move = self._ai.best_move(self._board, BOSS, win_length=self.WIN_LENGTH)
        if move is None:
            self._finish_round(None)
            return

        x, y = move
        self._board[y][x] = BOSS
        self._cursor_x = x
        self._cursor_y = y
        self._pending_boss_move = False
        self._after_move(BOSS)

    def advance_after_round_delay(self) -> None:
        """Start the next round after a completed round if the match continues."""
        if not self._round_over or self._match_result != MatchResult.NONE:
            return
        self._round_number += 1
        self._start_round()

    def _start_round(self) -> None:
        """Reset the board and assign the starting player for this round."""
        self._board = self._empty_board()
        self._round_over = False
        self._pending_boss_move = False
        self._round_message = ""
        self._cursor_x = self.BOARD_SIZE // 2
        self._cursor_y = self.BOARD_SIZE // 2

        boss_starts = (self._round_number % 2 == 1) == self._round_one_boss_starts
        self._current_player = BOSS if boss_starts else PLAYER
        if boss_starts:
            self._pending_boss_move = True
            self._round_message = "Boss starts this round."

    def _after_move(self, mover: int) -> None:
        """Check for round completion and schedule the next actor."""
        winner = check_winner(self._board, self.WIN_LENGTH)
        if winner != EMPTY:
            self._finish_round(winner)
            return

        if is_board_full(self._board):
            self._finish_round(None)
            return

        self._current_player = PLAYER if mover == BOSS else BOSS
        if self._current_player == BOSS:
            self._pending_boss_move = True

    def _finish_round(self, winner: int | None) -> None:
        """Record round outcome and determine whether the match has ended."""
        self._round_over = True
        self._pending_boss_move = False

        if winner == PLAYER:
            self._player_wins += 1
            self._round_message = "Round won by Player (O)."
        elif winner == BOSS:
            self._boss_wins += 1
            self._round_message = "Round won by Boss (X)."
        else:
            self._round_message = "Round drawn. Rematch with alternate start."

        if self._player_wins >= self.WINS_TO_MATCH:
            self._match_result = MatchResult.PLAYER_WIN
            self._active = False
            return

        if self._boss_wins >= self.WINS_TO_MATCH:
            self._match_result = MatchResult.BOSS_WIN
            self._active = False
            return

    def _is_valid_move(self, x: int, y: int) -> bool:
        """Return True when (x, y) is inside the board and empty."""
        if not (0 <= x < self.BOARD_SIZE and 0 <= y < self.BOARD_SIZE):
            return False
        return self._board[y][x] == EMPTY

    def _empty_board(self) -> list[list[int]]:
        """Create a blank board."""
        return [[EMPTY for _ in range(self.BOARD_SIZE)] for _ in range(self.BOARD_SIZE)]

    def render(self, surface: pygame.Surface) -> None:
        """Draw the fullscreen boss battle Gomoku screen."""
        # 1. Background
        surface.fill((8, 6, 12))

        title_font = FontCache.get(36)
        info_font = FontCache.get(28)
        symbol_font = FontCache.get(42) if self.mode == "LOW" else FontCache.get(30)
        hint_font = FontCache.get(22)

        # 2. Draw Title
        title_text = title_font.render(f"BOSS BATTLE — GOMOKU ({self.mode} MODE)", True, (130, 20, 30))
        title_rect = title_text.get_rect(midtop=(surface.get_width() // 2, 20))
        surface.blit(title_text, title_rect)

        round_text = info_font.render(f"Round {self._round_number}", True, (230, 210, 210))
        round_rect = round_text.get_rect(midtop=(surface.get_width() // 2, 65))
        surface.blit(round_text, round_rect)

        # 3. Draw Gomoku Board (Centered)
        board_height = 480
        cell_size = board_height // self.BOARD_SIZE
        board_pixels = cell_size * self.BOARD_SIZE
        board_x = (surface.get_width() - board_pixels) // 2
        board_y = 120
        board_rect = pygame.Rect(board_x, board_y, board_pixels, board_pixels)

        # Draw board background
        pygame.draw.rect(surface, (20, 15, 25), board_rect)
        pygame.draw.rect(surface, (130, 20, 30), board_rect, 3)

        # Draw grid cells & pieces
        for r in range(self.BOARD_SIZE):
            for c in range(self.BOARD_SIZE):
                cell_rect = pygame.Rect(
                    board_x + c * cell_size,
                    board_y + r * cell_size,
                    cell_size,
                    cell_size,
                )
                # Caro pattern background
                bg_color = (25, 20, 30) if (r + c) % 2 == 0 else (35, 28, 42)
                pygame.draw.rect(surface, bg_color, cell_rect)
                pygame.draw.rect(surface, (80, 60, 75), cell_rect, 1)

                # Cursor
                if self.is_player_turn and c == self._cursor_x and r == self._cursor_y:
                    pygame.draw.rect(surface, (255, 230, 100), cell_rect, 3)

                # Piece symbol
                piece = self._board[r][c]
                if piece != EMPTY:
                    symbol = "O" if piece == PLAYER else "X"
                    color = (80, 180, 255) if piece == PLAYER else (220, 60, 70)
                    sym_surf = symbol_font.render(symbol, True, color)
                    sym_rect = sym_surf.get_rect(center=cell_rect.center)
                    surface.blit(sym_surf, sym_rect)

        # 4. Draw Player HUD Card (Left Side)
        player_card_rect = pygame.Rect(50, 180, 220, 320)
        pygame.draw.rect(surface, (15, 10, 20), player_card_rect)
        
        # Highlight card if Player's turn
        if self.is_player_turn:
            pygame.draw.rect(surface, (255, 230, 100), player_card_rect, 3)
        else:
            pygame.draw.rect(surface, (50, 60, 80), player_card_rect, 1)

        player_icon = get_named_icon("player", 96)
        if player_icon:
            iw, ih = player_icon.get_size()
            surface.blit(player_icon, (player_card_rect.centerx - iw // 2, player_card_rect.y + 20))

        # Text inside Player Card
        p_name = info_font.render("PLAYER", True, (80, 180, 255))
        p_name_rect = p_name.get_rect(midtop=(player_card_rect.centerx, player_card_rect.y + 130))
        surface.blit(p_name, p_name_rect)

        p_symbol = symbol_font.render("Piece: O", True, (80, 180, 255))
        p_symbol_rect = p_symbol.get_rect(midtop=(player_card_rect.centerx, player_card_rect.y + 175))
        surface.blit(p_symbol, p_symbol_rect)

        p_score = info_font.render(f"Wins: {self._player_wins} / {self.WINS_TO_MATCH}", True, (230, 210, 210))
        p_score_rect = p_score.get_rect(midtop=(player_card_rect.centerx, player_card_rect.y + 230))
        surface.blit(p_score, p_score_rect)

        # 5. Draw Boss HUD Card (Right Side)
        boss_card_rect = pygame.Rect(surface.get_width() - 270, 180, 220, 320)
        pygame.draw.rect(surface, (15, 10, 20), boss_card_rect)

        # Highlight card if Boss's turn
        if self.is_boss_turn or self._current_player == BOSS:
            pygame.draw.rect(surface, (220, 60, 70), boss_card_rect, 3)
        else:
            pygame.draw.rect(surface, (50, 60, 80), boss_card_rect, 1)

        boss_icon = get_named_icon("boss", 96)
        if boss_icon:
            iw, ih = boss_icon.get_size()
            surface.blit(boss_icon, (boss_card_rect.centerx - iw // 2, boss_card_rect.y + 20))

        # Text inside Boss Card
        b_name = info_font.render("BOSS", True, (220, 60, 70))
        b_name_rect = b_name.get_rect(midtop=(boss_card_rect.centerx, boss_card_rect.y + 130))
        surface.blit(b_name, b_name_rect)

        b_symbol = symbol_font.render("Piece: X", True, (220, 60, 70))
        b_symbol_rect = b_symbol.get_rect(midtop=(boss_card_rect.centerx, boss_card_rect.y + 175))
        surface.blit(b_symbol, b_symbol_rect)

        b_score = info_font.render(f"Wins: {self._boss_wins} / {self.WINS_TO_MATCH}", True, (230, 210, 210))
        b_score_rect = b_score.get_rect(midtop=(boss_card_rect.centerx, boss_card_rect.y + 230))
        surface.blit(b_score, b_score_rect)

        # 6. Hints & Round Status Message (Bottom)
        if self._round_message:
            msg_surf = hint_font.render(self._round_message, True, (255, 230, 100))
            msg_rect = msg_surf.get_rect(midtop=(surface.get_width() // 2, board_rect.bottom + 15))
            surface.blit(msg_surf, msg_rect)

        hint = f"WASD/Arrows: Move  |  SPACE/E: Place Piece  |  Get {self.WIN_LENGTH} in a row to win round"
        hint_surf = hint_font.render(hint, True, (160, 150, 150))
        hint_rect = hint_surf.get_rect(midbottom=(surface.get_width() // 2, surface.get_height() - 20))
        surface.blit(hint_surf, hint_rect)

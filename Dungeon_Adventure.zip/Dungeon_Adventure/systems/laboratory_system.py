"""AI laboratory room for map unlock interaction."""

from typing import TYPE_CHECKING

import pygame

from assets.sprite_manager import get_named_icon

if TYPE_CHECKING:
    from game.player import Player


class LaboratoryRoom:
    """Full laboratory room that unlocks the minimap on first interaction."""

    MARKER_COLOR: tuple[int, int, int] = (0, 255, 255)
    FLOOR_COLOR: tuple[int, int, int] = (0, 139, 139)

    def __init__(self, position: tuple[int, int]) -> None:
        """Initialize the laboratory room at its center grid position."""
        self.position = position
        self.completed = False
        self.map_unlocked = False

    def interact(self, player: "Player") -> bool:
        """Mark the laboratory complete and unlock the minimap once."""
        del player  # Laboratory interaction does not modify player inventory.
        if self.completed:
            return False

        self.completed = True
        self.map_unlocked = True
        print("Map Unlocked")
        return True

    def render(self, surface: pygame.Surface, tile_size: int) -> None:
        """Draw the activation marker at the laboratory room center."""
        x, y = self.position
        icon = get_named_icon("magic_stone", tile_size)
        if icon:
            iw, ih = icon.get_size()
            dest_x = x * tile_size + (tile_size - iw) // 2
            dest_y = y * tile_size + (tile_size - ih) // 2
            surface.blit(icon, (dest_x, dest_y))
            return

        padding = 7
        rect = pygame.Rect(
            x * tile_size + padding,
            y * tile_size + padding,
            tile_size - padding * 2,
            tile_size - padding * 2,
        )
        pygame.draw.rect(surface, self.MARKER_COLOR, rect)


class LaboratorySystem:
    """Compares AI algorithms and records performance metrics."""

    def __init__(self) -> None:
        """Initialize the laboratory system."""
        pass

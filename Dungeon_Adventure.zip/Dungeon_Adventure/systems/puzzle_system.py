"""Puzzle rooms wired to independent CSP solvers in ai/."""

from typing import TYPE_CHECKING

import pygame

from ai.forward_checking import ForwardCheckingSolver
from ai.min_conflicts import MinConflictsSolver

if TYPE_CHECKING:
    from game.player import Player


class PuzzleRoom:
    """Base class for puzzle rooms that permanently contain and reward keys."""

    color: tuple[int, int, int] = (255, 255, 255)

    def __init__(self, position: tuple[int, int], reward_key_id: int) -> None:
        """Initialize a puzzle room at a grid position."""
        self.position = position
        self.reward_key_id = reward_key_id
        self.solved = False

    def interact(self, player: "Player") -> None:
        """Solve the puzzle and reward the contained key once."""
        if self.solved:
            print(f"Key #{self.reward_key_id} already obtained")
            return

        if not self.solve():
            print("Puzzle could not be solved")
            return

        self._grant_key_reward(player)

    def _grant_key_reward(self, player: "Player") -> None:
        """Award the key stored inside this puzzle room."""
        self.solved = True
        player.inventory.add(f"Key {self.reward_key_id}")
        player.keys += 1
        print(f"Key #{self.reward_key_id} obtained")

    def solve(self) -> bool:
        """Solve this room's puzzle."""
        return False

    def render(self, surface: pygame.Surface, tile_size: int) -> None:
        """Draw the puzzle room marker."""
        x, y = self.position
        padding = 7
        rect = pygame.Rect(
            x * tile_size + padding,
            y * tile_size + padding,
            tile_size - padding * 2,
            tile_size - padding * 2,
        )
        pygame.draw.rect(surface, self.color, rect)


class PuzzleRoomBacktracking(PuzzleRoom):
    """Permanently contains Key #1; solved with Backtracking in ai/backtracking.py."""

    color: tuple[int, int, int] = (235, 220, 65)
    CONTAINED_KEY_ID: int = 1

    def __init__(self, position: tuple[int, int]) -> None:
        """Initialize the backtracking puzzle room with Key #1 inside."""
        super().__init__(position, reward_key_id=self.CONTAINED_KEY_ID)
        self.grid: list[list[int]] = [
            [1, 0, 0],
            [0, 2, 0],
            [0, 0, 3],
        ]
        self._solver = ForwardCheckingSolver(self.grid)

    def interact(self, player: "Player") -> None:
        """Solve the puzzle and release Key #1 from this room."""
        if self.solved:
            print("Key #1 already obtained")
            return

        if not self.solve():
            print("Puzzle could not be solved")
            return

        self.solved = True
        player.inventory.add("Key 1")
        player.keys += 1
        print("Key #1 obtained")

    def solve(self) -> bool:
        """Solve the puzzle by delegating to BacktrackingSolver in ai/."""
        solved = self._solver.solve()
        if solved:
            self.grid = self._solver.grid
        return solved


class PuzzleRoomMinConflicts(PuzzleRoom):
    """Permanently contains Key #2; solved with Min-Conflicts in ai/min_conflicts.py."""

    color: tuple[int, int, int] = (235, 145, 45)
    CONTAINED_KEY_ID: int = 2

    def __init__(self, position: tuple[int, int]) -> None:
        """Initialize the min-conflicts puzzle room with Key #2 inside."""
        super().__init__(position, reward_key_id=self.CONTAINED_KEY_ID)
        self._solver = MinConflictsSolver()
        self.state = self._solver.initialize_state()

    def interact(self, player: "Player") -> None:
        """Solve the puzzle and release Key #2 from this room."""
        if self.solved:
            print("Key #2 already obtained")
            return

        if not self.solve():
            print("Puzzle could not be solved")
            return

        self.solved = True
        player.inventory.add("Key 2")
        player.keys += 1
        print("Key #2 obtained")

    def solve(self) -> bool:
        """Solve the puzzle by delegating to MinConflictsSolver in ai/."""
        solved = self._solver.solve()
        if solved:
            self.state = self._solver.state
        return solved

"""Player character gameplay logic."""

import pygame

from game.inventory import Inventory
from maps.dungeon import Dungeon
from assets.sprite_manager import get_named_icon


class Player:
    """Represents the player with HP, stamina, and inventory."""

    COLOR: tuple[int, int, int] = (50, 150, 255)
    MOVE_COOLDOWN: float = 0.15
    MAX_STAMINA: int = 150
    ATTACK_COST: int = 1
    HEALTH_REGEN_RATE: float = 1.0
    STAMINA_REGEN_RATE: float = 0.5
    ATTACK_ANIM_DURATION: float = 0.18

    def __init__(self, x: int, y: int) -> None:
        """Initialize the player at grid position (x, y)."""
        self.max_hp = 100
        self.hp = self.max_hp
        self.max_stamina = self.MAX_STAMINA
        self.current_stamina = float(self.max_stamina)
        self.keys = 0
        self.inventory = Inventory()
        self.x = x
        self.y = y
        self._move_timer = 0.0
        self.facing: tuple[int, int] = (0, -1)
        self._attack_timer: float = 0.0
        self._attack_cooldown_timer: float = 0.0
        self._health_regen_buffer: float = 0.0
        self.move_cooldown_modifier = 0.0
        
        self.base_attack = 1
        self.base_vision = 3
        self.base_stamina = 6

        # Dynamic gameplay configurations
        self.stamina_cost_per_move = 0.5
        self.move_cooldown_val = 0.15

        # Burn DOT (Damage Over Time) state
        self.burn_timer = 0.0
        
        self.attack = self.base_attack
        self.vision = self.base_vision
        self.stamina_stat = self.base_stamina

    def apply_burn(self, amount: float = 10.0) -> None:
        """Apply a burn status effect that deals damage over time."""
        self.burn_timer = 5.0

    @property
    def stamina(self) -> int:
        """Return current stamina as an integer for HUD and combat checks."""
        return int(self.current_stamina)

    @stamina.setter
    def stamina(self, value: int) -> None:
        """Set current stamina from integer values."""
        self.current_stamina = float(value)

    @classmethod
    def spawn(cls, dungeon: Dungeon) -> "Player":
        """Create a player at the dungeon spawn point."""
        spawn_x, spawn_y = dungeon.get_spawn_point()
        return cls(x=spawn_x, y=spawn_y)

    def grid_position(self) -> tuple[int, int]:
        """Return the player's current grid coordinates."""
        return self.x, self.y

    @property
    def is_alive(self) -> bool:
        """Return True while the player still has HP."""
        return self.hp > 0

    def update(self, keys: pygame.key.ScancodeWrapper, dungeon: object, dt: float) -> None:
        """Move the player with WASD when keys are held, respecting wall collision."""
        if not self.is_alive:
            return

        self.regenerate_passive(dt, dungeon)

        # Apply burn DOT (deals 2 HP per second for 5 seconds)
        if self.burn_timer > 0.0:
            tick = 2.0 * dt
            self.hp = max(0.0, self.hp - tick)
            self.burn_timer = max(0.0, self.burn_timer - dt)

        self._move_timer += dt
        # advance attack animation and cooldown timers
        if self._attack_timer > 0.0:
            self._attack_timer = max(0.0, self._attack_timer - dt)
        if self._attack_cooldown_timer > 0.0:
            self._attack_cooldown_timer = max(0.0, self._attack_cooldown_timer - dt)
        if self._move_timer < (self.move_cooldown_val + self.move_cooldown_modifier):
            return

        dx, dy = 0, 0
        # Support both WASD and arrow keys for player movement.
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            dy = -1
        elif keys[pygame.K_s] or keys[pygame.K_DOWN]:
            dy = 1
        elif keys[pygame.K_a] or keys[pygame.K_LEFT]:
            dx = -1
        elif keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            dx = 1

        if dx == 0 and dy == 0:
            return

        if self.move(dx, dy, dungeon):
            self._move_timer = 0.0
            # update facing when a move succeeds
            if dx != 0 or dy != 0:
                self.facing = (dx, dy)

    def move(self, dx: int, dy: int, dungeon: Dungeon) -> bool:
        """Attempt to move by (dx, dy). Consumes stamina. Returns True if the move succeeded."""
        if not self.is_alive:
            return False

        new_x = self.x + dx
        new_y = self.y + dy

        if not dungeon.is_walkable(new_x, new_y):
            return False

        if hasattr(dungeon, "is_gate_position") and dungeon.is_gate_position(new_x, new_y):
            if dungeon.gate.locked:
                return False

        # Stamina cost checking
        if self.current_stamina < self.stamina_cost_per_move:
            print("Out of stamina! Cannot move.")
            return False

        self.current_stamina -= self.stamina_cost_per_move
        self.x = new_x
        self.y = new_y
        return True

    def start_attack(self) -> None:
        """Begin a short attack animation and apply attack cooldown."""
        self._attack_timer = self.ATTACK_ANIM_DURATION
        self._attack_cooldown_timer = 0.6

    def take_damage(self, amount: int) -> None:
        """Reduce HP by amount, keeping it within valid bounds."""
        if amount <= 0:
            return

        self.hp = max(0, self.hp - amount)

    def heal(self, amount: int) -> None:
        """Restore HP by amount, up to max HP."""
        if amount <= 0:
            return

        self.hp = min(self.max_hp, self.hp + amount)

    def has_sword(self) -> bool:
        """Return True when the player can use sword attacks."""
        return self.inventory.has(Inventory.SWORD)

    def can_attack(self) -> bool:
        """Return True when the player has enough stamina for a sword attack and cooldown is over."""
        return self.current_stamina >= self.ATTACK_COST and self._attack_cooldown_timer <= 0.0

    def consume_stamina(self, amount: int) -> bool:
        """Spend stamina if available. Returns True when stamina was consumed."""
        amount = max(0, amount)
        if self.current_stamina < amount:
            return False

        self.current_stamina -= amount
        return True

    def regenerate_stamina(self, amount: float) -> None:
        """Restore stamina by amount, up to max stamina."""
        if self.current_stamina >= self.max_stamina:
            return

        self.current_stamina = min(
            float(self.max_stamina),
            self.current_stamina + max(0.0, amount),
        )

    def regenerate_health(self, dt: float) -> None:
        """Restore health slowly over time as a buffered regen."""
        if dt <= 0.0 or self.hp >= self.max_hp:
            return

        self._health_regen_buffer += self.HEALTH_REGEN_RATE * dt
        if self._health_regen_buffer < 1.0:
            return

        heal_amount = int(self._health_regen_buffer)
        self._health_regen_buffer -= heal_amount
        self.heal(heal_amount)

    def regenerate_passive(self, dt: float, dungeon: object | None = None) -> None:
        """Passively restore stamina and health over time while below max."""
        if dt <= 0.0:
            return

        # Check special tiles/environments
        is_lab = False
        is_green_shattered = False

        if dungeon is not None:
            # Check Laboratory
            check_lab = getattr(dungeon, "is_laboratory_room_tile", None)
            if check_lab and check_lab(self.x, self.y):
                is_lab = True
            
            # Check Green Crystal in Boss Arena
            crystals = getattr(dungeon, "crystals", None)
            if crystals and "green" in crystals:
                if not crystals["green"]["intact"]:
                    is_green_shattered = True

        if is_green_shattered:
            # Green crystal broken: recovers 3 stamina per 1s
            self.regenerate_stamina(3.0 * dt)
        elif is_lab:
            # Fast stamina regen in Laboratory (30.0 stamina per second)
            self.regenerate_stamina(30.0 * dt)
        else:
            # Scale stamina regeneration by (stamina_stat / 6.0)
            scale = max(0.2, self.stamina_stat / 6.0)
            self.regenerate_stamina(self.STAMINA_REGEN_RATE * scale * dt)

        self.regenerate_health(dt)

    def render(self, surface: pygame.Surface, tile_size: int) -> None:
        """Draw the player centered on its current tile."""
        # Try to draw the provided icon; fall back to simple rectangle.
        icon = get_named_icon("player", tile_size)
        if icon:
            iw, ih = icon.get_size()
            import math

            offset = int(math.sin(pygame.time.get_ticks() / 300.0) * 2)
            dest_x = self.x * tile_size + (tile_size - iw) // 2
            dest_y = self.y * tile_size + (tile_size - ih) // 2 + offset
            surface.blit(icon, (dest_x, dest_y))
            # draw a short attack indicator in front of the player when active
            if self._attack_timer > 0.0:
                fx = self.x + self.facing[0]
                fy = self.y + self.facing[1]
                attack_rect = pygame.Rect(
                    fx * tile_size + 4,
                    fy * tile_size + 4,
                    tile_size - 8,
                    tile_size - 8,
                )
                s = pygame.Surface((attack_rect.width, attack_rect.height), pygame.SRCALPHA)
                s.fill((255, 255, 120, 160))
                surface.blit(s, (attack_rect.x, attack_rect.y))
            return

        padding = 6
        rect = pygame.Rect(
            self.x * tile_size + padding,
            self.y * tile_size + padding,
            tile_size - padding * 2,
            tile_size - padding * 2,
        )
        pygame.draw.rect(surface, self.COLOR, rect)

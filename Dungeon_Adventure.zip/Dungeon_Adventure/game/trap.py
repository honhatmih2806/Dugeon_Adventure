"""Trap definitions and effects."""

import pygame

from game.player import Player


class Trap:
    """Base class for dungeon traps."""

    name: str = "Trap"
    damage: int = 0
    color: tuple[int, int, int] = (120, 0, 0)
    single_use: bool = True

    def __init__(self, x: int, y: int) -> None:
        """Initialize trap state at a grid position."""
        self.x = x
        self.y = y
        self.triggered = False

    def grid_position(self) -> tuple[int, int]:
        """Return the trap's grid coordinates."""
        return self.x, self.y

    def activate(self, player: Player) -> bool:
        """Apply the trap effect to the player. Returns True when activated."""
        if self.single_use and self.triggered:
            return False

        self.triggered = True
        self.apply_effect(player)
        return True

    def apply_effect(self, player: Player) -> None:
        """Apply this trap's effect to the player."""
        if self.damage > 0:
            player.take_damage(self.damage)
            player.apply_burn(10.0)

    def render(self, surface: pygame.Surface, tile_size: int) -> None:
        """Draw the trap centered on its tile using boom.png sprite."""
        from assets.sprite_manager import get_named_icon
        icon = get_named_icon("boom", tile_size)
        if icon:
            rect = icon.get_rect(topleft=(self.x * tile_size, self.y * tile_size))
            surface.blit(icon, rect.topleft)
        else:
            padding = 9
            rect = pygame.Rect(
                self.x * tile_size + padding,
                self.y * tile_size + padding,
                tile_size - padding * 2,
                tile_size - padding * 2,
            )
            pygame.draw.rect(surface, self.color, rect)


class DamageTrap(Trap):
    """A trap that damages the player."""

    name: str = "Damage Trap"
    damage: int = 50
    color: tuple[int, int, int] = (120, 0, 0)


class InstantDeathTrap(Trap):
    """A bomb trap that deals heavy damage."""

    name: str = "Instant Death Trap"
    damage: int = 50
    color: tuple[int, int, int] = (120, 0, 0)

    def apply_effect(self, player: Player) -> None:
        """Damage the player for 50 HP."""
        player.take_damage(self.damage)


SpikeTrap = DamageTrap
DeathTrap = InstantDeathTrap


def create_trap_from_placement(placement: tuple[int, int, str]) -> Trap:
    """Create a trap instance from dungeon generation placement data."""
    x, y, trap_type = placement

    if trap_type == "Damage Trap":
        return DamageTrap(x, y)
    if trap_type == "Instant Death Trap":
        return InstantDeathTrap(x, y)

    raise ValueError(f"Unknown trap placement type: {trap_type}")

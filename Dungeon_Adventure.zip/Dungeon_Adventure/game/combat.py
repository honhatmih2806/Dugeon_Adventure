"""Combat resolution between entities."""

from __future__ import annotations

from typing import TYPE_CHECKING, Iterable

from game.inventory import Inventory

if TYPE_CHECKING:
    from game.enemy import Enemy
    from game.player import Player


class Combat:
    """Handles combat interactions between the player and enemies."""

    SWORD_DAMAGE: int = 1
    STAMINA_COST: int = 5
    MELEE_RANGE: int = 1

    def sword_attack(
        self,
        player: "Player",
        enemies: Iterable["Enemy"],
    ) -> list["Enemy"]:
        """Perform a melee sword attack on adjacent enemies.

        Returns enemies defeated by this attack.
        """
        if not player.inventory.has(Inventory.SWORD):
            return []

        if player.stamina <= 0:
            return []

        if not player.consume_stamina(self.STAMINA_COST):
            return []

        player_position = player.grid_position()
        defeated: list[Enemy] = []

        damage = getattr(player, "attack", self.SWORD_DAMAGE)
        for enemy in enemies:
            if not enemy.is_alive:
                continue
            if not self._is_in_melee_range(player_position, enemy.grid_position()):
                continue

            enemy.take_damage(damage)
            if not enemy.is_alive:
                print("Enemy/Crystal defeated")
                player.regenerate_stamina(50.0)
                print("[COMBAT] Defeated target! +50 Stamina restored.")
                defeated.append(enemy)

        return defeated

    def _is_in_melee_range(
        self,
        attacker: tuple[int, int],
        target: tuple[int, int],
    ) -> bool:
        """Return True when target is within adjacent melee range."""
        distance = abs(attacker[0] - target[0]) + abs(attacker[1] - target[1])
        return distance <= self.MELEE_RANGE

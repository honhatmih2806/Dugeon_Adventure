"""Collectible item definitions."""

from typing import TYPE_CHECKING

import pygame

from assets.sprite_manager import get_named_icon

if TYPE_CHECKING:
    from game.player import Player


class Item:
    """Base class for collectible items."""

    name: str = "Item"
    description: str = "A collectible item."
    color: tuple[int, int, int] = (230, 230, 230)

    def __init__(self, x: int, y: int) -> None:
        """Initialize the item at a grid position."""
        self.x = x
        self.y = y

    def grid_position(self) -> tuple[int, int]:
        """Return the item's current grid coordinates."""
        return self.x, self.y

    def pickup(self, player: "Player") -> bool:
        """Add this item to the player's inventory when it can be collected."""
        player.inventory.add(self.name)
        return True

    def render(self, surface: pygame.Surface, tile_size: int) -> None:
        """Draw the item centered on its tile."""
        # Try to draw a named icon for this item; fall back to colored rect.
        icon = get_named_icon(self.name, tile_size)
        if icon:
            iw, ih = icon.get_size()
            # bobbing animation
            import math

            offset = int(math.sin(pygame.time.get_ticks() / 350.0) * 2)
            dest_x = self.x * tile_size + (tile_size - iw) // 2
            dest_y = self.y * tile_size + (tile_size - ih) // 2 + offset
            surface.blit(icon, (dest_x, dest_y))
            return

        padding = 10
        rect = pygame.Rect(
            self.x * tile_size + padding,
            self.y * tile_size + padding,
            tile_size - padding * 2,
            tile_size - padding * 2,
        )
        pygame.draw.rect(surface, self.color, rect)

    def __repr__(self) -> str:
        """Return a developer-friendly item representation."""
        return (
            f"{self.__class__.__name__}("
            f"name={self.name!r}, x={self.x}, y={self.y})"
        )


class Sword(Item):
    """A basic weapon item."""

    name: str = "Sword"
    description: str = "A sharp blade for close combat."
    color: tuple[int, int, int] = (200, 200, 200)
    damage: int = 25

    def pickup(self, player: "Player") -> bool:
        """Collect the sword and increase attack by one."""
        player.inventory.add(self.name)
        player.attack += 1
        player.base_attack += 1
        print(f"Sword obtained. Attack increased to {player.attack}")
        return True


class Torch(Item):
    """A light source item."""

    name: str = "Torch"
    description: str = "A burning torch that helps reveal dark places."
    color: tuple[int, int, int] = (255, 140, 0)
    light_radius: int = 5

    def pickup(self, player: "Player") -> bool:
        """Collect the torch and expand adventure vision (+3, max 6)."""
        player.inventory.add(self.name)
        player.vision = min(6, player.vision + 3)
        player.base_vision = min(6, player.base_vision + 3)
        print(f"Torch obtained. Vision increased to {player.vision}")
        return True


class HealthPotion(Item):
    """A healing consumable item."""

    name: str = "Health Potion"
    description: str = "A restorative potion that heals you to full health."
    color: tuple[int, int, int] = (0, 220, 0)

    def pickup(self, player: "Player") -> bool:
        """Store the potion in the player's inventory instead of consuming it immediately."""
        player.inventory.add(self.name)
        print("Health Potion obtained")
        return True


class Key(Item):
    """A key item for unlocking doors or exits."""

    name: str = "Key"
    description: str = "A small key for locked paths."
    color: tuple[int, int, int] = (255, 215, 0)

    def __init__(self, x: int, y: int, key_number: int = 1) -> None:
        """Initialize a numbered key at a grid position."""
        super().__init__(x, y)
        self.key_number = key_number
        self.name = f"Key {key_number}"

    def pickup(self, player: "Player") -> bool:
        """Add this numbered key to the inventory for boss door use."""
        player.inventory.add(self.name)
        player.keys += 1
        print(f"{self.name} obtained")
        return True


class MagicStone(Item):
    """A consumable magic stone that can be placed to form a temporary wall.

    Using the stone consumes it from the player's inventory and places a wall
    tile on the adjacent tile in the direction the player is facing. This is
    intended for tactical placement (blocking enemies or sealing passages).
    """

    name: str = "Magic Stone"
    description: str = "A mystical stone used to form a temporary wall."
    color: tuple[int, int, int] = (180, 0, 180)

    def pickup(self, player: "Player") -> bool:
        """Store the magic stone in the player's inventory."""
        # Inventory treats this like a 1-quantity item
        player.inventory.add(self.name)
        print("Magic Stone obtained")
        return True


class Spirit(Item):
    """A guiding spirit that reveals a safe path to the boss entrance."""

    name: str = "Spirit"
    description: str = "A spirit companion that reveals a short route when used."
    color: tuple[int, int, int] = (120, 220, 220)

    def pickup(self, player: "Player") -> bool:
        """Store the spirit in the player's inventory for one use."""
        player.inventory.add(self.name)
        print("Spirit obtained")
        return True


def create_item_from_placement(placement: tuple[int, int, str]) -> Item:
    """Create an item instance from dungeon generation placement data."""
    x, y, item_type = placement

    if item_type == "Key 1":
        return Key(x, y, key_number=1)
    if item_type == "Key 2":
        return Key(x, y, key_number=2)
    if item_type == "Key 3":
        return Key(x, y, key_number=3)
    if item_type == "Key 4":
        return Key(x, y, key_number=4)
    if item_type == "Torch":
        return Torch(x, y)
    if item_type == "Sword":
        return Sword(x, y)
    if item_type == "Health Potion":
        return HealthPotion(x, y)
    if item_type == "Magic Stone":
        return MagicStone(x, y)
    if item_type == "Spirit":
        return Spirit(x, y)

    raise ValueError(f"Unknown item placement type: {item_type}")

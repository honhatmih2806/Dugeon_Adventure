"""Player inventory management."""


class Inventory:
    """Stores supported player items and their quantities."""

    TORCH: str = "Torch"
    SWORD: str = "Sword"
    SPIRIT: str = "Spirit"
    KEY: str = "Key"
    HEALTH_POTION: str = "Health Potion"
    KEY_1: str = "Key 1"
    KEY_2: str = "Key 2"
    KEY_3: str = "Key 3"
    KEY_4: str = "Key 4"
    HEALTH_POTION: str = "Health Potion"

    SUPPORTED_ITEMS: tuple[str, ...] = (
        TORCH,
        SWORD,
        "Magic Stone",
        SPIRIT,
        HEALTH_POTION,
        KEY_1,
        KEY_2,
        KEY_3,
        KEY_4,
    )
    MAX_QUANTITIES: dict[str, int] = {
        TORCH: 10,
        SWORD: 10,
        "Magic Stone": 6,
        SPIRIT: 3,
        HEALTH_POTION: 5,
        KEY_1: 1,
        KEY_2: 1,
        KEY_3: 1,
        KEY_4: 1,
    }

    def __init__(self) -> None:
        """Initialize an empty inventory."""
        self._items = {item: 0 for item in self.SUPPORTED_ITEMS}

    def add(self, item: str, quantity: int = 1) -> None:
        """Add a quantity of a supported item."""
        self._validate_item(item)
        if quantity <= 0:
            return

        new_quantity = self._items[item] + quantity
        if item in self.MAX_QUANTITIES:
            new_quantity = min(new_quantity, self.MAX_QUANTITIES[item])

        self._items[item] = new_quantity

    def remove(self, item: str, quantity: int = 1) -> bool:
        """Remove a quantity of an item. Returns True when successful."""
        self._validate_item(item)
        if quantity <= 0:
            return True

        if self._items[item] < quantity:
            return False

        self._items[item] -= quantity
        return True

    def has(self, item: str, quantity: int = 1) -> bool:
        """Return True if the inventory contains at least quantity of item."""
        self._validate_item(item)
        if quantity <= 0:
            return True

        return self._items[item] >= quantity

    def count(self, item: str) -> int:
        """Return the quantity of a supported item."""
        self._validate_item(item)
        return self._items[item]

    def clear(self) -> None:
        """Remove all items from the inventory."""
        for item in self.SUPPORTED_ITEMS:
            self._items[item] = 0

    def to_dict(self) -> dict[str, int]:
        """Return a copy of all item quantities."""
        return dict(self._items)

    def _validate_item(self, item: str) -> None:
        """Raise ValueError when item is not supported."""
        if item not in self._items:
            raise ValueError(f"Unsupported inventory item: {item}")

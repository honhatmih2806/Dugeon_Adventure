"""Boss entity gameplay logic."""

from __future__ import annotations
import random
from typing import TYPE_CHECKING
from game.enemy import EnemyAStar

if TYPE_CHECKING:
    from game.player import Player
    from maps.boss_arena import BossArena


class BossEnemy(EnemyAStar):
    """Final boss with defensive behavior around boss crystals."""

    STATE_IDLE = "IDLE"
    STATE_DEFEND = "DEFEND"
    STATE_RETURN = "RETURN"
    STATE_CHASE = "CHASE"

    PROTECT_RANGE: int = 3
    DEFEND_DURATION: float = 5.0
    CHASE_RADIUS: int = 4 # Default vision is 4 (version 4)

    def __init__(self, x: int, y: int, home: tuple[int, int]) -> None:
        super().__init__(x, y)
        self.home_position = home
        self.state = self.STATE_IDLE
        self.target_crystal: tuple[int, int] | None = None
        self._defend_timer = 0.0
        self._return_path: list[tuple[int, int]] = []
        
        # Player action tracking inside boss room
        self.player_action_count = 0
        self.action_threshold = random.randint(5, 7)
        self._last_player_grid = None
        self._last_player_attacking = False

    def activate_defense(self, crystal_position: tuple[int, int]) -> None:
        """Send the boss to defend a crystal position."""
        self.target_crystal = crystal_position
        self.state = self.STATE_DEFEND
        self._defend_timer = 0.0
        self._return_path = []

    def update(
        self,
        player: "Player",
        arena: "BossArena",
        dt: float,
    ) -> None:
        """Update boss behavior inside the boss arena."""
        if not self.is_alive or not player.is_alive:
            return

        if self._flash_timer > 0.0:
            self._flash_timer = max(0.0, self._flash_timer - dt)

        self._update_contact_damage(player, dt)

        # 1. Check if protection mechanism is activated (player hit any crystal for the first time)
        if not arena.crystal_protection_active:
            if any(c.hp < c.max_hp for c in arena.crystal_entities.values()):
                arena.crystal_protection_active = True
                print("[BOSS ROOM] Crystal protection mechanism activated! Boss will guard crystals every 5-7 actions.")

        # 2. Track player actions inside boss room
        current_grid = player.grid_position()
        is_attacking = player._attack_timer > 0.0
        
        player_acted = False
        if self._last_player_grid is not None and current_grid != self._last_player_grid:
            player_acted = True
        elif is_attacking and not self._last_player_attacking:
            player_acted = True
            
        self._last_player_grid = current_grid
        self._last_player_attacking = is_attacking
        
        # Guard mechanism only runs if crystal protection mechanism has been activated
        if player_acted and arena.crystal_protection_active:
            self.player_action_count += 1
            # Trigger crystal defense when action count matches the threshold (5-7)
            if self.player_action_count >= self.action_threshold:
                self.player_action_count = 0
                self.action_threshold = random.randint(5, 7)
                
                # Check for intact crystals
                intact_crystals = [info for info in arena.crystals.values() if info["intact"]]
                if intact_crystals:
                    # Target the closest intact crystal to player
                    closest = min(intact_crystals, key=lambda c: self._manhattan(current_grid, c["position"]))
                    self.activate_defense(closest["position"])
                    print(f"[BOSS ROOM] Boss defends crystal: {closest['position']}!")

        # 3. Defending crystal state
        if self.state == self.STATE_DEFEND and self.target_crystal is not None:
            # Check player distance to the crystal we are defending
            dist_player_to_crystal = self._manhattan(current_grid, self.target_crystal)
            
            if dist_player_to_crystal <= self.PROTECT_RANGE:
                # Chase/attack the player (chase limit is 3 tiles from crystal)
                self._move_toward_goal(current_grid, arena, set())
            else:
                # Stand guard or move back to target crystal
                if self.grid_position() != self.target_crystal:
                    self._move_toward_goal(self.target_crystal, arena, set())
            
            self._defend_timer += dt
            if self._defend_timer >= self.DEFEND_DURATION:
                self.state = self.STATE_RETURN
                self.target_crystal = None
                self._return_path = []
            return

        # 4. Returning state
        if self.state == self.STATE_RETURN:
            if self.grid_position() != self.home_position:
                if not self._return_path:
                    self._return_path = self._find_path(
                        self.home_position,
                        arena,
                        set(),
                    )
                self._step_along_path(self._return_path, set())
                return
            self.state = self.STATE_IDLE
            return

        # 5. Standard chase state (uses default vision = 4, or active Vision buff = 8)
        distance_to_player = self._manhattan(self.grid_position(), player.grid_position())
        if distance_to_player <= self.CHASE_RADIUS:
            self.state = self.STATE_CHASE
            self._move_chase(player, arena, set())
            return

        # 6. Idle / returning home state
        self.state = self.STATE_IDLE
        if self.grid_position() != self.home_position:
            self.state = self.STATE_RETURN
            self._return_path = []

    def _move_chase(
        self,
        player: "Player",
        arena: "BossArena",
        blocked_positions: set[tuple[int, int]],
    ) -> bool:
        """Chase the player inside the arena."""
        return self._move_toward_goal(
            player.grid_position(),
            arena,
            blocked_positions,
        )

    def _update_contact_damage(self, player: "Player", dt: float) -> None:
        """Damage the player once per cooldown while adjacent, scaling 1 boss damage to 5 player HP."""
        self._damage_timer += dt
        if self._manhattan(self.grid_position(), player.grid_position()) != 1:
            return

        if self._damage_timer < self.DAMAGE_COOLDOWN:
            return

        # 1 boss damage = 5 HP player. Default damage is 6 (which is 30 HP player)
        hp_damage = self.CONTACT_DAMAGE * 5
        player.take_damage(hp_damage)
        print(f"[COMBAT] Boss hits player for {hp_damage} HP (Boss Damage: {self.CONTACT_DAMAGE})!")
        self._damage_timer = 0.0

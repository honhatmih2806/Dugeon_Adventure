"""Global game state tracking."""


class GameState:
    """Tracks the current state of an active game session."""

    def __init__(self) -> None:
        """Initialize the game state."""
        pass

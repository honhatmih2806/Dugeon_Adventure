"""Enemy entity gameplay logic."""

from __future__ import annotations

import random
from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import TYPE_CHECKING

import pygame

from ai.astar import AStar
from ai.greedy import GreedyBestFirstSearch
from assets.sprite_manager import get_named_icon

if TYPE_CHECKING:
    from game.player import Player
    from maps.dungeon import Dungeon


class Enemy(ABC):
    """Base dungeon enemy with patrol, chase, and search states."""

    PATROL: str = "PATROL"
    CHASE: str = "CHASE"
    SEARCH: str = "SEARCH"

    MOVE_COOLDOWN: float = 0.35
    SEARCH_TIMEOUT: float = 3.0
    CONTACT_DAMAGE: int = 10
    DAMAGE_COOLDOWN: float = 1.0
    FLASH_DURATION: float = 0.15
    FLASH_COLOR: tuple[int, int, int] = (255, 255, 255)
    PATROL_WAIT: float = 1.0
    DIRECTIONS: tuple[tuple[int, int], ...] = ((0, -1), (0, 1), (-1, 0), (1, 0))

    def __init__(
        self,
        x: int,
        y: int,
        hp: int = 1,
        detection_radius: int = 8,
        patrol_radius: int = 5,
        sprite_name: str = "enemy",
    ) -> None:
        """Initialize the enemy at a grid position."""
        self.x = x
        self.y = y
        self.hp = hp
        self.max_hp = hp
        self.spawn_position = (x, y)
        self.detection_radius = detection_radius
        self.patrol_radius = patrol_radius
        self.state = self.PATROL
        self.last_known_player_position: tuple[int, int] | None = None
        self.sprite_name = sprite_name
        self._move_timer = 0.0
        self._search_timer = 0.0
        self._damage_timer = self.DAMAGE_COOLDOWN
        self._flash_timer = 0.0
        # short stun timer applied when the enemy is hit (hit-and-run)
        self._stun_timer: float = 0.0
        self._was_adjacent: bool = False
        self.damage_cooldown: float = self.DAMAGE_COOLDOWN
        # Limit how far this enemy will pursue the player from its spawn.
        self.max_chase_distance: int = 12
        # Optional explicit patrol route used for boss-area alert enemies.
        self.patrol_route: list[tuple[int, int]] | None = None
        self._patrol_index: int = 0
        self._patrol_forward: bool = True
        self._patrol_wait: float = 0.0
        self.is_boss_gate_guard: bool = False

    def grid_position(self) -> tuple[int, int]:
        """Return the enemy's current grid coordinates."""
        return self.x, self.y

    @property
    def is_alive(self) -> bool:
        """Return True while the enemy still has HP."""
        return self.hp > 0

    @property
    def current_move_cooldown(self) -> float:
        """Return the current move cooldown considering wall slowdown."""
        cooldown = self.MOVE_COOLDOWN
        if getattr(self, "_wall_slowdown_timer", 0.0) > 0.0:
            return cooldown * 2.0
        return cooldown

    def take_damage(self, amount: int) -> None:
        """Reduce HP and trigger a brief damage flash."""
        if amount <= 0 or not self.is_alive:
            return

        self.hp = max(0, self.hp - amount)
        self._flash_timer = self.FLASH_DURATION
        # stun the enemy briefly so player can hit-and-run
        try:
            stun = getattr(self, "STUN_DURATION", None)
            if stun is None:
                stun = self.MOVE_COOLDOWN * 0.75  # slightly reduced stun (stun quái giảm siêu nhẹ)
        except Exception:
            stun = self.MOVE_COOLDOWN * 0.75

        self._stun_timer = stun
        self._damage_timer = 0.0

    def update(
        self,
        player: "Player",
        dungeon: "Dungeon",
        dt: float,
        blocked_positions: set[tuple[int, int]],
    ) -> None:
        """Update state machine and move one tile when ready."""
        if not self.is_alive or not player.is_alive:
            return
        # decrement stun timer first; when stunned, skip movement/state changes
        if self._stun_timer > 0.0:
            self._stun_timer = max(0.0, self._stun_timer - dt)
            if self._flash_timer > 0.0:
                self._flash_timer = max(0.0, self._flash_timer - dt)
            # still allow contact damage while stunned
            self._update_contact_damage(player, dt)
            return

        if not hasattr(self, "_wall_slowdown_timer"):
            self._wall_slowdown_timer = 0.0

        if self._wall_slowdown_timer > 0.0:
            self._wall_slowdown_timer = max(0.0, self._wall_slowdown_timer - dt)

        # If this is a Ghost (EnemyAStar) and is currently in a wall, set slow timer
        if self.sprite_name == "ghost" and not dungeon.is_walkable(self.x, self.y):
            self._wall_slowdown_timer = 3.0

        if self._flash_timer > 0.0:
            self._flash_timer = max(0.0, self._flash_timer - dt)

        self._update_contact_damage(player, dt)

        self._update_state(player)

        if self.state == self.SEARCH:
            self._search_timer += dt
            if self._search_timer >= self.SEARCH_TIMEOUT:
                self._enter_patrol()

        # If this enemy has an explicit patrol route and is in PATROL state, follow it.
        # Otherwise, use the standard movement machine (chase, search).
        if self.state == self.PATROL and self.patrol_route is not None:
            if self._patrol_wait > 0.0:
                self._patrol_wait = max(0.0, self._patrol_wait - dt)
                return

            self._move_timer += dt
            if self._move_timer < self.current_move_cooldown:
                return

            # determine next index
            next_index = self._patrol_index + (1 if self._patrol_forward else -1)
            if next_index < 0 or next_index >= len(self.patrol_route):
                # reached end — pause and reverse
                self._patrol_forward = not self._patrol_forward
                self._patrol_wait = self.PATROL_WAIT
                self._move_timer = 0.0
                return

            self.x, self.y = self.patrol_route[next_index]
            self._patrol_index = next_index
            self._move_timer = 0.0
            return

        self._move_timer += dt
        if self._move_timer < self.current_move_cooldown:
            return

        moved = False
        if self.state == self.CHASE:
            moved = self._move_chase(player, dungeon, blocked_positions)
        elif self.state == self.SEARCH:
            moved = self._move_search(dungeon, blocked_positions)
        else:
            moved = self._move_patrol(dungeon, blocked_positions)

        if moved:
            self._move_timer = 0.0

    def _update_state(self, player: "Player") -> None:
        """Apply patrol, chase, and search transitions."""
        previous_state = self.state
        player_position = player.grid_position()
        distance = self._manhattan(self.grid_position(), player_position)
        # Only consider the player visible if within detection radius and not
        # too far from this enemy's current position. This prevents long chases
        # and avoids persisting a chase-area anchored at the spawn point.
        player_visible = (
            distance <= self.detection_radius
            and self._manhattan(self.grid_position(), player_position) <= self.max_chase_distance
        )

        if player_visible:
            self.last_known_player_position = player_position
            if previous_state != self.CHASE:
                self._enter_chase()
            self.state = self.CHASE
            return

        if previous_state == self.CHASE:
            self._enter_search()
            self.state = self.SEARCH
            return

        if previous_state == self.SEARCH:
            self.state = self.SEARCH
            return

        self.state = self.PATROL

    def _enter_chase(self) -> None:
        """Handle transition into chase."""
        self._search_timer = 0.0
        print("Enemy entered CHASE state")

    def _enter_search(self) -> None:
        """Handle transition into search."""
        self._search_timer = 0.0
        print("Enemy entered SEARCH state")

    def _enter_patrol(self) -> None:
        """Handle transition back to patrol."""
        self.state = self.PATROL
        self._search_timer = 0.0
        print("Enemy returned to PATROL")

    def _move_patrol(
        self,
        dungeon: "Dungeon",
        blocked_positions: set[tuple[int, int]],
    ) -> bool:
        """Patrol randomly within the spawn area, or return if outside it."""
        if self._manhattan(self.grid_position(), self.spawn_position) > self.patrol_radius:
            return self._move_toward_goal(
                self.spawn_position,
                dungeon,
                blocked_positions,
            )

        candidates: list[tuple[int, int]] = []

        for dx, dy in self.DIRECTIONS:
            next_x = self.x + dx
            next_y = self.y + dy
            next_position = (next_x, next_y)

            if next_position in blocked_positions:
                continue
            if not dungeon.is_walkable(next_x, next_y):
                continue
            if self._manhattan(next_position, self.spawn_position) > self.patrol_radius:
                continue

            candidates.append(next_position)

        if not candidates:
            return False

        self.x, self.y = random.choice(candidates)
        return True

    def _move_search(
        self,
        dungeon: "Dungeon",
        blocked_positions: set[tuple[int, int]],
    ) -> bool:
        """Move to the last known player position and search nearby briefly."""
        if self.last_known_player_position is None:
            return self._move_patrol(dungeon, blocked_positions)

        if self.grid_position() == self.last_known_player_position:
            return self._move_random_near(
                self.last_known_player_position,
                radius=2,
                dungeon=dungeon,
                blocked_positions=blocked_positions,
            )

        return self._move_toward_goal(
            self.last_known_player_position,
            dungeon,
            blocked_positions,
        )

    def _move_random_near(
        self,
        center: tuple[int, int],
        radius: int,
        dungeon: "Dungeon",
        blocked_positions: set[tuple[int, int]],
    ) -> bool:
        """Move randomly within a small radius of a target tile."""
        candidates: list[tuple[int, int]] = []

        for dx, dy in self.DIRECTIONS:
            next_x = self.x + dx
            next_y = self.y + dy
            next_position = (next_x, next_y)

            if next_position in blocked_positions:
                continue
            if not dungeon.is_walkable(next_x, next_y):
                continue
            if self._manhattan(next_position, center) > radius:
                continue

            candidates.append(next_position)

        if not candidates:
            return False

        self.x, self.y = random.choice(candidates)
        return True

    def _move_toward_goal(
        self,
        goal: tuple[int, int],
        dungeon: "Dungeon",
        blocked_positions: set[tuple[int, int]],
    ) -> bool:
        """Move one tile along a path toward a goal position."""
        path = self._find_path(goal, dungeon, blocked_positions)
        return self._step_along_path(path, blocked_positions)

    @abstractmethod
    def _find_path(
        self,
        goal: tuple[int, int],
        dungeon: "Dungeon",
        blocked_positions: set[tuple[int, int]],
    ) -> list[tuple[int, int]]:
        """Return a path to the goal using the enemy's search algorithm."""
        return []

    @abstractmethod
    def _move_chase(
        self,
        player: "Player",
        dungeon: "Dungeon",
        blocked_positions: set[tuple[int, int]],
    ) -> bool:
        """Move toward the player while chasing."""
        return False

    def _update_contact_damage(self, player: "Player", dt: float) -> None:
        """Damage the player once per cooldown while adjacent."""
        self._damage_timer += dt
        is_adjacent = (self._manhattan(self.grid_position(), player.grid_position()) == 1)

        if not is_adjacent:
            self._was_adjacent = False
            return

        # Now we are adjacent (Manhattan distance == 1)
        if not self._was_adjacent:
            self._was_adjacent = True
            
            # Set initial attack delays (0.1s for skeleton, 0.3s for ghost) to prevent instant-hit
            if self.sprite_name == "ghost":
                first_attack_delay = 0.3
            else:
                first_attack_delay = 0.1
                
            self._damage_timer = max(0.0, self.damage_cooldown - first_attack_delay)

        if self._damage_timer < self.damage_cooldown:
            return

        player.take_damage(self.CONTACT_DAMAGE)
        self._damage_timer = 0.0

    def render(self, surface: pygame.Surface, tile_size: int) -> None:
        """Draw the enemy centered on its current tile."""
        # Flash override: draw white flash when recently hit.
        if self._flash_timer > 0.0:
            color = self.FLASH_COLOR
            padding = 6
            rect = pygame.Rect(
                self.x * tile_size + padding,
                self.y * tile_size + padding,
                tile_size - padding * 2,
                tile_size - padding * 2,
            )
            pygame.draw.rect(surface, color, rect)
            return

        icon = get_named_icon(self.sprite_name, tile_size)
        if icon:
            iw, ih = icon.get_size()
            import math

            offset = int(math.sin(pygame.time.get_ticks() / 320.0) * 2)
            dest_x = self.x * tile_size + (tile_size - iw) // 2
            dest_y = self.y * tile_size + (tile_size - ih) // 2 + offset
            surface.blit(icon, (dest_x, dest_y))
            return

        color = getattr(self, "color", (200, 200, 200))
        padding = 6
        rect = pygame.Rect(
            self.x * tile_size + padding,
            self.y * tile_size + padding,
            tile_size - padding * 2,
            tile_size - padding * 2,
        )
        pygame.draw.rect(surface, color, rect)

    @staticmethod
    def _manhattan(
        first: tuple[int, int],
        second: tuple[int, int],
    ) -> int:
        """Return Manhattan distance between two grid positions."""
        return abs(first[0] - second[0]) + abs(first[1] - second[1])

    def _step_along_path(
        self,
        path: list[tuple[int, int]],
        blocked_positions: set[tuple[int, int]],
    ) -> bool:
        """Move one tile along the first valid path step."""
        for next_x, next_y in path:
            if (next_x, next_y) in blocked_positions:
                continue

            self.x = next_x
            self.y = next_y
            return True

        return False

    def _make_walkable_checker(
        self,
        dungeon: "Dungeon",
        blocked_positions: set[tuple[int, int]],
        goal: tuple[int, int],
    ) -> Callable[[int, int], bool]:
        """Return a walkability callback for pathfinding."""
        current = self.grid_position()

        def is_walkable(x: int, y: int) -> bool:
            position = (x, y)
            if position == goal or position == current:
                return dungeon.is_walkable(x, y)
            return dungeon.is_walkable(x, y) and position not in blocked_positions

        return is_walkable


class EnemyGreedy(Enemy):
    """Enemy that chases using Greedy Best-First Search from ai/greedy.py."""

    color: tuple[int, int, int] = (220, 45, 45)

    MAX_HP: int = 3

    def __init__(self, x: int, y: int) -> None:
        """Initialize the greedy enemy (Skeleton)."""
        super().__init__(x, y, hp=self.MAX_HP, sprite_name="skeleton")
        self._pathfinder = GreedyBestFirstSearch()
        self.damage_cooldown = 1.2

    def _find_path(
        self,
        goal: tuple[int, int],
        dungeon: "Dungeon",
        blocked_positions: set[tuple[int, int]],
    ) -> list[tuple[int, int]]:
        """Find a path with greedy best-first search."""
        return self._pathfinder.find_path(
            self.grid_position(),
            goal,
            self._make_walkable_checker(dungeon, blocked_positions, goal),
        )

    def _move_chase(
        self,
        player: "Player",
        dungeon: "Dungeon",
        blocked_positions: set[tuple[int, int]],
    ) -> bool:
        """Follow the player using greedy best-first search."""
        return self._move_toward_goal(
            player.grid_position(),
            dungeon,
            blocked_positions,
        )


class EnemyAStar(Enemy):
    """Enemy that chases using A* search from ai/astar.py (Ghost with wall-passing capability)."""

    color: tuple[int, int, int] = (160, 60, 220)

    MAX_HP: int = 5

    def __init__(self, x: int, y: int) -> None:
        """Initialize the A* enemy (Ghost)."""
        super().__init__(x, y, hp=self.MAX_HP, sprite_name="ghost")
        self._pathfinder = AStar()
        self._wall_crosses = 0
        self.damage_cooldown = 0.8

    def _make_walkable_checker(
        self,
        dungeon: "Dungeon",
        blocked_positions: set[tuple[int, int]],
        goal: tuple[int, int],
    ) -> Callable[[int, int], bool]:
        """Return a walkability callback for pathfinding that allows passing through walls (for Ghost)."""
        current = self.grid_position()

        def is_walkable(x: int, y: int) -> bool:
            position = (x, y)
            if not (0 <= x < dungeon.GRID_WIDTH and 0 <= y < dungeon.GRID_HEIGHT):
                return False
            if position != goal and position != current and position in blocked_positions:
                return False
            
            # If the ghost has already crossed a wall once, it cannot enter walls anymore
            if self._wall_crosses >= 1:
                return dungeon.is_walkable(x, y)
                
            return True

        return is_walkable

    def _make_cost_checker(self, dungeon: "Dungeon") -> Callable[[int, int], int]:
        """Return a step cost callback where walls cost more to pass through (for Ghost)."""
        def get_cost(x: int, y: int) -> int:
            if not dungeon.is_walkable(x, y):
                return 4
            return 1
        return get_cost

    def _find_path(
        self,
        goal: tuple[int, int],
        dungeon: "Dungeon",
        blocked_positions: set[tuple[int, int]],
    ) -> list[tuple[int, int]]:
        """Find a path with A* search with custom wall cost."""
        return self._pathfinder.find_path(
            self.grid_position(),
            goal,
            self._make_walkable_checker(dungeon, blocked_positions, goal),
            self._make_cost_checker(dungeon),
        )

    def _move_toward_goal(
        self,
        goal: tuple[int, int],
        dungeon: "Dungeon",
        blocked_positions: set[tuple[int, int]],
    ) -> bool:
        """Move toward target and count wall crossings."""
        path = self._find_path(goal, dungeon, blocked_positions)
        old_pos = self.grid_position()
        success = self._step_along_path(path, blocked_positions)
        if success:
            new_pos = self.grid_position()
            # If moving from walkable (floor) to non-walkable (wall)
            if dungeon.is_walkable(*old_pos) and not dungeon.is_walkable(*new_pos):
                self._wall_crosses += 1
                print(f"[GHOST] Wall crossed! Total: {self._wall_crosses}")
        return success

    def _move_chase(
        self,
        player: "Player",
        dungeon: "Dungeon",
        blocked_positions: set[tuple[int, int]],
    ) -> bool:
        """Follow the player using A* search."""
        return self._move_toward_goal(
            player.grid_position(),
            dungeon,
            blocked_positions,
        )
